.pragma library
// Model-only quantities: fixed identification band, independent of view and measured annotations.
function analyze(model,evaluate,analyzeFeatures,supportedAt){
    var r={minimum:model.fitMin,maximum:model.fitMax,dcGain:null,dcGainDb:null,cutoffs:[],gainCrossovers:[],phaseCrossovers:[],resonances:[],error:null};
    var lo=model.fitMin,hi=model.fitMax;
    if(!(lo>0)||!(hi>lo)){r.error="模型分析频段无效";return r;}
    function point(f){var h=evaluate(model,f),m=Math.sqrt(h[0]*h[0]+h[1]*h[1]);return {frequency:f,gainDb:20*Math.log(m)/Math.LN10,phaseDeg:Math.atan2(h[1],h[0])*180/Math.PI,valid:m>0&&isFinite(m),coherence:1};}
    var ai=0,bi=0;while(ai<model.a.length&&model.a[ai]===0)ai++;while(bi<model.b.length&&model.b[bi]===0)bi++;
    if(ai<model.a.length){if(bi>=model.b.length||bi>ai)r.dcGain=0;else if(bi===ai)r.dcGain=model.b[bi]/model.a[ai];}
    if(r.dcGain!==null&&isFinite(r.dcGain)&&r.dcGain!==0)r.dcGainDb=20*Math.log(Math.abs(r.dcGain))/Math.LN10;
    // Limit phase change due to known delay to <= 5 degrees per sample.
    var count=Math.max(8192,Math.ceil(72*Math.max(0,model.delay||0)*hi*Math.log(hi/lo)));
    r.resolutionLimited=count>65536;count=Math.min(count,65536);
    var points=[],i;for(i=0;i<=count;i++)points.push(point(lo*Math.pow(hi/lo,i/count)));
    var features=analyzeFeatures(points,{referenceDb:r.dcGainDb===null?0:r.dcGainDb,loop:true});
    function tag(p){p.supported=supportedAt(model,p.frequency);return p;}
    // Refine the detected brackets directly against the analytical model.
    function refine(hit,key,target){var index=Math.max(0,Math.min(count-1,Math.floor(Math.log(hit.frequency/lo)/Math.log(hi/lo)*count))),a=points[index],b=points[index+1];
        function value(f){var p=point(f);if(key==="phaseDeg"){while(p.phaseDeg-target>180)p.phaseDeg-=360;while(p.phaseDeg-target< -180)p.phaseDeg+=360;}return {p:p,v:p[key]-target};}
        var left=value(a.frequency),right=value(b.frequency),low=a.frequency,high=b.frequency;
        if(left.v*right.v<=0)for(var k=0;k<40;k++){var mid=Math.sqrt(low*high),current=value(mid);if(left.v*current.v<=0){high=mid;right=current;}else{low=mid;left=current;}}
        else {low=hit.frequency;high=hit.frequency;}
        var p=value(Math.sqrt(low*high)).p;
        var margin=((180+p.phaseDeg)%360+360)%360;if(margin>180)margin-=360;
        p.phaseMargin=key==="gainDb"&&target===0?margin:null;p.gainMargin=key==="phaseDeg"?-p.gainDb:null;
        return tag(p);
    }
    if(r.dcGainDb!==null)for(i=0;i<features.cutoffs.length;i++)r.cutoffs.push(refine(features.cutoffs[i],"gainDb",r.dcGainDb-3.010299956639812));
    for(i=0;i<features.gainCrossovers.length;i++)r.gainCrossovers.push(refine(features.gainCrossovers[i],"gainDb",0));
    for(i=0;i<features.phaseCrossovers.length;i++)r.phaseCrossovers.push(refine(features.phaseCrossovers[i],"phaseDeg",features.phaseCrossovers[i].phaseDeg));
    for(i=1;i<count;i++)if(points[i].valid&&points[i-1].valid&&points[i+1].valid&&points[i].gainDb>points[i-1].gainDb&&points[i].gainDb>points[i+1].gainDb){
        var l=Math.log(points[i-1].frequency),h=Math.log(points[i+1].frequency);
        for(var j=0;j<40;j++){var u=l+(h-l)/3,v=h-(h-l)/3;if(point(Math.exp(u)).gainDb<point(Math.exp(v)).gainDb)l=u;else h=v;}
        var peak=tag(point(Math.exp((l+h)/2)));peak.relativePeakDb=r.dcGainDb===null?null:peak.gainDb-r.dcGainDb;r.resonances.push(peak);
    }
    r.resonances.sort(function(a,b){return b.gainDb-a.gainDb;});
    r.dcExtrapolated=true;r.marginInterpretation="PM/GM apply only when this transfer function is an open-loop SISO negative-feedback loop; not a stability certificate.";
    return r;
}
function display(v,d){return v!==null&&v!==undefined&&isFinite(v)?Number(v).toFixed(d===undefined?2:d):"—";}
function rows(r,loop){
    if(!r)return [];
    if(r.error)return [r.error];
    function hz(p){return display(p.frequency)+" Hz"+(p.supported?"":"（支持缺口内预测）");}
    var out=["直流增益 K = "+display(r.dcGain,4)+" · "+display(r.dcGainDb)+" dB（模型外推）", "截止 fc（相对直流 −3.01 dB）："+(r.cutoffs.length?r.cutoffs.map(hz).join("、"):r.dcGainDb===null?"无有限非零直流参考，不适用":"拟合频段内未找到")];
    out.push("0 dB 穿越 fg："+(r.gainCrossovers.length?r.gainCrossovers.map(function(p){return hz(p)+(loop?" · PM "+display(p.phaseMargin)+"°":"");}).join("；"):"拟合频段内未找到"));
    if(loop)out.push("−180° 穿越 fp / GM："+(r.phaseCrossovers.length?r.phaseCrossovers.map(function(p){return hz(p)+" · GM "+display(p.gainMargin)+" dB";}).join("；"):"拟合频段内未找到（不等同于无穷裕度）"));
    out.push("谐振 fr / 峰值 Gr："+(r.resonances.length?r.resonances.map(function(p){return hz(p)+" · "+display(p.gainDb)+" dB"+(p.relativePeakDb!==null?" · ΔMr "+display(p.relativePeakDb)+" dB":"");}).join("；"):"拟合频段内无内部局部峰"));
    if(r.resolutionLimited)out.push("延迟较大：扫描分辨率已达上限，可能漏检穿越。");
    return out;
}
