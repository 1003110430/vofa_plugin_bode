import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import "IdentificationDisplay.js" as Display
import "ModelParameters.js" as Parameters

Rectangle {
    id:assessment
    objectName:"bode-assessment"
    property var model:null
    property bool loopMode:false
    property var candidates:[]
    property bool allowExpand:true
    property var score:model?(model.validation||model.training):null
    signal candidateChosen(int poles,int zeros)
    signal expandRequested()
    implicitHeight:statsContents.implicitHeight+20;implicitWidth:340
    color:"#0d1d30";radius:8;border.color:"#29455e"
    ColumnLayout {
        id:statsContents
        anchors.fill:parent;anchors.margins:10;spacing:6
        RowLayout {
            Layout.fillWidth:true
            BodeLabel {text:"辨识评估";font.pixelSize:12;font.bold:true;color:"#d4e7f7"}
            Item {Layout.fillWidth:true}
            BodeLabel {text:assessment.model?(assessment.model.stable?"● 稳定":"● 非稳定"):"等待辨识";font.pixelSize:10;color:assessment.model&&!assessment.model.stable?"#ff9585":"#63d6b3"}
        }
        BodeLabel {Layout.fillWidth:true;elide:Text.ElideRight;font.pixelSize:10;color:"#819fb9";text:!assessment.model?"完成辨识后显示误差与候选模型":(assessment.model.validation?(assessment.model.preprocessing&&assessment.model.preprocessing.validationMode==="frequency"?"频点留出 · 同记录":"留出时段验证"):"仅训练 · 未留出验证")+" · "+assessment.score.points+" 个频点"}
        BodeLabel {objectName:"bode-support-summary";visible:assessment.model!==null;Layout.fillWidth:true;wrapMode:Text.Wrap;font.pixelSize:10;color:assessment.model&&assessment.model.bandCoverage&&assessment.model.bandCoverage.percent<70?"#f4ce87":"#819fb9";text:!assessment.model?"":"拟合 "+Display.display(assessment.model.fitMin,2)+"～"+Display.display(assessment.model.fitMax,2)+" Hz"+(assessment.model.bandCoverage&&assessment.model.bandCoverage.percent!==null?" · 覆盖测量可信点 "+Display.display(assessment.model.bandCoverage.percent,1)+"%":"")+(assessment.model.bandCoverage&&assessment.model.bandCoverage.percent<70?"；范围覆盖不足，请扩大辨识频段或检查激励。":"")+(assessment.model.bandCoverage&&assessment.model.bandCoverage.missedCutoffs&&assessment.model.bandCoverage.missedCutoffs.length?"；未覆盖测得截止点 "+assessment.model.bandCoverage.missedCutoffs.map(function(f){return Display.display(f,2)+" Hz";}).join("、"):"")+(assessment.model.preprocessing&&assessment.model.preprocessing.validationUnavailableReason?"；"+assessment.model.preprocessing.validationUnavailableReason:"")}
        GridLayout {
            columns:2;Layout.fillWidth:true;columnSpacing:6;rowSpacing:6
            Repeater {
                model:4
                Rectangle {
                    Layout.fillWidth:true;implicitHeight:43;radius:5;color:"#152b40"
                    Column {anchors.left:parent.left;anchors.leftMargin:9;anchors.verticalCenter:parent.verticalCenter;spacing:2
                        BodeLabel {text:["频响拟合度 ↑","复频响误差 ↓","幅度 RMSE ↓","相位 RMSE ↓"][index];font.pixelSize:9;color:"#87a4be"}
                        BodeLabel {text:!assessment.score?"—":index===0?Display.display(Display.fitPercent(assessment.score),2)+" %":index===1?Display.display(assessment.score.relativeErrorPercent,2)+" %":index===2?Display.display(assessment.score.gainRmseDb,3)+" dB":Display.display(assessment.score.phaseRmseDeg,2)+"°";font.pixelSize:16;font.bold:true;color:index===0?"#6adbc2":"#cfdfef"}
                    }
                }
            }
        }
        BodeLabel {visible:assessment.model!==null;Layout.fillWidth:true;text:"辨识模型 · 关键参数";font.pixelSize:11;color:"#f4ce87"}
        Repeater {
            model:Parameters.rows(assessment.model?assessment.model.keyParameters:null,assessment.loopMode)
            BodeLabel {objectName:"bode-model-parameter-row";Layout.fillWidth:true;wrapMode:Text.Wrap;text:modelData;font.pixelSize:10;color:"#c3d9eb"}
        }
        BodeLabel {visible:assessment.model!==null;Layout.fillWidth:true;wrapMode:Text.Wrap;font.pixelSize:9;color:"#819fb9";text:"仅在拟合频段搜索；随候选模型更新，与实测参数分别计算。PM/GM 需选择开环环路模式；不据此判定闭环稳定。"}
        BodeLabel {visible:assessment.model!==null;Layout.fillWidth:true;text:"阻尼比 · 模型极点估计";font.pixelSize:11;color:"#bad1e5"}
        BodeLabel {objectName:"bode-modal-summary";visible:assessment.model!==null;Layout.fillWidth:true;wrapMode:Text.Wrap;font.pixelSize:10;color:"#f4ce87";text:!assessment.model?"":assessment.model.modalAnalysis&&assessment.model.modalAnalysis.error?assessment.model.modalAnalysis.error:(assessment.model.limitedSupport?"频点较少；":"")+(assessment.score&&assessment.score.relativeErrorPercent>20?"验证误差偏大；":"")+"ζ 为模型估计；fn 为固有频率（Hz）"}
        Repeater {
            model:assessment.model&&assessment.model.modalAnalysis?assessment.model.modalAnalysis.modes:[]
            BodeLabel {objectName:"bode-modal-row";Layout.fillWidth:true;wrapMode:Text.Wrap;font.pixelSize:10;color:modelData.withinFitBand===false||modelData.inNyquist===false?"#f4ce87":"#a8d9d0";text:modelData.kind+" · ζ "+Display.display(modelData.dampingRatio,4)+" · fn "+Display.display(modelData.naturalFrequencyHz,2)+" Hz"+(modelData.withinFitBand===false||modelData.inNyquist===false?" · 带外":"");ToolTip.visible:modeMouse.containsMouse;ToolTip.text:"极点："+Display.display(modelData.real,3)+(modelData.imag?" ± j"+Display.display(modelData.imag,3):"")+" rad/s；衰减振荡频率 "+Display.display(modelData.dampedFrequencyHz,2)+" Hz"+(modelData.withinFitBand===false||modelData.inNyquist===false?"；频率不在辨识支持带内，不能据此认定真实模态。":"");MouseArea{id:modeMouse;anchors.fill:parent;hoverEnabled:true;acceptedButtons:Qt.NoButton}}
        }
        BodeLabel {visible:assessment.model!==null;Layout.fillWidth:true;wrapMode:Text.Wrap;font.pixelSize:9;color:"#698ba8";text:"实极点 ζ=±1 为极点定义，不代表整系统临界阻尼。"}
        RowLayout {Layout.fillWidth:true;BodeLabel {text:"零极点对比";font.pixelSize:11;color:"#bad1e5"}Item{Layout.fillWidth:true}BodeLabel {text:assessment.candidates.length>1?(assessment.allowExpand?"展开对比 ↗":"点击行切换模型"):"自动选阶后可对比";font.pixelSize:9;color:"#7698b5";MouseArea {anchors.fill:parent;enabled:assessment.allowExpand;cursorShape:Qt.PointingHandCursor;onClicked:assessment.expandRequested()}}}
        RowLayout {
            Layout.fillWidth:true;spacing:4
            BodeLabel {Layout.preferredWidth:72;text:"极点 / 零点";font.pixelSize:9;color:"#7896b0"}
            BodeLabel {Layout.preferredWidth:28;horizontalAlignment:Text.AlignHCenter;text:"参数";font.pixelSize:9;color:"#7896b0"}
            BodeLabel {Layout.fillWidth:true;horizontalAlignment:Text.AlignRight;text:"训练误差 %";font.pixelSize:9;color:"#7896b0"}
            BodeLabel {Layout.fillWidth:true;horizontalAlignment:Text.AlignRight;text:"验证误差 %";font.pixelSize:9;color:"#7896b0"}
        }
        ListView {
            id:comparison;Layout.fillWidth:true;Layout.fillHeight:true;Layout.minimumHeight:85
            clip:true;model:assessment.candidates;spacing:2;boundsBehavior:Flickable.StopAtBounds
            ScrollBar.vertical:ScrollBar {policy:ScrollBar.AsNeeded}
            delegate:Rectangle {
                width:comparison.width-8;height:25;radius:4
                property bool current:Display.key(assessment.model)===modelData.key
                color:current?"#244760":rowMouse.containsMouse?"#1b354c":"#12263a"
                border.color:current?"#59c4dc":"transparent"
                RowLayout {
                    anchors.fill:parent;anchors.leftMargin:6;anchors.rightMargin:6;spacing:4
                    BodeLabel {Layout.preferredWidth:66;text:modelData.poles+" / "+modelData.zeros+(modelData.recommended?" ★":"");font.pixelSize:10;color:modelData.ok?modelData.recommended?"#f4ce87":"#c5d9ea":"#6f879c"}
                    BodeLabel {Layout.preferredWidth:28;horizontalAlignment:Text.AlignHCenter;text:modelData.parameters; font.pixelSize:10;color:"#9ab5cc"}
                    BodeLabel {Layout.fillWidth:true;horizontalAlignment:Text.AlignRight;text:modelData.ok?Display.display(modelData.trainingErrorPercent,2):"不可用";font.pixelSize:10;color:"#9ab5cc"}
                    BodeLabel {Layout.fillWidth:true;horizontalAlignment:Text.AlignRight;text:modelData.ok?Display.display(modelData.validationErrorPercent,2):"—";font.pixelSize:10;color:modelData.ok?"#c5dfed":"#6f879c"}
                }
                MouseArea {id:rowMouse;anchors.fill:parent;hoverEnabled:true;cursorShape:modelData.ok?Qt.PointingHandCursor:Qt.ArrowCursor;onClicked:if(modelData.ok)assessment.candidateChosen(modelData.poles,modelData.zeros)}
                ToolTip.visible:rowMouse.containsMouse
                ToolTip.delay:500
                ToolTip.text:modelData.ok?(modelData.recommended?"★ 自动推荐；":"")+"参数数："+modelData.parameters+"；点击查看此模型的公式、误差与曲线。":modelData.reason||"该候选辨识失败。"
            }
        }
        BodeLabel {Layout.fillWidth:true;wrapMode:Text.Wrap;text:"拟合度 = 100% − 复频响误差；非时域 R²。★ 自动推荐";font.pixelSize:9;color:"#698ba8"}
    }
}
