.pragma library
// Pole-based continuous-time modal estimates; independent from fitting success.
function times(a,b){return [a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]];}
function divide(a,b){var d=b[0]*b[0]+b[1]*b[1];return [ (a[0]*b[0]+a[1]*b[1])/d,(a[1]*b[0]-a[0]*b[1])/d];}
function polynomial(a,z){var p=[a[a.length-1],0],derivative=[0,0];for(var i=a.length-2;i>=0;i--){derivative=times(derivative,z);derivative[0]+=p[0];derivative[1]+=p[1];p=times(p,z);p[0]+=a[i];}return {p:p,d:derivative};}
function magnitude(z){return Math.sqrt(z[0]*z[0]+z[1]*z[1]);}
function roots(coefficients){
    var a=coefficients.slice(),n=a.length-1,zeros=[],i,k;
    while(n>0&&a[0]===0){zeros.push([0,0]);a.shift();n--;}
    if(n===0)return zeros;
    if(n===1)return zeros.concat([[-a[0]/a[1],0]]);
    if(n===2){
        var b=a[1]/a[2],c=a[0]/a[2],disc=b*b-4*c;
        if(disc<0)return zeros.concat([[-b/2,Math.sqrt(-disc)/2],[-b/2,-Math.sqrt(-disc)/2]]);
        var q=-.5*(b+(b>=0?1:-1)*Math.sqrt(disc));
        return zeros.concat(q===0?[[0,0],[0,0]]:[[q,0],[c/q,0]]);
    }
    var radius=0;for(i=0;i<n;i++)radius=Math.max(radius,Math.pow(Math.abs(a[i]/a[n]),1/(n-i)));
    if(!(radius>0)||!isFinite(radius))throw new Error("极点缩放失败。");
    var scaled=[];for(i=0;i<=n;i++)scaled[i]=a[i]/a[n]/Math.pow(radius,n-i);
    var z=[];for(i=0;i<n;i++){var angle=2*Math.PI*(i+.37)/n;z.push([1.2*Math.cos(angle),1.2*Math.sin(angle)]);}
    // Simultaneous Aberth iterations with Newton corrections, in scaled coordinates.
    for(var iteration=0;iteration<600;iteration++){
        var next=[],maxStep=0;
        for(i=0;i<n;i++){
            var pd=polynomial(scaled,z[i]);
            if(magnitude(pd.p)<1e-28){next.push(z[i]);continue;}
            if(magnitude(pd.d)<1e-28){next.push([z[i][0]+1e-8,z[i][1]+1e-8]);continue;}
            var correction=divide(pd.p,pd.d),sum=[0,0];
            for(k=0;k<n;k++)if(k!==i){var difference=[z[i][0]-z[k][0],z[i][1]-z[k][1]];if(magnitude(difference)<1e-20)difference=[1e-12,1e-12];var reciprocal=divide([1,0],difference);sum[0]+=reciprocal[0];sum[1]+=reciprocal[1];}
            var product=times(correction,sum),denominator=[1-product[0],-product[1]];
            var step=magnitude(denominator)>1e-20?divide(correction,denominator):correction;
            var value=[z[i][0]-step[0],z[i][1]-step[1]];next.push(value);maxStep=Math.max(maxStep,magnitude(step));
        }
        z=next;if(maxStep<1e-13)break;
    }
    for(i=0;i<n;i++){
        var residual=magnitude(polynomial(scaled,z[i]).p),bound=0,absz=magnitude(z[i]);
        for(k=0;k<=n;k++)bound+=Math.abs(scaled[k])*Math.pow(absz,k);
        if(!isFinite(residual)||residual>1e-8*Math.max(bound,1e-100))throw new Error("极点求解未收敛，暂不显示阻尼比。");
        z[i]=[z[i][0]*radius,z[i][1]*radius];
    }
    // Verify all roots together, rather than accepting a duplicated subset of roots.
    var reconstructed=[[1,0]];
    for(i=0;i<n;i++){var expanded=[];for(k=0;k<=reconstructed.length;k++){var term=k<reconstructed.length?times(reconstructed[k],[-z[i][0]/radius,-z[i][1]/radius]):[0,0];if(k>0){term[0]+=reconstructed[k-1][0];term[1]+=reconstructed[k-1][1];}expanded.push(term);}reconstructed=expanded;}
    for(k=0;k<=n;k++)if(magnitude([reconstructed[k][0]-scaled[k],reconstructed[k][1]])>1e-6*Math.max(1,Math.abs(scaled[k])))throw new Error("极点重构误差较大，暂不显示阻尼比。");
    return zeros.concat(z);
}
function analyze(model){
    try{
        var q=roots(model.a),poles=[],modes=[],used=[],scale=model.scale||1;
        for(var i=0;i<q.length;i++)poles.push({real:q[i][0]*scale,imag:q[i][1]*scale});
        poles.sort(function(a,b){return magnitude([a.real,a.imag])-magnitude([b.real,b.imag])||b.imag-a.imag;});
        for(i=0;i<poles.length;i++){
            if(used[i])continue;
            var p=poles[i],wn=magnitude([p.real,p.imag]),isReal=Math.abs(p.imag)<=1e-4*Math.max(wn,1e-12),pair=-1;
            if(!isReal){var distance=Infinity;for(var j=i+1;j<poles.length;j++)if(!used[j]){var delta=magnitude([poles[j].real-p.real,poles[j].imag+p.imag]);if(delta<distance){distance=delta;pair=j;}}if(pair<0||distance>1e-4*Math.max(wn,1e-12))throw new Error("共轭极点配对失败，暂不显示阻尼比。");used[pair]=true;}
            used[i]=true;
            modes.push({real:p.real,imag:isReal?0:Math.abs(p.imag),multiplicity:isReal?1:2,kind:wn===0?"积分极点":isReal?"实极点":"共轭极点",dampingRatio:wn>0?-p.real/wn:null,withinFitBand:model.fitMin===undefined?null:wn/(2*Math.PI)>=model.fitMin&&wn/(2*Math.PI)<=model.fitMax,inNyquist:model.fs?wn/(2*Math.PI)<model.fs/2:null,naturalFrequencyHz:wn/(2*Math.PI),dampedFrequencyHz:isReal?0:Math.abs(p.imag)/(2*Math.PI),stable:p.real<0});
        }
        return {method:"Continuous poles: zeta=-Re(p)/abs(p), fn=abs(p)/(2*pi)",poles:poles,modes:modes,error:null};
    }catch(e){return {modes:[],poles:[],error:String(e.message||e)};}
}
