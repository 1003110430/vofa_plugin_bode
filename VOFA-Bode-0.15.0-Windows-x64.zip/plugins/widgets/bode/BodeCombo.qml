import QtQuick 2.12
import QtQuick.Controls 2.5
ComboBox {
 id:control;implicitHeight:34;implicitWidth:130;leftPadding:10;rightPadding:28
 font.family:"Microsoft YaHei";font.pixelSize:12
 contentItem:Text{text:control.displayText;font:control.font;color:control.enabled?"#dfebf8":"#71869f";verticalAlignment:Text.AlignVCenter;elide:Text.ElideRight}
 background:Rectangle{radius:6;color:control.enabled?(control.hovered?"#162c42":"#0b1829"):"#132135";border.width:1;border.color:control.activeFocus?"#56cce4":"#2b3e56"}
 indicator:Text{x:control.width-width-10;y:(control.height-height)/2;text:"▾";color:control.enabled?"#87b8ce":"#526b80";font.pixelSize:14}
 delegate:ItemDelegate{width:control.width;text:modelData;font:control.font;highlighted:control.highlightedIndex===index;contentItem:Text{text:modelData;color:"#e0eaf7";font:control.font;verticalAlignment:Text.AlignVCenter;elide:Text.ElideRight}
 background:Rectangle{color:parent.highlighted?"#25475f":"#142438"}}
 popup:Popup{y:control.height+4;width:control.width;padding:4;implicitHeight:Math.min(280,contentItem.implicitHeight+8);contentItem:ListView{clip:true;implicitHeight:contentHeight;model:control.popup.visible?control.delegateModel:null;currentIndex:control.highlightedIndex;ScrollIndicator.vertical:ScrollIndicator{}}
 background:Rectangle{radius:7;color:"#142438";border.color:"#304963"}}
}
