.pragma library

function band(points) {
    var lo=Infinity, hi=0;
    for(var i=0;i<points.length;i++) if(points[i].valid && points[i].frequency>0) {
        lo=Math.min(lo,points[i].frequency); hi=Math.max(hi,points[i].frequency);
    }
    return hi>0?{min:lo,max:hi}:null;
}
function analyze(points,options) {
    options=options||{};
    var filtered=!!options.filterCrossings,phaseBand=Number(options.phaseHysteresis===undefined?8:options.phaseHysteresis),gainBand=Number(options.gainHysteresis===undefined ? .5 :options.gainHysteresis),coherence=Number(options.crossingCoherence===undefined ? .9 :options.crossingCoherence);
    var r={referenceDb:null,cutoffs:[],gainCrossovers:[],phaseCrossovers:[],error:null};
    if(filtered&&(!isFinite(phaseBand)||phaseBand<0||phaseBand>90||!isFinite(gainBand)||gainBand<0||gainBand>20||!isFinite(coherence)||coherence<0||coherence>1||String(options.phaseHysteresis===undefined?8:options.phaseHysteresis).trim()===""||String(options.gainHysteresis===undefined ? .5 :options.gainHysteresis).trim()===""||String(options.crossingCoherence===undefined ? .9 :options.crossingCoherence).trim()==="")){r.error="去抖门槛无效：相位0～90°，增益0～20 dB，相干性0～1。";return r;}
    var segments=[],chunk=[],last=null,i,j;
    for(i=0;i<points.length;i++){
        var source=points[i];
        if(!source.valid||!(source.frequency>0)||!isFinite(source.gainDb)||!isFinite(source.phaseDeg)||filtered&&(!isFinite(source.coherence)||source.coherence<coherence)){
            if(chunk.length)segments.push(chunk);chunk=[];last=null;continue;
        }
        var phase=source.phaseDeg;
        if(last!==null){while(phase-last>180)phase-=360;while(phase-last< -180)phase+=360;}
        chunk.push({frequency:source.frequency,gainDb:source.gainDb,phaseDeg:phase});last=phase;
    }
    if(chunk.length)segments.push(chunk);
    var reference=options.referenceDb,baseline=[];
    if(reference===undefined||reference===null||!isFinite(reference)){
        if(segments.length)for(i=0;i<Math.min(5,segments[0].length);i++)baseline.push(segments[0][i].gainDb);
        baseline.sort(function(a,b){return a-b;});reference=baseline.length?baseline[Math.floor(baseline.length/2)]:null;
    }
    r.referenceDb=reference;
    function median(values){values.sort(function(a,b){return a-b;});return values[Math.floor(values.length/2)];}
    function smooth(segment){var out=[];for(var n=0;n<segment.length;n++){var gains=[],phases=[];for(var k=Math.max(0,n-1);k<=Math.min(segment.length-1,n+1);k++){gains.push(segment[k].gainDb);phases.push(segment[k].phaseDeg);}out.push({frequency:segment[n].frequency,gainDb:n===0||n===segment.length-1?segment[n].gainDb:median(gains),phaseDeg:n===0||n===segment.length-1?segment[n].phaseDeg:median(phases)});}return out;}
    function interpolate(a,b,key,target,kind){
        var t=(target-a[key])/(b[key]-a[key]),frequency=a.frequency*Math.pow(b.frequency/a.frequency,t),gain=a.gainDb+t*(b.gainDb-a.gainDb),phase=a.phaseDeg+t*(b.phaseDeg-a.phaseDeg);
        var margin=((180+phase)%360+360)%360;if(margin>180)margin-=360;
        return {frequency:frequency,gainDb:gain,phaseDeg:phase,phaseMargin:kind==="gain"&&options.loop?margin:null,gainMargin:kind==="phase"&&options.loop?-gain:null};
    }
    function detect(segment,key,target,kind,hysteresis,persistent){
        var out=[],committed=0,runSide=0,runLength=0,candidate=null;
        function append(p){if(!out.length||Math.abs(Math.log(p.frequency/out[out.length-1].frequency))>1e-10)out.push(p);}
        for(var n=0;n<segment.length;n++){
            var b=segment[n],value=b[key]-target;
            if(n){var a=segment[n-1],va=a[key]-target;
                if(a[key]!==b[key]&&va*value<=0){var hit=interpolate(a,b,key,target,kind);if(!persistent){if(kind!=="cutoff"||b[key]<a[key])append(hit);}else if(committed)candidate=hit;}
            }
            if(!persistent)continue;
            var side=value>hysteresis?1:value< -hysteresis?-1:0;
            if(side&&side===runSide)runLength++;else{runSide=side;runLength=side?1:0;}
            if(runLength>=2&&side!==committed){if(committed&&candidate&&(kind!=="cutoff"||committed===1&&side===-1))append(candidate);committed=side;candidate=null;}
        }
        return out;
    }
    function collect(segment,persistent){
        var result={cutoffs:[],gainCrossovers:[],phaseCrossovers:[]};
        if(reference!==null)result.cutoffs=detect(segment,"gainDb",reference-3.010299956639812,"cutoff",gainBand,persistent);
        result.gainCrossovers=detect(segment,"gainDb",0,"gain",gainBand,persistent);
        var lo=Infinity,hi=-Infinity;for(var n=0;n<segment.length;n++){lo=Math.min(lo,segment[n].phaseDeg);hi=Math.max(hi,segment[n].phaseDeg);}
        for(var k=Math.ceil((-hi-180)/360);k<=Math.floor((-lo-180)/360);k++)result.phaseCrossovers=result.phaseCrossovers.concat(detect(segment,"phaseDeg",-180-360*k,"phase",phaseBand,persistent));
        return result;
    }
    var rawGain=0,rawPhase=0;
    for(i=0;i<segments.length;i++){
        var raw=collect(segments[i],false),confirmed=filtered?collect(smooth(segments[i]),true):raw;
        rawGain+=raw.gainCrossovers.length;rawPhase+=raw.phaseCrossovers.length;
        r.cutoffs=r.cutoffs.concat(confirmed.cutoffs);r.gainCrossovers=r.gainCrossovers.concat(confirmed.gainCrossovers);r.phaseCrossovers=r.phaseCrossovers.concat(confirmed.phaseCrossovers);
    }
    function sortedUnique(list){list.sort(function(a,b){return a.frequency-b.frequency;});var out=[];for(var n=0;n<list.length;n++)if(!out.length||Math.abs(Math.log(list[n].frequency/out[out.length-1].frequency))>1e-10)out.push(list[n]);return out;}
    r.cutoffs=sortedUnique(r.cutoffs);r.gainCrossovers=sortedUnique(r.gainCrossovers);r.phaseCrossovers=sortedUnique(r.phaseCrossovers);
    r.crossingDiagnostics={filtered:filtered,rawGain:rawGain,rawPhase:rawPhase,confirmedGain:r.gainCrossovers.length,confirmedPhase:r.phaseCrossovers.length};
    return r;
}
