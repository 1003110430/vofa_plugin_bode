import QtQuick 2.12
import QtQuick.Controls 2.5
Label { font.family: "Microsoft YaHei"; font.pixelSize: 13; color: "#c3d8ee" }
