// Qt 5 WorkerScript: imports are local and require no extra runtime.
Qt.include("BodeMath.js");
Qt.include("ChannelSource.js");
Qt.include("StreamingAnalysis.js");
var dataset=null,active=null,token=null,idSearch=null;
WorkerScript.onMessage=function(message){
    try{
        if(message.action==="reset"){active=null;dataset=null;token=null;idSearch=null;return;}
        if(message.action==="cancel"){if(token===message.token){active=null;token=null;idSearch=null;}return;}
        if(message.action==="capture"){
            active=null;dataset={source:message.source};token=message.token;
            active=createChunkedStreamJob(dataset.source,"capture",{});
        }else if(message.action==="identify"){
            if(!dataset)throw new Error("本次采样快照已释放，请重新读取。");
            token=message.token;idSearch={options:message.options,best:null,attempts:0};active=createChunkedStreamJob(dataset.source,"identify",message.options);
        }else if(message.action==="chunk"&&message.token===token){feedStreamChunk(active,message.text,message.finalChunk);if(message.finalChunk&&(!active.headerSeen||active.text.charAt(active.text.length-1)!=="\n")){var incomplete=new Error("快照最后一行尚未写完。");incomplete.incomplete=true;throw incomplete;}}
        else if(message.action!=="step"||message.token!==token)return;
        if(!active)return;
        var done=active.headerSeen?stepStreamJob(active,8192,25):false;
        if(done){var result={token:token,done:true,kind:active.kind,totalRows:active.lastNonEmpty,results:active.results,metadata:active.metadata,fullSpectrum:active.fullSpectrum||null};if(active.kind==="identify"&&idSearch){
                var support=identificationSupport(result.results,idSearch.options);idSearch.attempts++;
                result.metadata.frequencySupport=support;
                if(!idSearch.best||support.score>idSearch.best.metadata.frequencySupport.score||support.score===idSearch.best.metadata.frequencySupport.score&&support.training>idSearch.best.metadata.frequencySupport.training)idSearch.best=result;
                var target=Math.max(12,3*(Number(idSearch.options.autoOrder?idSearch.options.maxPoles||6:idSearch.options.poles||3)+Number(idSearch.options.autoZeros?0:idSearch.options.zeros||0)+1)),next=active.metadata.nfft*2;
                if((support.training<target||support.validation<6||result.metadata.validationUnavailableReason)&&idSearch.attempts<3&&next<=active.metadata.maxResolutionNfft){
                    idSearch.options.resolutionNfft=next;active=createChunkedStreamJob(dataset.source,"identify",idSearch.options);
                    WorkerScript.sendMessage({token:token,done:false,kind:"identify",progress:0,phase:"提高辨识频率分辨率 · FFT "+next,needChunk:true,rewind:true});return;
                }
                result=idSearch.best;result.metadata.resolutionTrials=idSearch.attempts;idSearch=null;
            }
            active=null;WorkerScript.sendMessage(result);}
        else {WorkerScript.sendMessage({token:token,done:false,kind:active.kind,progress:streamProgress(active),phase:active.statistics?"去趋势统计":"分段 FFT",needChunk:streamNeedsChunk(active),rewind:!!active.rewind});active.rewind=false;}
    }catch(e){var failed=message.token;active=null;WorkerScript.sendMessage({token:failed,error:String(e.message||e),incomplete:!!e.incomplete});}
};
