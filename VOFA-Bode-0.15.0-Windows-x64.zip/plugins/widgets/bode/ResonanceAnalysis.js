.pragma library
// Measured-FRF peak and half-power estimates. No identified model is used.
function analyze(points,options){
    options=options||{};
    var coherence=Number(options.minCoherence===undefined ? .8 :options.minCoherence),prominence=Number(options.minProminenceDb===undefined?1:options.minProminenceDb);
    var lo=Number(options.minHz||0),maximum=Number(options.maxHz||0),hi=maximum===0?Infinity:maximum;
    if((typeof options.minCoherence==="string"&&!options.minCoherence.trim())||!isFinite(maximum)||maximum<0||!isFinite(coherence)||coherence<0||coherence>1||!isFinite(prominence)||prominence<=0||!isFinite(lo)||lo<0||!(hi>lo))return {peaks:[],error:"峰区门槛无效：相干性须为0～1，最小突出度须大于0，频段上限须大于下限。"};
    var peaks=[],segments=[],chunk=[];
    function usable(p){return p.valid&&p.frequency>0&&p.frequency>=lo&&p.frequency<=hi&&isFinite(p.gainDb)&&isFinite(p.phaseDeg)&&isFinite(p.coherence)&&p.coherence>=coherence;}
    for(var i=0;i<points.length;i++){if(usable(points[i]))chunk.push(points[i]);else if(chunk.length){segments.push(chunk);chunk=[];}}
    if(chunk.length)segments.push(chunk);
    var validCount=0;
    for(var s=0;s<segments.length;s++){
        var p=segments[s],n=p.length;validCount+=n;if(n<3)continue;
        var size=1;while(size<n)size*=2;
        var tree=[],left=[],right=[],stack=[],j;
        for(i=0;i<2*size;i++)tree[i]=Infinity;
        for(i=0;i<n;i++)tree[size+i]=p[i].gainDb;
        for(i=size-1;i>0;i--)tree[i]=Math.min(tree[2*i],tree[2*i+1]);
        function minimum(a,b){var result=Infinity;a+=size;b+=size;while(a<=b){if(a%2)result=Math.min(result,tree[a++]);if(!(b%2))result=Math.min(result,tree[b--]);a=Math.floor(a/2);b=Math.floor(b/2);}return result;}
        function nearestBelow(node,a,b,ql,qr,target,reverse){
            if(b<ql||a>qr||tree[node]>target)return -1;
            if(a===b)return a;
            var mid=Math.floor((a+b)/2),first=reverse?nearestBelow(2*node+1,mid+1,b,ql,qr,target,reverse):nearestBelow(2*node,a,mid,ql,qr,target,reverse);
            return first>=0?first:reverse?nearestBelow(2*node,a,mid,ql,qr,target,reverse):nearestBelow(2*node+1,mid+1,b,ql,qr,target,reverse);
        }
        for(i=0;i<n;i++){while(stack.length&&p[stack[stack.length-1]].gainDb<=p[i].gainDb)stack.pop();left[i]=stack.length?stack[stack.length-1]:0;stack.push(i);}
        stack=[];
        for(i=n-1;i>=0;i--){while(stack.length&&p[stack[stack.length-1]].gainDb<=p[i].gainDb)stack.pop();right[i]=stack.length?stack[stack.length-1]:n-1;stack.push(i);}
        function crossing(a,b,target){var t=(target-a.gainDb)/(b.gainDb-a.gainDb);return {frequency:a.frequency*Math.pow(b.frequency/a.frequency,t),gainDb:target,phaseDeg:a.phaseDeg+t*(b.phaseDeg-a.phaseDeg)};}
        for(i=1;i<n-1;i++){
            if(!(p[i].gainDb>p[i-1].gainDb&&p[i].gainDb>=p[i+1].gainDb))continue;
            var end=i;while(end+1<n&&p[end+1].gainDb===p[i].gainDb)end++;
            if(end===n-1||p[end+1].gainDb>=p[i].gainDb)continue;
            var center=Math.floor((i+end)/2),peak=p[center],height=peak.gainDb;
            var prominent=height-Math.max(minimum(left[center],center),minimum(center,right[center]));
            if(prominent<prominence){i=end;continue;}
            var target=height-3.010299956639812,l=nearestBelow(1,0,size-1,0,center-1,target,true),r=nearestBelow(1,0,size-1,end+1,n-1,target,false);
            var f1=l>=0?crossing(p[l],p[l+1],target):null,f2=r>=0?crossing(p[r-1],p[r],target):null;
            var delta=options.referenceDb===null||options.referenceDb===undefined||!isFinite(options.referenceDb)?null:height-options.referenceDb;
            var result={frequency:peak.frequency,gainDb:height,phaseDeg:peak.phaseDeg,coherence:peak.coherence,prominenceDb:prominent,relativePeakDb:delta,relativePeakRatio:delta===null?null:Math.pow(10,delta/20),halfPowerDb:target,left:f1,right:f2,bandwidthHz:f1&&f2?f2.frequency-f1.frequency:null,dampingRatio:null,qualityFactor:null,reason:null,notes:[],segment:s};
            if(!f1||!f2)result.reason=(!f1?"左侧":"右侧")+"缺少可信的峰值−3.01 dB交点（可能受选区边界或低相干间隙限制）。";
            else{
                var maxStep=0;for(j=l;j<r;j++)maxStep=Math.max(maxStep,p[j+1].frequency-p[j].frequency);
                result.bandwidthBins=result.bandwidthHz/maxStep;
                var estimate=result.bandwidthHz/(2*result.frequency);
                if(result.bandwidthBins<4)result.reason="半功率带宽不足4个频率间隔，请提高FFT分辨率或扩大时域选区。";
                else if(!(Number(options.segments)>=4))result.reason="Welch平均不足4段，暂不输出阻尼比。";
                else if(!(estimate>0)||estimate>.2)result.reason="峰较宽，超出轻阻尼半功率近似范围（ζ_HP>0.2）。";
                else{result.dampingRatio=estimate;result.qualityFactor=result.frequency/result.bandwidthHz;if(result.bandwidthBins<8)result.notes.push("峰宽分辨率较低，仅作粗估");if(estimate>.1)result.notes.push("ζ_HP>0.1，轻阻尼近似偏差可能较大");}
            }
            peaks.push(result);i=end;
        }
    }
    // A second significant maximum above the half-power floor means unresolved modes.
    peaks.sort(function(a,b){return a.frequency-b.frequency;});
    function lower(f){var a=0,b=peaks.length;while(a<b){var mid=Math.floor((a+b)/2);if(peaks[mid].frequency<f)a=mid+1;else b=mid;}return a;}
    for(i=0;i<peaks.length;i++){var item=peaks[i];if(item.left&&item.right&&lower(item.right.frequency)-lower(item.left.frequency)>1){item.dampingRatio=null;item.qualityFactor=null;item.reason="半功率区间内存在多个显著峰，模态可能重叠，暂不输出单模态阻尼比。";}}
    peaks.sort(function(a,b){return b.prominenceDb-a.prominenceDb||b.gainDb-a.gainDb||a.frequency-b.frequency;});
    return {peaks:peaks,validCount:validCount,error:null,message:peaks.length?"半功率法假定孤立、轻阻尼模态；结果为实测频响近似，不是传递函数极点结果。":"未检出满足突出度和相干性门槛的内部共振峰；单调低通不能据此给出阻尼比。"};
}
