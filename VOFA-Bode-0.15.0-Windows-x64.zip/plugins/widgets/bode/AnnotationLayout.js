.pragma library
function frequency(f){return f>=10000?(f/1000).toFixed(2)+" kHz":f.toFixed(2)+" Hz";}
function describe(m,key){
    if(m.kind==="resonance"){
        if(key!=="gainDb")return null;
        var cfg=m.display||{},parts=[];
        if(cfg.fr)parts.push("fr "+frequency(m.frequency));
        if(cfg.peak){parts.push("峰值 Gr "+m.gainDb.toFixed(2)+" dB");if(m.relativePeakDb!==null)parts.push("ΔMr "+m.relativePeakDb.toFixed(2)+" dB / "+m.relativePeakRatio.toFixed(3)+"×");}
        if(cfg.zeta&&m.dampingRatio!==null)parts.push("ζ_HP ≈ "+m.dampingRatio.toFixed(4));
        if(cfg.bandwidth&&m.bandwidthHz!==null)parts.push("BW "+frequency(m.bandwidthHz));
        if(cfg.q&&m.qualityFactor!==null)parts.push("Q_HP ≈ "+m.qualityFactor.toFixed(3));
        if(!parts.length)return null;
        return {title:parts[0],detail:parts.slice(1).join(" · "),details:parts.slice(1)};
    }
    if(m.kind==="f1"||m.kind==="f2")return key==="gainDb"?{title:m.kind+" "+frequency(m.frequency),detail:"峰值 −3.01 dB"}:null;
    if(m.kind==="fc")return key==="gainDb"?{title:"fc "+frequency(m.frequency),detail:"G "+m.gainDb.toFixed(2)+" dB"}:null;
    if(m.kind==="fg") {
        if(key==="phaseDeg" && m.showMargin!==false && m.phaseMargin!==null && m.phaseMargin!==undefined)
            return {title:"PM "+m.phaseMargin.toFixed(2)+"°",detail:m.showFrequency===false?"相位裕度":"fg "+frequency(m.frequency)};
        if(m.showFrequency===false)return null;
        return {title:"fg "+frequency(m.frequency),detail:key==="gainDb"?"G 0.00 dB":"φ "+m.phaseDeg.toFixed(2)+"°"};
    }
    if(m.kind==="fp") {
        if(key==="gainDb" && m.showMargin!==false && m.gainMargin!==null && m.gainMargin!==undefined)
            return {title:"GM "+m.gainMargin.toFixed(2)+" dB",detail:m.showFrequency===false?"增益裕度":"fp "+frequency(m.frequency)};
        if(m.showFrequency===false)return null;
        return {title:"fp "+frequency(m.frequency),detail:"φ "+m.phaseDeg.toFixed(2)+"°"};
    }
    return null;
}
function place(px,py,w,h,area,used){
    if(w>area.right-area.left||h>area.bottom-area.top)return null;
    var xs=[px+12,px-w-12,px-w/2],ys=[py-h-12,py+12,area.top+5,area.bottom-h-5],best=null,score=Infinity;
    for(var x=area.left+5;x+w<=area.right;x+=w+8)xs.push(x);
    for(var y=area.top+5;y+h<=area.bottom;y+=h+8)ys.push(y);
    for(var i=0;i<xs.length;i++)for(var j=0;j<ys.length;j++){
        var bx=Math.max(area.left,Math.min(area.right-w,xs[i])),by=Math.max(area.top,Math.min(area.bottom-h,ys[j])),overlap=false;
        for(var k=0;k<used.length;k++){var q=used[k];if(!(bx+w+5<=q.x||q.x+q.w+5<=bx||by+h+5<=q.y||q.y+q.h+5<=by)){overlap=true;break;}}
        if(overlap)continue;
        var distance=Math.pow(bx+w/2-px,2)+Math.pow(by+h/2-py,2);
        if(px>=bx&&px<=bx+w&&py>=by&&py<=by+h)distance+=100000;
        if(distance<score){best={x:bx,y:by,w:w,h:h};score=distance;}
    }
    return best;
}
