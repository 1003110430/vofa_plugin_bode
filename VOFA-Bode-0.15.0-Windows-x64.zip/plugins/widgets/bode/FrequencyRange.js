.pragma library
function fraction(f,lo,hi){return Math.max(0,Math.min(1,Math.log(f/lo)/Math.log(hi/lo)));}
function frequency(t,lo,hi){return lo*Math.pow(hi/lo,Math.max(0,Math.min(1,t)));}
function normalize(minimum,maximum,lo,hi){
    if(!(lo>0)||!(hi>lo)||!isFinite(lo)||!isFinite(hi))return null;
    if(!(minimum>0)||!(maximum>minimum)||!isFinite(minimum)||!isFinite(maximum))return null;
    var a=fraction(minimum,lo,hi),b=fraction(maximum,lo,hi),span=.001;
    if(b-a<span){var center=(a+b)/2;a=Math.max(0,Math.min(1-span,center-span/2));b=a+span;}
    return {min:frequency(a,lo,hi),max:frequency(b,lo,hi)};
}
function drag(minimum,maximum,lo,hi,kind,delta){
    var view=normalize(minimum,maximum,lo,hi);if(!view||!isFinite(delta))return null;
    var a=fraction(view.min,lo,hi),b=fraction(view.max,lo,hi),span=.001;
    if(kind==="left")a=Math.max(0,Math.min(b-span,a+delta));
    else if(kind==="right")b=Math.max(a+span,Math.min(1,b+delta));
    else{var shift=Math.max(-a,Math.min(1-b,delta));a+=shift;b+=shift;}
    return {min:frequency(a,lo,hi),max:frequency(b,lo,hi)};
}

// Manual display band. Zero/blank selects the corresponding FFT boundary.
function manual(minimumText,maximumText,lo,hi){
    var a=String(minimumText).trim(),b=String(maximumText).trim(),minimum=a===""?0:Number(a),maximum=b===""?0:Number(b);
    if(!isFinite(minimum)||!isFinite(maximum)||minimum<0||maximum<0)return {error:"频率须为非负数；0表示FFT边界。"};
    if(!(lo>0)||!(hi>lo)||!isFinite(lo)||!isFinite(hi))return {error:"请先读取有效频响数据。"};
    if(minimum===0)minimum=lo;if(maximum===0)maximum=hi;
    if(!(minimum<maximum))return {error:"起始频率必须小于终止频率。"};
    if(minimum<lo||maximum>hi)return {error:"频率超出FFT范围："+lo.toPrecision(5)+"～"+hi.toPrecision(5)+" Hz。"};
    return {min:minimum,max:maximum,error:null};
}
