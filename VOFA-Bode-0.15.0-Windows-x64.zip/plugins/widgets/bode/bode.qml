import QtQuick 2.12
import QtQuick.Window 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtQuick.Dialogs 1.3
import Qt.labs.folderlistmodel 2.1
import MyModules 1.0
import mine.qt.FileIO 1.0
import "BodeMath.js" as BodeMath
import "ChannelSource.js" as ChannelSource
import "BodeFeatures.js" as Features
import "Identification.js" as Identification
import "PlotLayout.js" as PlotLayout
import "IdentificationDisplay.js" as IdentificationDisplay
import "ModalAnalysis.js" as ModalAnalysis
import "ModelParameters.js" as ModelParameters
import "ResonanceAnalysis.js" as Resonance
import "ParameterAnnotations.js" as Annotations
import "FrequencyRange.js" as FrequencyRange
import "CurveDenoise.js" as CurveDenoise

ResizableRectangle {
    id: root
    property string path: "bode"
    property string frequencyRangeMessage:""
    property bool curveDenoise:false
    property int curveDenoiseStrength:1
    property var displayPoints:result?(curveDenoise?CurveDenoise.smooth(result.points,curveDenoiseStrength):result.points):[]
    property real settingsHeight:330
    property real settingsFontScale:1
    property bool settingsCollapsed:false
    property bool idNoiseAssist:true
    property string idCoherence:"0.35"
    onIdNoiseAssistChanged:clearModel()
    onIdCoherenceChanged:clearModel()
    property var plotRatios: [.45,.4,.15]
    property bool identificationOpen: false
    onIdentificationOpenChanged:if(identificationOpen){resonanceOpen=false;advancedOpen=false;settingsCollapsed=false;}
    property bool showModel: true
    property bool idStable: true
    property bool idRobust: true
    property bool idDetrend: false
    property bool idValidate: true
    property string idValidationMode:"frequency"
    onIdValidationModeChanged:clearModel()
    property bool modelFullRange:true
    onModelFullRangeChanged:refreshModelCurve()
    onPlotMinChanged:refreshModelCurve()
    onPlotMaxChanged:refreshModelCurve()
    property int idPoles: 3
    property int idZeros: 0
    property bool idAutoOrder: false
    property bool idAutoZeros: false
    property int idMaxPoles: 6
    property var identificationJob: null
    property int identificationGeneration: 0
    onIdAutoOrderChanged: clearModel()
    onIdAutoZerosChanged: clearModel()
    onIdMaxPolesChanged: clearModel()
    property string idTrim: "0"
    property string idDelay: "0"
    property string idMin: "0"
    property string idMax: "0"
    property var capturedPairs: null
    property var identifiedModel: null
    property var candidateModels: []
    property var candidateSummaries: []
    property var comparisonRows: candidateSummaries.length?candidateSummaries:IdentificationDisplay.comparisonRows(identifiedModel)
    property var modelPoints: []
    property bool identifying: false
    property string identificationStatus: "选取宽带激励的稳态区间，先读取数据，再辨识。"
    onIdPolesChanged: clearModel()
    onIdZerosChanged: clearModel()
    onIdTrimChanged: clearModel()
    onIdDelayChanged: clearModel()
    onIdMinChanged: clearModel()
    onIdMaxChanged: clearModel()
    onIdStableChanged: clearModel()
    onIdRobustChanged: clearModel()
    onIdDetrendChanged: clearModel()
    onIdValidateChanged: clearModel()
    property var hub: typeof datahub_global !== "undefined" ? datahub_global : null
    property var selectionBar: typeof sys_manager !== "undefined" && sys_manager.parent ? sys_manager.parent.bar : null
    property bool followSelection: true
    property bool adaptiveFFT: true
    property bool allSegments: true
    property bool autoFrequency: true
    property bool followAuto: true
    property bool useDeltaT: false
    property bool crossingFilter:true
    property bool annotationAllCrossings:false
    property string crossingPhaseBand:"8"
    property string crossingGainBand:"0.5"
    property string crossingCoherence:"0.9"
    onCrossingFilterChanged:updateFeatures()
    onAnnotationAllCrossingsChanged:rebuildMarks()
    onCrossingPhaseBandChanged:updateFeatures()
    onCrossingGainBandChanged:updateFeatures()
    onCrossingCoherenceChanged:updateFeatures()
    property bool showParameters: true
    property var annotationOptions:Annotations.defaults()
    onAnnotationOptionsChanged:rebuildMarks()
    property bool resonanceOpen:false
    onResonanceOpenChanged:if(resonanceOpen){identificationOpen=false;advancedOpen=false;settingsCollapsed=false;}
    property var resonanceResult:null
    property int resonanceIndex:0
    onResonanceIndexChanged:rebuildMarks()
    property string resonanceMinHz:"0"
    property string resonanceMaxHz:"0"
    property string resonanceProminenceDb:"1"
    property string resonanceCoherence:"0.8"
    onResonanceMinHzChanged:updateResonance()
    onResonanceMaxHzChanged:updateResonance()
    onResonanceProminenceDbChanged:updateResonance()
    onResonanceCoherenceChanged:updateResonance()
    property bool advancedOpen: false
    onAdvancedOpenChanged:if(advancedOpen){identificationOpen=false;resonanceOpen=false;}
    property bool loopMode: false
    property string referenceDbText: ""
    property bool detached: false
    property alias detachedWindow: standaloneWindow
    property var features: null
    property var marks: []
    property string selectionText: ""
    property string capturedSelection: ""
    property var channelLabels: []
    property int preferredInputIndex: 0
    property int preferredOutputIndex: 1
    property var result: null
    property string statusText: "选择输入、输出，拖动底部选择条选中数据，再点击“读取并计算”。"
    property bool busy: false
    property bool automatic: false
    property real cursorFrequency: 0
    property bool cursorPinned:false
    property real plotMin: 1
    property real plotMax: 1000
    property string lastExport: ""
    property string inputName: ""
    property string outputName: ""
    property string analysisLimitText: "0"
    property string exportTimeoutText: "180"
    property string workerToken: ""
    property string workerPurpose: ""
    property var workerRequest: null
    property int workerSequence: 0
    property string capturedText: ""
    property real transferOffset: 0
    onAnalysisLimitTextChanged:clearResult()
    onExportTimeoutTextChanged:if(busy)cancelCapture()
    property string instanceToken: Date.now().toString() + "-" + Math.floor(Math.random() * 1000000)
    property int captureGeneration: 0
    property var pendingCapture: null
    property var retiredSnapshots: []
    property Item ref: Loader {
        active: false
        sourceComponent: Component { Item {
            property var ref_preferences: root
            property var ref_input: inputChoice
            property var ref_output: outputChoice
            property var ref_fs: sampleRate
            property var ref_nfft: fftChoice
            property var ref_averages: averageChoice
            property var ref_fmin: frequencyMin
            property var ref_fmax: frequencyMax
            property var ref_coherence: coherenceThreshold
        } }
    }
    width: g_settings.applyHScale(1020)
    height: g_settings.applyVScale(740)
    minimumWidth: g_settings.applyHScale(820)
    minimumHeight: g_settings.applyVScale(620)
    full_parent_enabled: true
    color: "#0b1423"
    border.color: "#2c4662"
    border.width: 1
    FileIO { id: io }
    FolderListModel {
        id:snapshotFiles;folder:"file:///"+sys_manager.data_path+"/bode"
        nameFilters:["snapshot-"+root.instanceToken+"-*.csv"];showDirs:false;showDotAndDotDot:false
    }
    WorkerScript {id:analysisWorker;source:"BodeWorker.js";onMessage:root.receiveAnalysis(messageObject)}

    MyMenu {
        id: contextMenu
        MyMenuItem {text:"解除读数锁定";onTriggered:root.cursorPinned=false}
        MyMenuItem { text: "Auto · 自动缩放"; onTriggered: root.fitAll() }
        MyMenuItem { text: root.detached ? "返回画布" : "独立窗口"; onTriggered: { if(root.detached) root.returnEmbedded(); else root.openDetached(); } }
        MyMenuItem { text: "显示 / 隐藏关键参数"; onTriggered: root.showParameters=!root.showParameters }
        FillParentMenu { target: root }
        DeleteMenuItem { target: root }
    }
    Connections { target: root.mouse; onClicked: { if (mouse.button === Qt.RightButton) contextMenu.popup(); } }
    Connections {
        target: root.hub; ignoreUnknownSignals: true
        onNum_lines_changed: root.refreshChannels()
        onName_changed: root.refreshChannels()
        onDatas_loaded: { root.clearResult(); root.refreshChannels(); }
    }
    Component.onCompleted: { refreshChannels(); refreshSelection(); }
    Timer { interval: 1500; running: root.visible || root.detached; repeat: true; onTriggered: root.refreshChannels() }
    Timer { interval: 5000; running: root.automatic && (root.visible || root.detached); repeat: true; onTriggered: root.capture() }
    Timer { interval: 350; running: root.pendingCapture !== null && root.workerPurpose!=="capture"; repeat: true; onTriggered: root.pollCapture() }
    Timer { interval: 5000; running: root.visible || root.detached; repeat: true; onTriggered: root.cleanSnapshots() }

    Timer { interval: 250; running: root.visible || root.detached; repeat: true; onTriggered: root.refreshSelection() }
    Timer {interval:15;running:root.identificationJob!==null;repeat:true;onTriggered:root.advanceOrderSearch()}
    Window {
        id: standaloneWindow; title: "VOFA+ · 伯德图"; color: "#0b1423"
        width: 1140; height: 900; minimumWidth: 900; minimumHeight: 620
        visible: root.detached; flags: Qt.Window
        onClosing: { close.accepted=false; root.returnEmbedded(); }
    }
    Item {
        id: panel
        parent: root.detached ? standaloneWindow.contentItem : root
        anchors.fill: parent
        Rectangle { anchors.fill: parent; color: "#0b1423" }
        Popup {
            id:assessmentPopup;parent:panel
            width:Math.min(610,panel.width-40);height:Math.min(510,panel.height-60)
            x:(panel.width-width)/2;y:(panel.height-height)/2;padding:0
            closePolicy:Popup.CloseOnEscape|Popup.CloseOnPressOutside
            contentItem:IdentificationAssessment {loopMode:root.loopMode;allowExpand:false;model:root.identifiedModel;candidates:root.comparisonRows;onCandidateChosen:root.selectCandidate(poles,zeros)}
        }
        Popup {
            id:parameterPopup;objectName:"bode-parameter-popup";parent:panel
            width:Math.min(660,panel.width-40);height:parameterBody.implicitHeight+24;x:(panel.width-width)/2;y:Math.max(10,(panel.height-height)/2);padding:12
            closePolicy:Popup.CloseOnEscape|Popup.CloseOnPressOutside
            background:Rectangle{color:"#102238";radius:9;border.color:"#35516a"}
            ColumnLayout {id:parameterBody;anchors.fill:parent;spacing:8
                BodeLabel {text:"图上参数 · 独立显示配置";font.bold:true;font.pixelSize:14}
                RowLayout {BodeCheckBox{text:"总开关";checked:root.showParameters;onToggled:root.showParameters=checked}Item{Layout.fillWidth:true}BodeButton{text:"全部开启";onClicked:root.setAllAnnotations(true)}BodeButton{text:"全部关闭";onClicked:root.setAllAnnotations(false)}BodeButton{text:"完成";onClicked:parameterPopup.close()}}
                GridLayout {columns:3;Layout.fillWidth:true;columnSpacing:8;rowSpacing:4
                    Repeater {model:[{key:"fc",label:"截止频率 fc"},{key:"fg",label:"0 dB穿越 fg"},{key:"fp",label:"−180°穿越 fp",loopOnly:true},{key:"pm",label:"相位裕度 PM",loopOnly:true},{key:"gm",label:"增益裕度 GM",loopOnly:true},{key:"fr",label:"谐振频率 fr"},{key:"peak",label:"谐振峰值 Gr / ΔMr"},{key:"zeta",label:"实测阻尼 ζ_HP"},{key:"halfPower",label:"半功率点 f1 / f2"},{key:"bandwidth",label:"半功率带宽 BW"},{key:"q",label:"峰宽品质因数 Q_HP"},{key:"zeroDb",label:"0 dB参考线"},{key:"minus180",label:"−180°参考线"}]
                        BodeCheckBox {objectName:"bode-annotation-"+modelData.key;Layout.fillWidth:true;text:modelData.label;enabled:!modelData.loopOnly||root.loopMode;checked:!!root.annotationOptions[modelData.key];onToggled:root.setAnnotationOption(modelData.key,checked)}
                    }
                }
                RowLayout {spacing:6
                    BodeCheckBox{text:"穿越标注去抖";checked:root.crossingFilter;onToggled:root.crossingFilter=checked}
                    BodeLabel{text:"相位±";font.pixelSize:10}BodeField{Layout.preferredWidth:45;enabled:root.crossingFilter;text:root.crossingPhaseBand;onTextEdited:root.crossingPhaseBand=text}BodeLabel{text:"°";font.pixelSize:10}
                    BodeLabel{text:"增益±";font.pixelSize:10}BodeField{Layout.preferredWidth:45;enabled:root.crossingFilter;text:root.crossingGainBand;onTextEdited:root.crossingGainBand=text}BodeLabel{text:"dB";font.pixelSize:10}
                    BodeLabel{text:"相干性≥";font.pixelSize:10}BodeField{Layout.preferredWidth:50;enabled:root.crossingFilter;text:root.crossingCoherence;onTextEdited:root.crossingCoherence=text}
                }
                BodeCheckBox{text:"显示全部确认穿越（关闭时仅标主要点）";checked:root.annotationAllCrossings;onToggled:root.annotationAllCrossings=checked}
                BodeLabel{objectName:"bode-crossing-status";Layout.fillWidth:true;wrapMode:Text.Wrap;font.pixelSize:10;color:"#aac6d9";text:root.crossingStatus()}
                BodeLabel {Layout.fillWidth:true;wrapMode:Text.Wrap;font.pixelSize:10;color:"#87a4be";text:"裕度仅在开环模式有效。谐振和半功率标注使用实测伯德图，无需辨识模型；不满足条件时不会显示阻尼数值。显示选项可随布局保存。"}
            }
        }
        ColumnLayout {
            anchors.fill: parent; anchors.margins: 18; spacing: 10
            RowLayout {
                Layout.fillWidth:true;spacing:12
                Rectangle {width:4;height:30;radius:2;color:"#58cce4"}
                Column {
                    spacing:1
                    BodeLabel {text:"BODE";font.pixelSize:23;font.bold:true;color:"#edf5ff"}
                    BodeLabel {text:"频率响应分析";font.pixelSize:10;color:"#7893af"}
                }
                Rectangle {Layout.leftMargin:6;implicitWidth:88;implicitHeight:24;radius:12;color:"#142b3d";border.color:"#23485b";BodeLabel{anchors.centerIn:parent;text:"H1 / WELCH";font.pixelSize:10;color:"#80cddd"}}
                Item {Layout.fillWidth:true}
                BodeButton {text:"解除读数";visible:root.cursorPinned;onClicked:root.cursorPinned=false}
                BodeButton {text:root.settingsCollapsed?"展开设置":"收起设置";onClicked:root.settingsCollapsed=!root.settingsCollapsed}
                BodeButton {text:"A−";implicitWidth:40;enabled:root.settingsFontScale>.81;onClicked:root.settingsFontScale=Math.max(.8,Math.round((root.settingsFontScale-.1)*10)/10)}
                BodeLabel {text:Math.round(root.settingsFontScale*100)+"%";font.pixelSize:11;color:"#8fa8c3"}
                BodeButton {text:"A+";implicitWidth:40;enabled:root.settingsFontScale<1.39;onClicked:root.settingsFontScale=Math.min(1.4,Math.round((root.settingsFontScale+.1)*10)/10)}
                BodeButton {text:root.detached?"返回画布":"独立窗口";onClicked:{if(root.detached)root.returnEmbedded();else root.openDetached();}}
            }
            Flickable {
                id:settingsScroll;objectName:"bode-settings-scroll"
                visible:!root.settingsCollapsed;Layout.fillWidth:true
                Layout.minimumHeight:90;Layout.maximumHeight:Math.max(90,panel.height-468)
                Layout.preferredHeight:Math.max(90,Math.min(root.settingsHeight,panel.height-468))
                contentWidth:width;contentHeight:settingsBody.implicitHeight*root.settingsFontScale
                clip:true;boundsBehavior:Flickable.StopAtBounds
                ScrollBar.vertical:ScrollBar {policy:ScrollBar.AsNeeded}
                ColumnLayout {
                    id:settingsBody;objectName:"bode-settings-body"
                    width:(settingsScroll.width-12)/root.settingsFontScale
                    scale:root.settingsFontScale;transformOrigin:Item.TopLeft;spacing:10
            Rectangle {
                Layout.fillWidth:true;implicitHeight:sourceControls.implicitHeight+24;radius:10;color:"#111f32";border.color:"#21354e"
                ColumnLayout {
                    id:sourceControls;anchors.fill:parent;anchors.margins:12;spacing:10
                    RowLayout {
                        Layout.fillWidth:true;spacing:10
                        BodeLabel {text:"输入 X";font.pixelSize:11;color:"#8fa8c3"}
                        BodeCombo {id:inputChoice;Layout.fillWidth:true;model:root.channelLabels;onActivated:{root.preferredInputIndex=currentIndex;root.clearResult();}}
                        BodeLabel {text:"→";font.pixelSize:18;color:"#527c99";Layout.leftMargin:4;Layout.rightMargin:4}
                        BodeLabel {text:"输出 Y";font.pixelSize:11;color:"#8fa8c3"}
                        BodeCombo {id:outputChoice;Layout.fillWidth:true;model:root.channelLabels;currentIndex:1;onActivated:{root.preferredOutputIndex=currentIndex;root.clearResult();}}
                        BodeButton {text:"刷新";implicitWidth:60;onClicked:root.refreshChannels()}
                    }
                    RowLayout {
                        Layout.fillWidth:true;spacing:10
                        BodeLabel {text:"采样率";font.pixelSize:11;color:"#8fa8c3"}
                        BodeField {id:sampleRate;Layout.preferredWidth:102;placeholderText:root.useDeltaT?"跟随 Δt":"实际采样率";enabled:!root.useDeltaT;selectByMouse:true;onTextEdited:root.clearResult()}
                        BodeLabel {text:"Hz";font.pixelSize:11;color:"#627f9d"}
                        BodeLabel {text:root.adaptiveFFT?"FFT 上限":"FFT 点数";font.pixelSize:11;color:"#8fa8c3";Layout.leftMargin:8}
                        BodeCombo {id:fftChoice;Layout.preferredWidth:90;model:[256,512,1024,2048,4096,8192,16384];currentIndex:4;onActivated:root.clearResult()}
                        BodeLabel {text:"相干性 ≥";font.pixelSize:11;color:"#8fa8c3";Layout.leftMargin:8}
                        BodeField {id:coherenceThreshold;Layout.preferredWidth:64;text:"0.8";selectByMouse:true;onTextEdited:root.clearResult()}
                        Item {Layout.fillWidth:true}
                        BodeCombo {Layout.preferredWidth:205;model:["普通传递函数 H","开环环路 L · 显示裕度"];currentIndex:root.loopMode?1:0;onActivated:{root.loopMode=currentIndex===1;root.updateFeatures();}}
                    }
                }
            }
            RowLayout {
                Layout.fillWidth:true;spacing:8
                BodeButton {text:root.busy?"正在计算…":"读取并计算";primary:true;enabled:!root.busy&&!root.identifying;onClicked:root.capture()}
                BodeButton {text:"取消读取";visible:root.busy;onClicked:root.cancelCapture()}
                BodeButton {text:"Auto";implicitWidth:66;onClicked:root.fitAll()}
                BodeButton {text:"导出 CSV";enabled:root.result!==null;onClicked:saveDialog.open()}
                BodeButton {text:"传递函数辨识";checked:root.identificationOpen;onClicked:{root.identificationOpen=!root.identificationOpen;}}
                BodeButton {text:"谐振 / 阻尼";checked:root.resonanceOpen;onClicked:root.resonanceOpen=!root.resonanceOpen}
                BodeButton {text:"清空";implicitWidth:60;onClicked:{root.automatic=false;root.clearResult();}}
                Item {Layout.fillWidth:true}
                BodeButton {text:"图上参数 ▾";checked:root.showParameters;onClicked:parameterPopup.open()}
                BodeButton {text:root.advancedOpen?"收起设置 ▴":"参数设置 ▾";checked:root.advancedOpen;onClicked:{root.advancedOpen=!root.advancedOpen;}}
            }
            RowLayout {
                Layout.fillWidth:true;spacing:9
                BodeCheckBox {objectName:"bode-curve-denoise";text:"曲线降噪";checked:root.curveDenoise;onToggled:root.curveDenoise=checked}
                BodeCombo {objectName:"bode-curve-denoise-strength";Layout.preferredWidth:110;model:["轻度","中度","强度"];enabled:root.curveDenoise;currentIndex:Math.max(0,Math.min(2,root.curveDenoiseStrength));onActivated:root.curveDenoiseStrength=currentIndex}
                BodeLabel {Layout.fillWidth:true;elide:Text.ElideRight;font.pixelSize:10;color:root.curveDenoise?"#f4ce87":"#7895b0";text:root.curveDenoise?"仅平滑幅相显示；标注、阻尼、辨识与CSV保留原始频响。强平滑可能削弱窄峰。":"关闭即显示原始幅相；可随时切换对比，无需重新采集。"}
            }
            Rectangle {
                visible:root.advancedOpen;Layout.fillWidth:true;implicitHeight:advancedControls.implicitHeight+20;radius:9;color:"#101e30";border.color:"#21354e"
                ColumnLayout {
                    id:advancedControls;anchors.fill:parent;anchors.margins:10;spacing:7
                    RowLayout {
                        Layout.fillWidth:true;spacing:8
                        BodeLabel {text:"平均段数";font.pixelSize:11;color:"#8fa8c3"}
                        BodeCombo {id:averageChoice;enabled:!root.allSegments;Layout.preferredWidth:70;model:[2,4,8,16,32,64];currentIndex:2;onActivated:root.clearResult()}
                        BodeLabel {text:"通带参考 dB";font.pixelSize:11;color:"#8fa8c3"}
                        BodeField {Layout.preferredWidth:110;placeholderText:"自动低频参考";text:root.referenceDbText;selectByMouse:true;onTextEdited:{root.referenceDbText=text;root.updateFeatures();}}
                        Item {Layout.fillWidth:true}
                    }
                    RowLayout {
                        spacing:14
                        BodeCheckBox {text:"跟随底部选区";checked:root.followSelection;onToggled:{root.followSelection=checked;root.clearResult();}}
                        BodeCheckBox {text:"自适应 FFT";checked:root.adaptiveFFT;onToggled:{root.adaptiveFFT=checked;root.clearResult();}}
                        BodeCheckBox {text:"全部分段";checked:root.allSegments;onToggled:{root.allSegments=checked;root.clearResult();}}
                        BodeCheckBox {text:"采样率跟随 Δt";checked:root.useDeltaT;onToggled:{root.useDeltaT=checked;root.clearResult();}}
                    }
                    RowLayout {
                        spacing:14
                        BodeCheckBox {text:"持续 Auto";checked:root.followAuto;onToggled:{root.followAuto=checked;if(checked)root.fitAll();}}
                        BodeCheckBox {text:"每 5 秒更新";checked:root.automatic;onToggled:{root.automatic=checked;if(checked)root.capture();}}
                    }
                    RowLayout {
                        spacing:8
                        BodeLabel {text:"分析点数上限";font.pixelSize:11}
                        BodeField {Layout.preferredWidth:120;text:root.analysisLimitText;onTextEdited:root.analysisLimitText=text}
                        BodeLabel {text:"0 = 不限制；限制时取选区末尾";font.pixelSize:10;color:"#829bb4"}
                        BodeLabel {text:"导出等待 s";font.pixelSize:11}
                        BodeField {Layout.preferredWidth:70;text:root.exportTimeoutText;onTextEdited:root.exportTimeoutText=text}
                        Item {Layout.fillWidth:true}
                    }
                }
            }
            Rectangle {
                id:resonancePane;objectName:"bode-resonance-panel";visible:root.resonanceOpen;Layout.fillWidth:true;implicitHeight:resonanceControls.implicitHeight+24;radius:9;color:"#10283a";border.color:"#34616c"
                ColumnLayout {id:resonanceControls;anchors.fill:parent;anchors.margins:12;spacing:8
                    RowLayout {Layout.fillWidth:true;BodeLabel{text:"实测谐振 / 半功率阻尼";font.bold:true;color:"#86e4d5"}Item{Layout.fillWidth:true}BodeButton{text:"标注配置";onClicked:parameterPopup.open()}}
                    RowLayout {spacing:7
                        BodeLabel{text:"峰区 Hz";font.pixelSize:11}BodeField{Layout.preferredWidth:70;text:root.resonanceMinHz;onTextEdited:root.resonanceMinHz=text}BodeLabel{text:"～"}BodeField{Layout.preferredWidth:70;text:root.resonanceMaxHz;onTextEdited:root.resonanceMaxHz=text}
                        BodeLabel{text:"突出度 ≥";font.pixelSize:11}BodeField{Layout.preferredWidth:55;text:root.resonanceProminenceDb;onTextEdited:root.resonanceProminenceDb=text}BodeLabel{text:"dB";font.pixelSize:10}
                        BodeLabel{text:"相干性 ≥";font.pixelSize:11}BodeField{Layout.preferredWidth:60;text:root.resonanceCoherence;onTextEdited:root.resonanceCoherence=text}BodeLabel{text:"0 Hz = 自动";font.pixelSize:10;color:"#87a4be"}
                    }
                    RowLayout {Layout.fillWidth:true
                        BodeCombo {objectName:"bode-resonance-choice";Layout.fillWidth:true;model:root.resonanceLabels();enabled:root.resonanceResult&&root.resonanceResult.peaks.length>0;currentIndex:root.resonanceIndex;onActivated:root.resonanceIndex=currentIndex}
                        BodeButton{text:"定位峰";enabled:root.selectedResonance()!==null;onClicked:root.focusResonance()}
                    }
                    GridLayout {columns:3;Layout.fillWidth:true;columnSpacing:8;rowSpacing:6
                        Repeater {model:6;Rectangle{Layout.fillWidth:true;implicitHeight:52;radius:6;color:"#142f41";Column{anchors.left:parent.left;anchors.leftMargin:10;anchors.verticalCenter:parent.verticalCenter;spacing:4
                            BodeLabel{text:["谐振频率 fr","绝对峰值 Gr","相对参考峰高 ΔMr","实测阻尼 ζ_HP","半功率带宽 BW","品质因数 Q_HP"][index];font.pixelSize:10;color:"#8daebb"}
                            BodeLabel{objectName:"bode-resonance-value-"+index;text:root.resonanceMetric(index);font.pixelSize:16;font.bold:true;color:"#a4eadb"}
                        }}}
                    }
                    BodeLabel{objectName:"bode-resonance-status";Layout.fillWidth:true;wrapMode:Text.Wrap;text:root.resonanceStatus();font.pixelSize:11;color:"#c4dce5"}
                }
            }
            Rectangle {
                id:identificationPane
                objectName:"bode-identification"
                property bool wide:width>=1000
                visible:root.identificationOpen;Layout.fillWidth:true;implicitHeight:idControls.implicitHeight+20;radius:9;color:"#122439";border.color:"#35516a"
                GridLayout {
                    id:idControls;anchors.fill:parent;anchors.margins:10;columns:identificationPane.wide?2:1;columnSpacing:14;rowSpacing:0
                    ColumnLayout {
                        Layout.fillWidth:true;Layout.minimumWidth:640;Layout.preferredWidth:670;spacing:7
                    RowLayout {
                        spacing:7
                        BodeLabel {text:"连续域 G(s)";color:"#f3c86e";font.bold:true}
                        BodeLabel {text:"极点";font.pixelSize:11}
                        BodeCombo {Layout.preferredWidth:55;enabled:!root.idAutoOrder;model:[1,2,3,4,5,6];currentIndex:root.idPoles-1;onActivated:root.idPoles=currentIndex+1}
                        BodeLabel {text:"零点";font.pixelSize:11}
                        BodeCombo {Layout.preferredWidth:55;enabled:!(root.idAutoOrder&&root.idAutoZeros);model:[0,1,2,3,4,5,6];currentIndex:root.idZeros;onActivated:root.idZeros=currentIndex}
                        BodeLabel {text:"已知延迟 ms";font.pixelSize:11}
                        BodeField {Layout.preferredWidth:62;text:root.idDelay;onTextEdited:root.idDelay=text}
                        BodeLabel {text:"频段 Hz";font.pixelSize:11}
                        BodeField {Layout.preferredWidth:65;text:root.idMin;onTextEdited:root.idMin=text}
                        BodeLabel {text:"～"}
                        BodeField {Layout.preferredWidth:65;text:root.idMax;onTextEdited:root.idMax=text}
                        BodeButton {text:"全部频段";implicitWidth:75;onClicked:{root.idMin="0";root.idMax="0";}}
                        Item {Layout.fillWidth:true}
                    }
                    RowLayout {
                        spacing:9
                        BodeCheckBox {text:"自动选阶";checked:root.idAutoOrder;onToggled:root.idAutoOrder=checked}
                        BodeLabel {text:"极点上限";font.pixelSize:11}
                        BodeCombo {Layout.preferredWidth:55;enabled:root.idAutoOrder;model:[1,2,3,4,5,6];currentIndex:root.idMaxPoles-1;onActivated:root.idMaxPoles=currentIndex+1}
                        BodeCheckBox {text:"同时搜索零点";enabled:root.idAutoOrder;checked:root.idAutoZeros;onToggled:root.idAutoZeros=checked}
                        BodeLabel {text:"验证误差接近时优先简单模型";font.pixelSize:10;color:"#829bb4"}
                        Item {Layout.fillWidth:true}
                    }
                    RowLayout {
                        spacing:9
                        BodeCheckBox {text:"稳定模型";checked:root.idStable;onToggled:root.idStable=checked}
                        BodeCheckBox {text:"稳健加权";checked:root.idRobust;onToggled:root.idRobust=checked}
                        BodeCheckBox {text:"去线性趋势";checked:root.idDetrend;onToggled:root.idDetrend=checked}
                        BodeCheckBox {text:"留出验证";enabled:!root.idAutoOrder;checked:root.idValidate||root.idAutoOrder;onToggled:if(!root.idAutoOrder)root.idValidate=checked}
                        BodeLabel {text:"剔除起始 %";font.pixelSize:11}
                        BodeField {Layout.preferredWidth:52;text:root.idTrim;onTextEdited:root.idTrim=text}
                        Item {Layout.fillWidth:true}
                    }
                    RowLayout {
                        spacing:8
                        BodeButton {text:root.identifying?"辨识中…":"开始辨识";primary:true;enabled:root.capturedPairs!==null&&!root.busy&&!root.identifying;onClicked:root.identify()}
                        BodeButton {text:"取消";visible:root.identifying;onClicked:{root.clearModel();root.identificationStatus="已取消辨识。";}}
                        BodeCheckBox {text:"绘制模型 · 金色虚线";checked:root.showModel;onToggled:{root.showModel=checked;if(root.followAuto)root.fitAll();}}
                        BodeCheckBox {text:"全图预测";checked:root.modelFullRange;onToggled:root.modelFullRange=checked}
                        BodeButton {text:"导出模型";enabled:root.identifiedModel!==null;onClicked:modelDialog.open()}
                        BodeButton {text:"评估与对比";visible:!identificationPane.wide;onClicked:assessmentPopup.open()}
                        BodeLabel {text:"去直流 / Hann / 相干性筛选";font.pixelSize:10;color:"#829bb4"}
                    }
                    RowLayout {
                        spacing:8
                        BodeCombo {Layout.preferredWidth:185;model:["频点留出 · 适合扫频","前70/后30 · 稳态宽带"];currentIndex:root.idValidationMode==="time"?1:0;onActivated:root.idValidationMode=currentIndex===1?"time":"frequency"}
                        BodeCheckBox {text:"含噪优化";checked:root.idNoiseAssist;onToggled:root.idNoiseAssist=checked}
                        BodeLabel {text:"辨识相干性 ≥";font.pixelSize:11}
                        BodeField {Layout.preferredWidth:65;text:root.idCoherence;onTextEdited:root.idCoherence=text}
                        BodeLabel {text:"独立于测量门槛 · 弱相干频点降权";font.pixelSize:10;color:"#829bb4"}
                    }
                    BodeLabel {Layout.fillWidth:true;text:root.identifiedModel?root.identificationSummary():root.identificationStatus;wrapMode:Text.Wrap;font.pixelSize:11;color:"#b5cce0"}
                    TransferFunctionView {visible:root.identifiedModel!==null;Layout.fillWidth:true;model:root.identifiedModel}
                    }
                    IdentificationAssessment {
                        visible:identificationPane.wide;Layout.fillWidth:true;Layout.fillHeight:true;Layout.preferredWidth:350;Layout.minimumWidth:300
                        loopMode:root.loopMode;model:root.identifiedModel;candidates:root.comparisonRows;onCandidateChosen:root.selectCandidate(poles,zeros);onExpandRequested:assessmentPopup.open()
                    }
                }
            }
            BodeLabel {Layout.fillWidth:true;text:root.selectionText;color:"#708ba7";font.pixelSize:10;elide:Text.ElideRight;maximumLineCount:1}
            RowLayout {
                Layout.fillWidth:true;spacing:7
                Rectangle {width:6;height:6;radius:3;color:root.busy?"#58cce4":root.result?"#5ed9ad":"#6583a1"}
                BodeLabel {Layout.fillWidth:true;text:root.statusText;color:"#a8bfd7";wrapMode:Text.Wrap;font.pixelSize:11}
            }
            GridLayout {
                visible:root.showParameters&&root.result!==null;Layout.fillWidth:true;columns:width>1000?5:width>700?4:3;columnSpacing:8;rowSpacing:6
                Repeater {model:root.summaryCards();Rectangle{Layout.fillWidth:true;implicitHeight:54;radius:8;color:"#112236";border.color:"#233c54";Column{anchors.left:parent.left;anchors.leftMargin:10;anchors.verticalCenter:parent.verticalCenter;spacing:3
                    BodeLabel{text:modelData.title;font.pixelSize:10;color:"#7c99b7"}BodeLabel{text:modelData.value;font.pixelSize:16;font.bold:true;color:modelData.color}
                }}}
            }
                }
            }
            Rectangle {
                visible:!root.settingsCollapsed;objectName:"bode-settings-divider";Layout.fillWidth:true;implicitHeight:10
                color:settingsHandle.containsMouse||settingsHandle.pressed?"#20475b":"#0b1423"
                Rectangle {width:88;height:3;radius:1.5;anchors.centerIn:parent;color:settingsHandle.containsMouse?"#6bd0e3":"#48667e"}
                MouseArea {
                    id:settingsHandle;anchors.fill:parent;hoverEnabled:true;cursorShape:Qt.SplitVCursor;preventStealing:true
                    property real origin:0
                    property real original:330
                    onPressed:{origin=mapToItem(panel,mouse.x,mouse.y).y;original=settingsScroll.height;}
                    onPositionChanged:if(pressed)root.settingsHeight=Math.max(90,Math.min(panel.height-468,original+mapToItem(panel,mouse.x,mouse.y).y-origin))
                    onDoubleClicked:root.settingsHeight=330
                }
            }
            Item {
                id:chartStack;objectName:"bode-chart-stack";Layout.fillWidth:true;Layout.fillHeight:true;Layout.minimumHeight:270
                property var sizes:PlotLayout.heights(height-20,root.plotRatios)
        BodePlot {
            id: gainPlot
            caption:root.curveDenoise?"增益 / dB · 降噪显示":"增益 / dB"
            width:chartStack.width;height:chartStack.sizes[0]
            modelPoints:root.showModel?root.modelPoints:[]

            points: root.displayPoints; frequencyMin: root.plotMin; frequencyMax: root.plotMax
            cursorFrequency: root.cursorFrequency;cursorPinned:root.cursorPinned
            onCursorMoved:if(!root.cursorPinned)root.cursorFrequency=frequency
            onCursorPicked:root.pinCursor(frequency)
            annotations: root.showParameters && !coherencePlot ? root.marks : []
            showZeroDb:root.showParameters&&root.annotationOptions.zeroDb;showMinus180:root.showParameters&&root.annotationOptions.minus180
            onFrequencyViewChanged:root.setFrequencyView(minimum,maximum)
            onManualViewChanged: root.followAuto=false
            onAutoRequested:{root.cursorPinned=false;root.fitAll();}
            onContextRequested: contextMenu.popup()
        }
        BodePlot {

            id: phasePlot
            y:gainPlot.height+10;width:chartStack.width;height:chartStack.sizes[1]
            modelPoints:root.showModel?root.modelPoints:[]
            caption:root.curveDenoise?"相位 / ° · 降噪显示":"相位 / °"; valueKey: "phaseDeg"; curveColor: "#b59aff"
            points: root.displayPoints; frequencyMin: root.plotMin; frequencyMax: root.plotMax
            cursorFrequency: root.cursorFrequency;cursorPinned:root.cursorPinned
            onCursorMoved:if(!root.cursorPinned)root.cursorFrequency=frequency
            onCursorPicked:root.pinCursor(frequency)
            annotations: root.showParameters && !coherencePlot ? root.marks : []
            showZeroDb:root.showParameters&&root.annotationOptions.zeroDb;showMinus180:root.showParameters&&root.annotationOptions.minus180
            onFrequencyViewChanged:root.setFrequencyView(minimum,maximum)
            onManualViewChanged: root.followAuto=false
            onAutoRequested:{root.cursorPinned=false;root.fitAll();}
            onContextRequested: contextMenu.popup()
        }
        BodePlot {

            id: coherenceChart
            y:phasePlot.y+phasePlot.height+10;width:chartStack.width;height:chartStack.sizes[2]
            caption: "相干性 / γ²"; valueKey: "coherence"; curveColor: "#54d8ac"; coherencePlot: true
            points: root.result ? root.result.points : []; frequencyMin: root.plotMin; frequencyMax: root.plotMax
            cursorFrequency: root.cursorFrequency;cursorPinned:root.cursorPinned
            onCursorMoved:if(!root.cursorPinned)root.cursorFrequency=frequency
            onCursorPicked:root.pinCursor(frequency)
            annotations: root.showParameters && !coherencePlot ? root.marks : []
            showZeroDb:root.showParameters&&root.annotationOptions.zeroDb;showMinus180:root.showParameters&&root.annotationOptions.minus180
            onFrequencyViewChanged:root.setFrequencyView(minimum,maximum)
            onManualViewChanged: root.followAuto=false
            onAutoRequested:{root.cursorPinned=false;root.fitAll();}
            onContextRequested: contextMenu.popup()
        }
                Repeater {
                    model:2
                    Rectangle {
                        width:chartStack.width;height:10;y:index===0?gainPlot.height:phasePlot.y+phasePlot.height;color:handleMouse.containsMouse||handleMouse.pressed?"#23475e":"#0b1423"
                        Rectangle {width:46;height:3;radius:1.5;anchors.centerIn:parent;color:handleMouse.containsMouse?"#70d5e8":"#3b5871"}
                        MouseArea {
                            id:handleMouse;anchors.fill:parent;hoverEnabled:true;cursorShape:Qt.SplitVCursor;preventStealing:true
                            property real origin:0
                            property var original:[]
                            onPressed:{origin=mapToItem(chartStack,mouse.x,mouse.y).y;original=root.plotRatios.slice();}
                            onPositionChanged:if(pressed)root.plotRatios=PlotLayout.resize(chartStack.height-20,original,index,mapToItem(chartStack,mouse.x,mouse.y).y-origin)
                            onDoubleClicked:root.plotRatios=[.45,.4,.15]
                        }
                    }
                }
            }
            Flow {
                objectName:"bode-frequency-controls";Layout.fillWidth:true;spacing:7
                BodeLabel {text:"显示频段";height:30;verticalAlignment:Text.AlignVCenter;font.pixelSize:11;color:"#88adc5"}
                BodeCombo {objectName:"bode-frequency-mode";width:116;model:["自动选择","手动设置"];currentIndex:root.autoFrequency?0:1;onActivated:root.setFrequencyMode(currentIndex===0)}
                BodeLabel {text:"起始 Hz";height:30;verticalAlignment:Text.AlignVCenter;font.pixelSize:11}
                BodeField {id:frequencyMin;objectName:"bode-frequency-min";width:90;text:"0";enabled:!root.autoFrequency;selectByMouse:true;onAccepted:root.applyManualFrequency()}
                BodeLabel {text:"终止 Hz";height:30;verticalAlignment:Text.AlignVCenter;font.pixelSize:11}
                BodeField {id:frequencyMax;objectName:"bode-frequency-max";width:90;text:"0";enabled:!root.autoFrequency;selectByMouse:true;onAccepted:root.applyManualFrequency()}
                BodeButton {objectName:"bode-frequency-apply";text:"应用";implicitWidth:60;enabled:!root.autoFrequency&&root.result!==null;onClicked:root.applyManualFrequency()}
                BodeLabel {text:root.autoFrequency?"按可信频点自动选择":"仅改变显示；0 = FFT边界";height:30;verticalAlignment:Text.AlignVCenter;font.pixelSize:10;color:"#6e8ca5"}
            }
            BodeLabel {objectName:"bode-frequency-error";visible:root.frequencyRangeMessage!=="";Layout.fillWidth:true;text:root.frequencyRangeMessage;wrapMode:Text.Wrap;font.pixelSize:10;color:"#ffad96"}
            FrequencyNavigator {
                id:frequencyNavigator;Layout.fillWidth:true;enabled:root.result!==null
                fullMin:root.result?root.result.resolution:1;fullMax:root.result?root.result.fs/2-root.result.resolution:10000
                viewMin:root.plotMin;viewMax:root.plotMax;points:root.displayPoints
                onRangeChanged:root.setFrequencyView(minimum,maximum)
                onAutoRequested:root.autoFrequencyView()
                onFullRequested:root.setFrequencyView(fullMin,fullMax)
            }
            RowLayout {
                Layout.fillWidth:true
                BodeLabel {Layout.fillWidth:true;text:root.cursorText();color:"#c3d8ec";font.pixelSize:11;elide:Text.ElideRight}
                BodeLabel {text:"滚轮缩放 · 拖动平移 · 双击 Auto";font.pixelSize:10;color:"#63809d"}
            }
        }
    }
    Column {
        visible:root.detached; anchors.centerIn:parent;spacing:12
        BodeLabel { text:"伯德图已在独立窗口打开";color:"#c3d8ee" }
        BodeButton { text:"显示窗口";onClicked:root.openDetached() }
        BodeButton { text:"返回画布";onClicked:root.returnEmbedded() }
    }
    FileDialog {
        id: saveDialog; title: "导出伯德图数据"; selectExisting: false; nameFilters: ["CSV (*.csv)"]
        onAccepted: root.exportTo(fileUrl.toString())
    }
    FileDialog {
        id:modelDialog;title:"导出传递函数模型";selectExisting:false;nameFilters:["JSON (*.json)"]
        onAccepted:root.exportModel(fileUrl.toString())
    }
    function clearModel(){if(workerPurpose==="identify"){analysisWorker.sendMessage({action:"cancel",token:workerToken});workerToken="";workerPurpose="";workerRequest=null;}identificationGeneration++;identificationJob=null;identifying=false;candidateModels=[];candidateSummaries=[];identifiedModel=null;modelPoints=[];identificationStatus="辨识设置已更新，请重新辨识。";}
    function openAssessment(){assessmentPopup.open();}
    function closeAssessment(){assessmentPopup.close();}
    function identificationSummary(){
        var model=identifiedModel;if(!model)return "";
        var choice=model.orderSelection,same=choice&&model.poles===choice.selectedPoles&&model.zeros===choice.selectedZeros;
        return (choice?(same?"自动推荐":"查看候选"):"当前模型")+" · "+model.poles+" 极点 / "+model.zeros+" 零点 · "+model.fitMin.toFixed(1)+"～"+model.fitMax.toFixed(1)+" Hz · "+model.frequencyCount+" 个训练频点"+(choice?" · "+choice.attempted+" 组候选":"")+(choice&&!same?"（推荐 "+choice.selectedPoles+" / "+choice.selectedZeros+"）":"")+(choice&&choice.atPoleLimit?" · 推荐已达阶次上限":"");
    }
    function selectCandidate(poles,zeros){
        if(identifying||!identifiedModel)return;
        var metadata=identifiedModel.preprocessing;
        for(var i=0;i<candidateModels.length;i++)if(candidateModels[i].poles===poles&&candidateModels[i].zeros===zeros){publishModel(candidateModels[i],metadata);return;}
    }
    function publishModel(model,metadata){
        model.preprocessing=metadata;model.fs=result.fs;model.bandCoverage=Identification.coverage(model,result.points);model.modalAnalysis=ModalAnalysis.analyze(model);model.keyParameters=ModelParameters.analyze(model,Identification.evaluate,Features.analyze,Identification.supportedAt);model.bandCoverage.missedCutoffs=[];if(features)for(var fi=0;fi<features.cutoffs.length;fi++)if(!Identification.supportedAt(model,features.cutoffs[fi].frequency))model.bandCoverage.missedCutoffs.push(features.cutoffs[fi].frequency);
        model.fs=result.fs;model.input=inputName;model.output=outputName;model.selection=capturedSelection;
        identifiedModel=model;refreshModelCurve();
        var score=model.validation||model.training,selection=model.orderSelection;
        identificationStatus=(selection?identificationSummary()+" · ":"")+(model.stable?"稳定模型":"非稳定模型")+" · "+model.frequencyCount+" 个拟合频点 · "+model.fitMin.toFixed(1)+"～"+model.fitMax.toFixed(1)+" Hz · "+(model.validation?(metadata.validationMode==="frequency"?"频点留出验证（同记录）":"后30%时段验证"):"训练集误差（未留出验证）")+"：复频响相对误差 "+score.relativeErrorPercent.toFixed(2)+"%，幅度 RMSE "+score.gainRmseDb.toFixed(3)+" dB，相位 RMSE "+score.phaseRmseDeg.toFixed(2)+"°。"+(score.relativeErrorPercent>20?" 误差偏大，请检查阶次、延迟和激励。":"")+(selection&&selection.atPoleLimit?(selection.maxPoles<6?" 推荐阶次达到搜索上限，可提高上限复核。":" 推荐阶次达到插件上限（6），请另采数据复核。") : "");
        identificationStatus+=(metadata.validationUnavailableReason?" "+metadata.validationUnavailableReason:"")+(model.limitedSupport?" 频点较少，仅作初步估计，请用更多数据复验。":"")+" 辨识FFT "+metadata.nfft+" · 分辨率尝试 "+(metadata.resolutionTrials||1)+" 次。";identifying=false;if(followAuto)fitAll();
    }
    function advanceOrderSearch(){
        var job=identificationJob;if(!job)return;
        if(job.captureGeneration!==captureGeneration||job.generation!==identificationGeneration){identificationJob=null;identifying=false;return;}
        try{
            Identification.stepOrderSearch(job.search);
            identificationStatus="自动选阶 "+job.search.index+" / "+job.search.jobs.length+"：已比较 "+job.search.jobs[job.search.index-1].poles+" 极点 / "+job.search.jobs[job.search.index-1].zeros+" 零点；可点击取消。";
            if(job.search.index>=job.search.jobs.length){var model=Identification.finishOrderSearch(job.search);candidateModels=job.search.models.slice();for(var i=0;i<candidateModels.length;i++)candidateModels[i].orderSelection=model.orderSelection;candidateSummaries=IdentificationDisplay.comparisonRows(model);identificationJob=null;publishModel(model,job.metadata);}
        }catch(e){var failedRows=IdentificationDisplay.comparisonRows({orderSelection:{selectedPoles:-1,selectedZeros:-1,candidates:job.search.candidates}});clearModel();candidateSummaries=failedRows;identificationStatus="辨识失败："+String(e.message||e);}
    }
    function refreshModelCurve(){
        modelPoints=identifiedModel&&result?Identification.curve(identifiedModel,result.points,{minimum:plotMin,maximum:plotMax,fullRange:modelFullRange}):[];
    }
    function snapshotMatchesSelection(){
        if(!capturedPairs)return false;
        if(capturedPairs.followSelection!==followSelection)return false;
        if(hub&&(hub.effective_size!==capturedPairs.bufferRows||hub.head!==capturedPairs.head||hub.size!==capturedPairs.size))return false;
        if(!followSelection)return true;
        try{var now=ChannelSource.selection(selectionBar.size,hub.effective_size,selectionBar.lindex_int,selectionBar.rindex_int),old=capturedPairs.selected;return old&&now.start===old.start&&now.end===old.end;}catch(e){return false;}
    }
    function identify(){
        if(!capturedPairs||!result||busy||identifying)return;
        if(!snapshotMatchesSelection()){clearModel();identificationStatus="选区或缓冲区已变化，请先重新读取并计算，再辨识当前选区。";return;}
        clearModel();identifying=true;identificationStatus="后台预处理及分段频谱计算…";
        workerToken="identify-"+(++workerSequence);workerPurpose="identify";transferOffset=0;
        workerRequest={generation:identificationGeneration,captureGeneration:captureGeneration,options:{poles:idPoles,zeros:idZeros,delayMs:idDelay,minHz:idMin,maxHz:idMax,enforceStable:idStable,robust:idRobust,maxPoles:idMaxPoles,autoZeros:idAutoZeros,noiseAssist:idNoiseAssist},autoOrder:idAutoOrder};
        analysisWorker.sendMessage({action:"identify",token:workerToken,options:{validationMode:idValidationMode,autoOrder:idAutoOrder,autoZeros:idAutoZeros,maxPoles:idMaxPoles,trimPercent:idTrim,detrend:idDetrend,validate:idValidate||idAutoOrder,robust:idRobust,minCoherence:idCoherence,noiseAssist:idNoiseAssist,poles:idPoles,zeros:idZeros,minHz:idMin,maxHz:idMax,noisy:result.coherenceMedian!==undefined&&result.coherenceMedian<.85}});
    }
    function beginIdentificationFit(message,request){
        if(request.generation!==identificationGeneration||request.captureGeneration!==captureGeneration)return;
        var measured=message.results[0],validation=message.results.length>1?message.results[1].points:null;
        request.options.validationKind=message.metadata.validationMode;
        request.options.supportPoints=message.fullSpectrum?message.fullSpectrum.points:measured.points;
        if(request.autoOrder&&!validation)throw new Error(message.metadata.validationUnavailableReason||"自动选阶需要有效留出验证，请扩大选区或提高FFT上限。");
        var prepared=Identification.prepareFrequencyPoints(measured.points,{noiseAssist:request.options.noiseAssist});
        request.options.assessmentPoints=measured.points;measured={points:prepared.points};
        message.metadata.spectralSmoothingCount=prepared.smoothed;
        if(request.autoOrder){identificationJob={search:Identification.createOrderSearch(measured.points,validation,request.options),metadata:message.metadata,captureGeneration:captureGeneration,generation:identificationGeneration};identificationStatus="自动选阶 0 / "+identificationJob.search.jobs.length+"；比较留出验证误差…";return;}
        var model=Identification.fit(measured.points,request.options);
        model.validation=validation?Identification.metrics(model,validation):null;publishModel(model,message.metadata);
    }
    function cancelCapture(){
        captureGeneration++;automatic=false;analysisWorker.sendMessage({action:"reset"});workerToken="";workerPurpose="";workerRequest=null;capturedText="";
        if(pendingCapture)retireSnapshot(pendingCapture.filename);pendingCapture=null;busy=false;result=null;capturedPairs=null;features=null;resonanceResult=null;resonanceIndex=0;marks=[];clearModel();statusText="已取消读取与计算。";
    }
    function snapshotMetadata(filename){
        var name=filename.slice(filename.lastIndexOf("/")+1);
        for(var i=0;i<snapshotFiles.count;i++)if(snapshotFiles.get(i,"fileName")===name)return String(snapshotFiles.get(i,"fileSize"))+"/"+String(snapshotFiles.get(i,"fileModified"));
        return "";
    }
    function receiveAnalysis(message){
        if(message.token!==workerToken)return;
        var purpose=workerPurpose,request=workerRequest;
        if(!message.done&&!message.error){
            if(purpose==="capture")statusText="后台扫描快照 / "+message.phase+"："+message.progress+"% · 分析 "+request.requiredPairs+" 对";
            else identificationStatus="后台预处理 / "+message.phase+"："+message.progress+"%";
            if(message.rewind)transferOffset=0;
            if(message.needChunk){var end=Math.min(capturedText.length,transferOffset+262144),chunk=capturedText.slice(transferOffset,end);transferOffset=end;analysisWorker.sendMessage({action:"chunk",token:workerToken,text:chunk,finalChunk:end>=capturedText.length});}
            else analysisWorker.sendMessage({action:"step",token:workerToken});return;
        }
        workerToken="";workerPurpose="";workerRequest=null;
        try{
            if(message.error){
                if(purpose==="capture"&&message.incomplete){request.lastSignature="";request.readSignature="";request.stableSince=0;request.retryAfter=Date.now()+700;statusText="快照尚未写完，继续等待… "+message.error;return;}
                throw new Error(message.error);
            }
            if(purpose==="identify"){beginIdentificationFit(message,request);return;}
            if(request.generation!==captureGeneration)return;
            verifyCaptureStable(request);
            var computed=message.results[0];
            result=computed;capturedPairs={streaming:true,count:request.analysisEnd-request.analysisStart,start:request.analysisStart,end:request.analysisEnd,selected:request.selected,followSelection:request.followSelection,head:request.head,size:request.size,bufferRows:request.expectedRows};inputName=request.inputName;outputName=request.outputName;capturedSelection=request.selectionLabel;
            updateFeatures();if(followAuto)fitAll();else fitFrequencyOnly();
            statusText=capturedSelection+"；缓冲区 "+message.totalRows+" 对；实际分析区间 "+request.start+"～"+(request.end-1)+"（"+computed.samples+" 对 / "+computed.segments+" 段），辨识将使用选区 "+request.analysisStart+"～"+(request.analysisEnd-1)+"；FFT="+computed.nfft+"；Δf="+computed.resolution.toPrecision(4)+" Hz；可信频点 "+computed.validCount+"。";
            if(!computed.validCount)statusText+=" 请检查激励与数据精度。";
            retireSnapshot(request.filename);pendingCapture=null;busy=false;
        }catch(e){
            if(purpose==="identify"){clearModel();identificationStatus="辨识失败："+String(e.message||e);}
            else{if(request)retireSnapshot(request.filename);pendingCapture=null;busy=false;automatic=false;capturedPairs=null;result=null;capturedText="";analysisWorker.sendMessage({action:"reset"});statusText=String(e.message||e);}
        }
    }
    function verifyCaptureStable(request){
        if(hub.effective_size!==request.expectedRows||hub.head!==request.head||hub.size!==request.size)throw new Error("导出或分析期间缓冲区发生变化，请先暂停接收，再读取计算。");
        // The worker scans the immutable text captured by read(), not the file.
        // FolderListModel can report a delayed final size/mtime after read completed.
        // Complete row count and selected numeric rows are verified in the worker.
    }
    function exportModel(url){
        if(!identifiedModel)return;
        try{var filename=decodeURIComponent(url.replace(/^file:\/\/\//,""));if(!/\.json$/i.test(filename))filename+=".json";
            var data={version:1,domain:"continuous-time",coefficientOrder:"descending powers of s; s in rad/s",equation:Identification.equation(identifiedModel),model:identifiedModel};
            io.source=filename;if(!io.write(JSON.stringify(data,null,2)))throw new Error("写入失败");statusText="模型已导出："+filename;
        }catch(e){statusText="模型导出失败："+String(e.message||e);}
    }
    function openParameterSettings(){parameterPopup.open();}
    function closeParameterSettings(){parameterPopup.close();}
    function onBind() { refreshChannels(); refreshSelection(); }
    function onUnbind() { returnEmbedded(); }
    function openDetached() { detached=true;standaloneWindow.show();standaloneWindow.raise();standaloneWindow.requestActivate(); }
    function returnEmbedded() { detached=false;standaloneWindow.hide(); }
    function refreshSelection() {
        if(!selectionBar || !hub){selectionText="无法读取底部选区。";return;}
        var dt=Number(selectionBar.delta_t),fs=1000/dt;
        try {
            var s=ChannelSource.selection(selectionBar.size,hub.effective_size,selectionBar.lindex_int,selectionBar.rindex_int);
            selectionText=(followSelection?"当前底部选区：":"当前模式：完整缓冲区；底部选区：")+s.count+" 对（有效样本 "+s.start+"～"+(s.end-1)+"） · Δt="+dt+" ms / "+fs.toPrecision(6)+" Hz";
        }catch(e){selectionText=String(e.message||e);}
    }
    function syncManualFrequency(){if(result){frequencyMin.text=String(plotMin);frequencyMax.text=String(plotMax);}}
    function setFrequencyMode(automaticRange){frequencyRangeMessage="";if(automaticRange){autoFrequency=true;if(result)fitFrequencyOnly();}else{if(result)syncManualFrequency();autoFrequency=false;}}
    function applyManualFrequency(){if(autoFrequency)return;if(!result){frequencyRangeMessage="先读取并计算，再应用显示频段。";return;}var range=FrequencyRange.manual(frequencyMin.text,frequencyMax.text,result.resolution,result.fs/2-result.resolution);if(range.error){frequencyRangeMessage=range.error;return;}frequencyRangeMessage="";followAuto=false;plotMin=range.min;plotMax=range.max;}
    function setFrequencyView(minimum,maximum){if(!result)return;var r=FrequencyRange.normalize(minimum,maximum,result.resolution,result.fs/2-result.resolution);if(!r)return;autoFrequency=false;frequencyRangeMessage="";followAuto=false;plotMin=r.min;plotMax=r.max;syncManualFrequency();}
    function navigateFrequency(kind,delta){frequencyNavigator.adjust(kind,delta);}
    function autoFrequencyView(){followAuto=false;setFrequencyMode(true);}
    function fitFrequencyOnly() {
        if(result) {
            var range=Features.band(result.points);if(identifiedModel){if(!range)range={min:identifiedModel.fitMin,max:identifiedModel.fitMax};else range={min:Math.min(range.min,identifiedModel.fitMin),max:Math.max(range.max,identifiedModel.fitMax)};}var lo=result.resolution,hi=result.fs/2-result.resolution;
            if(autoFrequency && range){lo=range.min;hi=range.max;if(hi<=lo){lo=Math.max(result.resolution,lo/1.2);hi=Math.min(result.fs/2-result.resolution,hi*1.2);}}
            if(!autoFrequency){var manual=FrequencyRange.manual(frequencyMin.text,frequencyMax.text,result.resolution,result.fs/2-result.resolution);if(manual.error){frequencyRangeMessage=manual.error;return;}lo=manual.min;hi=manual.max;}frequencyRangeMessage="";
            if(!isFinite(lo)||!isFinite(hi)||lo<=0||hi<=lo||hi>=result.fs/2){statusText="显示范围无效：须满足 0 < 起始 < 终止 < Fs/2。";return;}
            plotMin=lo;plotMax=hi;
        }
    }
    function fitAll(){fitFrequencyOnly();gainPlot.autoY();phasePlot.autoY();coherenceChart.autoY();}
    function setAnnotationOption(key,value){var cfg=Annotations.normalized(annotationOptions);if(cfg[key]===undefined)return;cfg[key]=!!value;annotationOptions=cfg;}
    function setAllAnnotations(value){if(value)showParameters=true;var cfg=Annotations.defaults();for(var key in cfg)cfg[key]=!!value;annotationOptions=cfg;}
    function selectedResonance(){return resonanceResult&&resonanceResult.peaks.length?resonanceResult.peaks[Math.min(Math.max(0,resonanceIndex),resonanceResult.peaks.length-1)]:null;}
    function rebuildMarks(){marks=Annotations.build(features,selectedResonance(),annotationOptions,loopMode,annotationAllCrossings);}
    function updateResonance(){
        if(!result){resonanceResult=null;rebuildMarks();return;}
        resonanceResult=Resonance.analyze(result.points,{segments:result.segments,minHz:resonanceMinHz,maxHz:resonanceMaxHz,minProminenceDb:resonanceProminenceDb,minCoherence:resonanceCoherence,referenceDb:features?features.referenceDb:null});
        if(resonanceIndex>=resonanceResult.peaks.length)resonanceIndex=0;
        rebuildMarks();
    }
    function updateFeatures() {
        if(!result){features=null;resonanceResult=null;resonanceIndex=0;marks=[];return;}
        var ref=referenceDbText.trim()===""?null:Number(referenceDbText);
        features=ref!==null&&!isFinite(ref)?null:Features.analyze(result.points,{referenceDb:ref,loop:loopMode,filterCrossings:crossingFilter,phaseHysteresis:crossingPhaseBand,gainHysteresis:crossingGainBand,crossingCoherence:crossingCoherence});
        updateResonance();
    }
    function focusResonance(){var p=selectedResonance();if(!p||!result)return;followAuto=false;var width=p.bandwidthHz?3*p.bandwidthHz:p.frequency*.5;plotMin=Math.max(result.resolution,p.frequency-width);plotMax=Math.min(result.fs/2-result.resolution,p.frequency+width);gainPlot.autoY();phasePlot.autoY();coherenceChart.autoY();}
    function resonanceLabels(){var list=[];if(resonanceResult)for(var i=0;i<resonanceResult.peaks.length;i++){var p=resonanceResult.peaks[i];list.push((i+1)+" · fr "+p.frequency.toFixed(2)+" Hz · Gr "+p.gainDb.toFixed(2)+" dB"+(p.dampingRatio===null?" · 阻尼条件不足":" · ζ_HP ≈ "+p.dampingRatio.toFixed(4)));}return list.length?list:["读取并计算后选择可信共振峰"];}
    function resonanceMetric(index){var p=selectedResonance();if(!p)return "未检出";if(index===0)return p.frequency.toFixed(2)+" Hz";if(index===1)return p.gainDb.toFixed(2)+" dB";if(index===2)return p.relativePeakDb===null?"无参考":p.relativePeakDb.toFixed(2)+" dB";if(index===3)return p.dampingRatio===null?"条件不足":"≈ "+p.dampingRatio.toFixed(4);if(index===4)return p.bandwidthHz===null?"缺少交点":p.bandwidthHz.toFixed(2)+" Hz";return p.qualityFactor===null?"条件不足":"≈ "+p.qualityFactor.toFixed(3);}
    function resonanceStatus(){
        if(!result)return "先读取并计算伯德图，无需执行传递函数辨识。";
        if(!resonanceResult)return "等待分析。";
        if(resonanceResult.error)return resonanceResult.error;
        var p=selectedResonance();if(!p)return resonanceResult.message;
        var text=p.dampingRatio===null?p.reason:"ζ_HP ≈ (f2−f1)/(2fr)，仅适用于孤立轻阻尼峰。";
        if(p.left&&p.right)text+=" f1="+p.left.frequency.toFixed(2)+" Hz，f2="+p.right.frequency.toFixed(2)+" Hz；峰值−3.01 dB="+p.halfPowerDb.toFixed(2)+" dB。";
        if(features&&features.referenceDb!==null)text+=" ΔMr参考="+features.referenceDb.toFixed(2)+" dB（"+(referenceDbText.trim()?"手动":"自动低频估计")+"），"+(p.relativePeakRatio===null?"":p.relativePeakRatio.toFixed(3)+"×。 ");
        if(p.notes.length)text+=" "+p.notes.join("；")+"。";return text;
    }
    function summaryCards(){var cfg=Annotations.normalized(annotationOptions),cards=[];
        function add(key,title,value,color){if(cfg[key])cards.push({title:title,value:value,color:color});}
        if(features){add("fc","截止 · fc",metricValue(0),"#f3c86e");add("fg","0 dB穿越 · fg",metricValue(1),"#fb8d86");if(loopMode){add("fp","−180°穿越 · fp",metricValue(4),"#8adecf");add("pm","相位裕度 · PM",metricValue(2),"#b9a1ff");add("gm","增益裕度 · GM",metricValue(3),"#8adecf");}}
        var p=selectedResonance();if(p){add("fr","谐振频率 · fr",resonanceMetric(0),"#86dfd2");add("peak","峰值增益 · Gr",resonanceMetric(1),"#86dfd2");add("zeta","实测阻尼 · ζ_HP",resonanceMetric(3),"#86dfd2");add("bandwidth","半功率带宽 · BW",resonanceMetric(4),"#95c9f2");add("q","品质因数 · Q_HP",resonanceMetric(5),"#95c9f2");}return cards;
    }
    function crossingStatus(){if(!result)return "读取并计算后显示穿越统计；主要点只影响显示，不删除已确认的穿越结果。";if(!features)return "通带参考无效。";if(features.error)return features.error;var d=features.crossingDiagnostics;if(!d)return "";return "相干性筛选后未去抖：fg "+d.rawGain+" / fp "+d.rawPhase+"；确认：fg "+d.confirmedGain+" / fp "+d.confirmedPhase+"。"+(annotationAllCrossings?"显示全部确认点。":"主要点按最小数值PM/GM选择；普通模式取首个。")}
    function selectedCrossing(index){
        if(!features)return null;var list=index===0?features.cutoffs:index===3||index===4?features.phaseCrossovers:features.gainCrossovers;if(!list.length)return null;
        var p=list[0],key=index===3||index===4?"gainMargin":"phaseMargin";
        if(loopMode&&!annotationAllCrossings&&index!==0)for(var i=1;i<list.length;i++)if(list[i][key]!==null&&list[i][key]<p[key])p=list[i];return p;
    }
    function metricValue(index) {
        if(!features)return "—";
        var list=index===0?features.cutoffs:index===3||index===4?features.phaseCrossovers:features.gainCrossovers;
        if(!list.length)return "未检出";
        var p=selectedCrossing(index),suffix=list.length>1?"  +"+(list.length-1):"";
        if(index===2)return p.phaseMargin===null?"—":p.phaseMargin.toFixed(2)+"°"+suffix;
        if(index===3)return p.gainMargin===null?"—":p.gainMargin.toFixed(2)+" dB"+suffix;
        return (p.frequency>=10000?(p.frequency/1000).toFixed(2)+" kHz":p.frequency.toFixed(2)+" Hz")+suffix;
    }
    function parameterText() {
        if(!result)return "计算后可标注低通 −3dB 截止 fc、0dB 穿越 fg；开环模式增加相位裕度 PM、−180° 穿越 fp 与增益裕度 GM。";
        if(!features)return "参考增益无效。";
        function hz(v){return v.toPrecision(5)+" Hz";}
        function lines(list,fn){var a=[];for(var i=0;i<Math.min(3,list.length);i++)a.push(fn(list[i]));return a.length?a.join("，")+(list.length>3?" … 共 "+list.length+" 个":""):"未检出";}
        var t="低频参考 "+(features.referenceDb===null?"无有效数据":features.referenceDb.toFixed(3)+" dB")+"；低通 −3dB fc："+lines(features.cutoffs,function(p){return hz(p.frequency);});
        t+="\n0dB 穿越 fg："+lines(features.gainCrossovers,function(p){return hz(p.frequency)+(loopMode?" / PM="+p.phaseMargin.toFixed(2)+"°":"");});
        if(loopMode)t+="；−180° 穿越 fp："+lines(features.phaseCrossovers,function(p){return hz(p.frequency)+" / GM="+p.gainMargin.toFixed(2)+" dB";});
        else t+="；测量开环 L 时再切换开环模式显示裕度。";
        return t;
    }
    function refreshChannels() {
        if (!hub) return;
        var labels = [], count = hub.num_lines;
        for (var i = 0; i < count; i++) labels.push("I" + i + (hub.names && hub.names[i] ? " · " + hub.names[i] : ""));
        if (JSON.stringify(labels) !== JSON.stringify(channelLabels)) {
            channelLabels = labels;
            inputChoice.currentIndex = preferredInputIndex >= 0 && preferredInputIndex < count ? preferredInputIndex : -1;
            outputChoice.currentIndex = preferredOutputIndex >= 0 && preferredOutputIndex < count ? preferredOutputIndex : -1;
            clearResult();
        }
    }
    function retireSnapshot(filename) {
        if (filename) retiredSnapshots.push({ path: filename, removeAfter: Date.now() + 20000 });
    }
    function cleanSnapshots() {
        var keep = [];
        for (var i = 0; i < retiredSnapshots.length; i++) {
            var item = retiredSnapshots[i];
            if (Date.now() < item.removeAfter || (io.exist(item.path) && !io.remove(item.path))) keep.push(item);
        }
        retiredSnapshots = keep;
    }
    function clearResult() {
        captureGeneration++; automatic = false;analysisWorker.sendMessage({action:"reset"});workerToken="";workerPurpose="";workerRequest=null;capturedText="";capturedPairs=null;clearModel();
        if (pendingCapture) retireSnapshot(pendingCapture.filename);
        pendingCapture = null; busy = false; result = null; features=null;resonanceResult=null;resonanceIndex=0;marks=[];cursorFrequency = 0;cursorPinned=false;
        statusText = "参数或通道已更新，请重新读取计算。";
    }
    function capture() {
        if (busy||identifying) return;
        busy = true;
        // Defer work to let the button and status repaint before synchronous host export.
        var generation = captureGeneration;
        Qt.callLater(function() { if (root.busy && generation === root.captureGeneration) root.captureNow(); });
    }
    function captureNow() {
        var snapshot = "";
        try {
            busy = true;analysisWorker.sendMessage({action:"reset"});workerToken="";workerPurpose="";workerRequest=null;capturedText="";
            result = null; features=null;resonanceResult=null;resonanceIndex=0;marks=[];cursorFrequency=0;cursorPinned=false;capturedPairs=null;clearModel();
            if (!hub || typeof hub.saveTo !== "function") throw new Error("当前 VOFA+ 未暴露 DataHub.saveTo；本插件已在 1.3.10 验证，其他版本需重新验证。");
            refreshChannels();
            var xindex = inputChoice.currentIndex, yindex = outputChoice.currentIndex;
            if (xindex < 0 || yindex < 0 || xindex === yindex) throw new Error("请选择两个不同的有效通道。");
            var selected=null;
            if(followSelection) {
                if(!selectionBar)throw new Error("当前宿主未提供底部选择条接口。");
                selected=ChannelSource.selection(selectionBar.size,hub.effective_size,selectionBar.lindex_int,selectionBar.rindex_int);
            }
            var available=selected?selected.count:hub.effective_size,analysisLimit=Number(analysisLimitText),timeout=Number(exportTimeoutText);
            if(!analysisLimitText.trim()||!isFinite(analysisLimit)||analysisLimit<0||analysisLimit!==Math.floor(analysisLimit)||analysisLimit>9007199254740991)throw new Error("分析点数上限须为非负整数，0 表示全部选区。");
            if(!isFinite(timeout)||timeout<15||timeout>3600)throw new Error("导出等待须为 15～3600 秒。");
            var count=analysisLimit===0?available:Math.min(available,analysisLimit);
            var fs=useDeltaT && selectionBar?1000/Number(selectionBar.delta_t):Number(sampleRate.text);
            var fftLimit=Number(fftChoice.currentText),nfft=fftLimit,averages=Number(averageChoice.currentText);
            if(adaptiveFFT) {
                var limit=Math.min(nfft,Math.floor(count/4));nfft=64;
                if(limit<64)throw new Error("选区样本不足，至少需要 256 对采样；请拉宽底部选择条。");
                while(nfft*2<=limit)nfft*=2;
            }
            if(allSegments)averages=Math.floor((count-nfft)/(nfft/2))+1;
            if ((!useDeltaT && !sampleRate.text.trim()) || !isFinite(fs) || fs <= 0) throw new Error("请填写真实采样率（Hz）。");
            var min = 0, max = 0, coherence = Number(coherenceThreshold.text);
            if (!coherenceThreshold.text.trim() || !isFinite(coherence) || coherence < 0 || coherence > 1) throw new Error("相干性阈值必须在 0～1 之间。");
            if (!isFinite(min) || !isFinite(max) || min < 0 || max < 0) throw new Error("频率范围无效；0 表示自动。");
            min = min === 0 ? fs / nfft : min; max = max === 0 ? fs / 2 - fs / nfft : max;
            if (min >= max || max >= fs / 2) throw new Error("频率范围须满足 0 < 起始 < 截止 < 采样率 / 2。");
            var requiredPairs = nfft + (averages - 1) * nfft / 2;
            if(averages<2 || count<requiredPairs)throw new Error("选区连续样本不足：FFT="+nfft+" 至少需要两个重叠分段，请拉宽选区或开启自适应 FFT。");
            var base = sys_manager.data_path + "/bode";
            io.mkdir(base);snapshotFiles.folder="";snapshotFiles.folder="file:///"+base; captureGeneration++;
            snapshot = base + "/snapshot-" + instanceToken + "-" + captureGeneration + ".csv";
            var exportNames = [];
            for (var channel = 0; channel < hub.num_lines; channel++) exportNames.push(hub.names && channel < hub.names.length ? String(hub.names[channel]) : "");
            var request = { filename: snapshot, generation: captureGeneration,
                xindex: xindex, yindex: yindex, channelCount: hub.num_lines, requiredPairs: requiredPairs,
                inputName: channelLabels[xindex], outputName: channelLabels[yindex], min: min, max: max,
                followSelection:followSelection,analysisStart:(selected?selected.end:hub.effective_size)-count,analysisEnd:selected?selected.end:hub.effective_size,fftLimit:fftLimit,selected:selected,expectedRows:hub.effective_size,head:hub.head,size:hub.size,start:(selected?selected.end:hub.effective_size)-requiredPairs,end:selected?selected.end:hub.effective_size,
                selectionLabel:selected?"选区样本 "+selected.start+"～"+(selected.end-1):"完整缓冲区",
                options: { fs: fs, nfft: nfft, averages: averages, minCoherence: coherence, powerFloorDb: -60 },
                started:Date.now(),timeoutMs:timeout*1000,lastSignature:"",stableSince:0,retryAfter:0 };
            if (!hub.saveTo(snapshot, exportNames, false)) throw new Error("宿主拒绝导出采样缓冲区。");
            if (request.generation !== captureGeneration) {
                retireSnapshot(snapshot); busy = false;
                statusText = "导出期间通道发生变化，请重新选择并读取。";
                return;
            }
            pendingCapture = request;
            busy = true;
            statusText = "正在等待宿主写出本次缓冲区快照…";
        } catch (e) {
            retireSnapshot(snapshot); pendingCapture = null; busy = false; automatic = false; result = null;
            statusText = String(e.message || e);
        }
    }
    function pollCapture(){
        var request=pendingCapture;if(!request||workerPurpose==="capture")return;
        if(request.generation!==captureGeneration){retireSnapshot(request.filename);pendingCapture=null;busy=false;return;}
        try{
            var now=Date.now();
            if(now-request.started>request.timeoutMs)throw new Error("等待宿主导出超时。可在参数设置中增加导出等待秒数。");
            if(now<request.retryAfter)return;
            var signature=snapshotMetadata(request.filename);if(!signature)return;
            if(signature!==request.lastSignature){request.lastSignature=signature;request.stableSince=now;return;}
            if(now-request.stableSince<700)return;
            verifyCaptureStable(request);request.readSignature=signature;
            statusText="读取宿主快照，随后转入后台扫描…";
            io.source=request.filename;capturedText=io.read();transferOffset=0;
            workerToken="capture-"+(++workerSequence);workerPurpose="capture";workerRequest=request;
            analysisWorker.sendMessage({action:"capture",token:workerToken,source:{xindex:request.xindex,yindex:request.yindex,channelCount:request.channelCount,start:request.start,end:request.end,expectedRows:request.expectedRows,analysisStart:request.analysisStart,analysisEnd:request.analysisEnd,fftLimit:request.fftLimit,options:request.options}});
        }catch(e){retireSnapshot(request.filename);pendingCapture=null;busy=false;automatic=false;result=null;capturedPairs=null;statusText=String(e.message||e);}
    }
    function pinCursor(frequency) {
        if(!result||!result.points.length)return;
        var nearest=result.points[0];
        for(var i=1;i<result.points.length;i++)if(Math.abs(result.points[i].frequency-frequency)<Math.abs(nearest.frequency-frequency))nearest=result.points[i];
        cursorFrequency=nearest.frequency;cursorPinned=true;
    }
    function cursorText() {
        if (!result || cursorFrequency <= 0) return "单击曲线锁定频点读数；拖动平移，滚轮缩放，双击自动缩放。";
        var nearest = null, distance = Infinity,nearestIndex=0;
        for (var i = 0; i < result.points.length; i++) {
            var p = result.points[i], d = Math.abs(p.frequency - cursorFrequency);
            if (d < distance) { nearest = p; distance = d;nearestIndex=i; }
        }
        if (!nearest) return "";
        var smoothed=curveDenoise&&nearest.valid?displayPoints[nearestIndex]:null;
        var prefix=smoothed?"降噪 "+smoothed.gainDb.toFixed(3)+" dB / "+smoothed.phaseDeg.toFixed(2)+"°   |   原始 ":"";
        return prefix+nearest.frequency.toPrecision(5) + " Hz   |   " + (nearest.valid ? nearest.gainDb.toFixed(3) + " dB   |   " + nearest.phaseDeg.toFixed(2) + "°" : "幅相无效：输入能量或相干性不足") + "   |   γ² = " + nearest.coherence.toFixed(4);
    }
    function exportTo(url) {
        if (!result) return;
        try {
            var filename = decodeURIComponent(url.replace(/^file:\/\/\//, ""));
            if (!/\.csv$/i.test(filename)) filename += ".csv";
            var rows = ["frequency_hz,gain_db,phase_deg,coherence,valid,fs_hz,input_channel,output_channel"];
            function quote(value) { return '"' + String(value).replace(/"/g, '""') + '"'; }
            for (var i = 0; i < result.points.length; i++) {
                var p = result.points[i];
                if (p.frequency < plotMin || p.frequency > plotMax) continue;
                rows.push([p.frequency, p.valid ? p.gainDb : "", p.valid ? p.phaseDeg : "", p.coherence, p.valid ? 1 : 0, result.fs, quote(inputName), quote(outputName)].join(","));
            }
            io.source = filename;
            if (!io.write(rows.join("\r\n") + "\r\n")) throw new Error("文件写入失败。");
            lastExport = filename; statusText = "已导出：" + filename;
        } catch (e) { statusText = "导出失败：" + String(e.message || e); }
    }
    function get_widget_ctx() {
        return { path: path, ctx: {
            '.': { ctx: get_ctx() }, preferences: { curveDenoise:curveDenoise,curveDenoiseStrength:curveDenoiseStrength,followSelection:followSelection,adaptiveFFT:adaptiveFFT,allSegments:allSegments,autoFrequency:autoFrequency,followAuto:followAuto,useDeltaT:useDeltaT,crossingFilter:crossingFilter,annotationAllCrossings:annotationAllCrossings,crossingPhaseBand:crossingPhaseBand,crossingGainBand:crossingGainBand,crossingCoherence:crossingCoherence,showParameters:showParameters,annotationOptions:annotationOptions,resonanceMinHz:resonanceMinHz,resonanceMaxHz:resonanceMaxHz,resonanceProminenceDb:resonanceProminenceDb,resonanceCoherence:resonanceCoherence,loopMode:loopMode,referenceDbText:referenceDbText, plotRatios:plotRatios,showModel:showModel,idStable:idStable,idRobust:idRobust,idDetrend:idDetrend,idValidate:idValidate,idValidationMode:idValidationMode,modelFullRange:modelFullRange,idPoles:idPoles,idZeros:idZeros,idTrim:idTrim,idDelay:idDelay,idMin:idMin,idMax:idMax,idAutoOrder:idAutoOrder,idAutoZeros:idAutoZeros,idMaxPoles:idMaxPoles,analysisLimitText:analysisLimitText,exportTimeoutText:exportTimeoutText,settingsHeight:settingsHeight,settingsFontScale:settingsFontScale,settingsCollapsed:settingsCollapsed,idNoiseAssist:idNoiseAssist,idCoherence:idCoherence }, input: { currentIndex: preferredInputIndex }, output: { currentIndex: preferredOutputIndex },
            fs: { text: sampleRate.text }, nfft: { currentIndex: fftChoice.currentIndex }, averages: { currentIndex: averageChoice.currentIndex },
            fmin: { text: frequencyMin.text }, fmax: { text: frequencyMax.text }, coherence: { text: coherenceThreshold.text }
        } };
    }
    function set_widget_ctx(ctx) {
        if (ctx.ctx.input && ctx.ctx.input.currentIndex !== undefined) preferredInputIndex = ctx.ctx.input.currentIndex;
        if (ctx.ctx.output && ctx.ctx.output.currentIndex !== undefined) preferredOutputIndex = ctx.ctx.output.currentIndex;
        var prefs=ctx.ctx.preferences;
        if(prefs){var keys=["curveDenoise","curveDenoiseStrength","followSelection","adaptiveFFT","allSegments","autoFrequency","followAuto","useDeltaT","crossingFilter","annotationAllCrossings","crossingPhaseBand","crossingGainBand","crossingCoherence","showParameters","annotationOptions","resonanceMinHz","resonanceMaxHz","resonanceProminenceDb","resonanceCoherence","loopMode","referenceDbText","plotRatios","showModel","idStable","idRobust","idDetrend","idValidate","idValidationMode","modelFullRange","idPoles","idZeros","idTrim","idDelay","idMin","idMax","idAutoOrder","idAutoZeros","idMaxPoles","analysisLimitText","exportTimeoutText","settingsHeight","settingsFontScale","settingsCollapsed","idNoiseAssist","idCoherence"];for(var i=0;i<keys.length;i++)if(prefs[keys[i]]!==undefined){if(keys[i]==="curveDenoiseStrength"){if(isFinite(prefs[keys[i]]))root.curveDenoiseStrength=Math.max(0,Math.min(2,Math.round(Number(prefs[keys[i]]))));}else if(keys[i]==="annotationOptions"){root.annotationOptions=Annotations.normalized(prefs[keys[i]]);}else if(keys[i]==="settingsFontScale"){if(isFinite(prefs[keys[i]]))root.settingsFontScale=Math.max(.8,Math.min(1.4,Number(prefs[keys[i]])));}else if(keys[i]==="settingsHeight"){if(isFinite(prefs[keys[i]]))root.settingsHeight=Math.max(90,Number(prefs[keys[i]]));}else if(keys[i]!=="plotRatios"||PlotLayout.valid(prefs[keys[i]]))root[keys[i]]=prefs[keys[i]];}}
        __set_ctx__(root, ctx.ctx, ref);
    }
}
