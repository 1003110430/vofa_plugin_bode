import QtQuick 2.12
import QtQuick.Controls 2.5
TextField {
 id:control;implicitHeight:34;implicitWidth:112;leftPadding:10;rightPadding:8
 font.family:"Microsoft YaHei";font.pixelSize:12;color:enabled?"#e0eaf7":"#7d91aa";placeholderTextColor:"#627a96";selectionColor:"#2f728c";selectedTextColor:"#ffffff"
 background:Rectangle{radius:6;color:control.enabled?"#0b1829":"#132135";border.color:control.activeFocus?"#56cce4":"#2b3e56";border.width:1}
}
