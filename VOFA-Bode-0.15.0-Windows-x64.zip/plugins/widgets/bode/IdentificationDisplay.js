.pragma library
function numberRich(value){
    var v=Math.abs(value);
    if(v===0)return "0";
    if(v>=10000||v<.001){var parts=v.toExponential(4).split("e");return String(Number(parts[0]))+" × 10<sup>"+Number(parts[1])+"</sup>";}
    return String(Number(v.toPrecision(5)));
}
function polynomialRich(coefficients){
    if(!coefficients||!coefficients.length)return "0";
    var terms=[];
    for(var i=0;i<coefficients.length;i++){
        var value=coefficients[i],power=coefficients.length-1-i;
        if(value===0)continue;
        var coefficient=Math.abs(value)===1&&power>0?"":numberRich(value);
        var variable=power?"<i>s</i>"+(power>1?"<sup>"+power+"</sup>":""):"";
        terms.push((terms.length?(value<0?" − ":" + "):(value<0?"−":""))+coefficient+(coefficient&&variable?"·":"")+variable);
    }
    return terms.join("")||"0";
}
function fitPercent(metrics){return metrics&&isFinite(metrics.relativeErrorPercent)?100-metrics.relativeErrorPercent:null;}
function display(value,digits){return value!==null&&value!==undefined&&isFinite(value)?Number(value).toFixed(digits===undefined?2:digits):"—";}
function key(model){return model?model.poles+"/"+model.zeros:"";}
function comparisonRows(model){
    if(!model)return [];
    var source=model.orderSelection?model.orderSelection.candidates:[{poles:model.poles,zeros:model.zeros,parameters:model.poles+model.zeros+1,ok:true,stable:model.stable,trainingErrorPercent:model.training.relativeErrorPercent,validationErrorPercent:model.validation?model.validation.relativeErrorPercent:null,gainRmseDb:(model.validation||model.training).gainRmseDb,phaseRmseDeg:(model.validation||model.training).phaseRmseDeg}];
    var selected=model.orderSelection?model.orderSelection.selectedPoles+"/"+model.orderSelection.selectedZeros:"",rows=[];
    for(var i=0;i<source.length;i++){var row={};for(var k in source[i])row[k]=source[i][k];row.key=key(row);row.recommended=row.key===selected;rows.push(row);}
    rows.sort(function(a,b){return Number(b.recommended)-Number(a.recommended)||Number(b.ok)-Number(a.ok)||(a.validationErrorPercent===null?Infinity:a.validationErrorPercent)-(b.validationErrorPercent===null?Infinity:b.validationErrorPercent)||a.parameters-b.parameters||a.poles-b.poles;});
    return rows;
}
