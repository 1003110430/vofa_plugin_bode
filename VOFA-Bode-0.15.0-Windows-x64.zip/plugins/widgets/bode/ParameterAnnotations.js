.pragma library
function defaults(){return {fc:true,fg:true,fp:true,pm:true,gm:true,fr:true,peak:true,zeta:true,halfPower:false,bandwidth:false,q:false,zeroDb:true,minus180:true};}
function normalized(value){var out=defaults();if(value)for(var key in out)if(typeof value[key]==="boolean")out[key]=value[key];return out;}
function build(features,peak,config,loop,allCrossings){
    var cfg=normalized(config),marks=[];
    function add(list,kind,color,frequency,margin){for(var i=0;i<list.length;i++){var p=list[i],m={};for(var k in p)m[k]=p[k];m.kind=kind;m.color=color;m.showFrequency=frequency;m.showMargin=margin;marks.push(m);}}
    if(features&&!allCrossings){
        function smallest(list,key){if(!list.length)return [];var best=list[0];if(loop)for(var i=1;i<list.length;i++)if(list[i][key]!==null&&list[i][key]<best[key])best=list[i];return [best];}
        features={cutoffs:features.cutoffs.slice(0,1),gainCrossovers:smallest(features.gainCrossovers,"phaseMargin"),phaseCrossovers:smallest(features.phaseCrossovers,"gainMargin")};
    }
    if(features){if(cfg.fc)add(features.cutoffs,"fc","#f3c86e",true,false);if(cfg.fg||loop&&cfg.pm)add(features.gainCrossovers,"fg","#fb8d86",cfg.fg,loop&&cfg.pm);if(loop&&(cfg.fp||cfg.gm))add(features.phaseCrossovers,"fp","#8adecf",cfg.fp,cfg.gm);}
    if(peak){
        if(cfg.fr||cfg.peak||cfg.zeta&&peak.dampingRatio!==null||cfg.bandwidth&&peak.bandwidthHz!==null||cfg.q&&peak.qualityFactor!==null){var mark={};for(var key in peak)mark[key]=peak[key];mark.kind="resonance";mark.color="#71dfce";mark.display=cfg;marks.push(mark);}
        if(cfg.halfPower){var ends=[peak.left,peak.right];for(var j=0;j<2;j++)if(ends[j]){var end={};for(var field in ends[j])end[field]=ends[j][field];end.kind=j?"f2":"f1";end.color="#95c9f2";marks.push(end);}}
    }
    return marks;
}
