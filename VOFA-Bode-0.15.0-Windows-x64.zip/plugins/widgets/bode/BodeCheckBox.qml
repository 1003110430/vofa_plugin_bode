import QtQuick 2.12
import QtQuick.Controls 2.5
CheckBox {
 id:control;implicitHeight:28;padding:0;spacing:7
 font.family:"Microsoft YaHei";font.pixelSize:12
 indicator:Rectangle{implicitWidth:16;implicitHeight:16;x:control.leftPadding;y:(control.height-height)/2;radius:4;color:control.checked?"#55c8df":"#101f31";border.color:control.checked?"#55c8df":"#435a72";Text{anchors.centerIn:parent;text:"✓";visible:control.checked;color:"#092130";font.pixelSize:12;font.bold:true}}
 contentItem:Text{text:control.text;font:control.font;color:control.enabled?"#b8cbe0":"#61758d";leftPadding:23;verticalAlignment:Text.AlignVCenter}
}
