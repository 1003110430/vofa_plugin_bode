.pragma library
// Shared by the worker and tests. Scan by newline offsets; retain only NFFT samples.
function streamPair(line,columns,xi,yi,row){
    var x="",y="",column=0,pos=0,next;
    if(line.indexOf('"')>=0){var fields=splitRow(line);column=fields.length;x=fields[xi];y=fields[yi];}
    else {do{next=line.indexOf(",",pos);var end=next<0?line.length:next;if(column===xi)x=line.slice(pos,end);if(column===yi)y=line.slice(pos,end);column++;pos=end+1;}while(next>=0);}
    if(column!==columns)throw new Error("CSV 第 "+(row+2)+" 行通道数不一致，不能保证连续采样。");
    if(x===undefined||y===undefined||!x.trim()||!y.trim()||!isFinite(Number(x))||!isFinite(Number(y)))throw new Error("CSV 第 "+(row+2)+" 行采样无效。");
    return [Number(x),Number(y)];
}
function streamRange(start,end,options){
    var n=options.nfft,segments=Math.floor((end-start-n)/(n/2))+1;
    if(segments<2)throw new Error("连续样本不足，至少需要两个完整重叠分段。");
    var opts={};for(var k in options)opts[k]=options[k];opts.averages=segments;
    return {originalStart:start,originalEnd:end,start:end-n-(segments-1)*n/2,end:end,options:opts,slopeX:0,slopeY:0};
}
function createStreamJob(text,source,kind,idOptions){
    if(!text||text.charAt(text.length-1)!=="\n"){var incomplete=new Error("快照仍在写入（已读 "+(text?text.length:0)+" 字符）。");incomplete.incomplete=true;throw incomplete;}
    var header=text.indexOf("\n");if(header<0)throw new Error("快照没有数据行。");
    if(source.xindex<0||source.yindex<0||source.xindex>=source.channelCount||source.yindex>=source.channelCount||source.start<0||source.end>source.expectedRows||source.end<=source.start)throw new Error("快照选区或通道无效。");
    var ranges=[],metadata=null,options=source.options;
    if(kind==="capture")ranges.push(streamRange(source.start,source.end,options));
    else {
        var trim=Number(idOptions.trimPercent),validate=!!idOptions.validate;
        if(!isFinite(trim)||trim<0||trim>40)throw new Error("过渡段剔除比例须为 0～40%。");
        var analysisStart=source.analysisStart===undefined?source.start:source.analysisStart,analysisEnd=source.analysisEnd===undefined?source.end:source.analysisEnd;
        if(analysisStart<0||analysisEnd>source.expectedRows||analysisStart>=analysisEnd)throw new Error("辨识时域选区无效。");
        var frequencyHoldout=validate&&idOptions.validationMode==="frequency";
        var removed=Math.floor((analysisEnd-analysisStart)*trim/100),begin=analysisStart+removed,count=analysisEnd-begin,split=validate&&!frequencyHoldout?Math.floor(count*.7):count;
        var timeValidation=validate&&!frequencyHoldout,fftLimit=source.fftLimit||options.nfft;
        if(count<256)throw new Error("剔除过渡段后样本不足。");
        var limit=Math.min(fftLimit,Math.floor(split/4),timeValidation?Math.floor((count-split)/3):16384),n=64;
        if(idOptions.noiseAssist&&idOptions.noisy)limit=Math.min(limit,Math.floor(2*split/9),timeValidation?Math.floor(2*(count-split)/9):16384);
        if(limit<64)throw new Error("验证时段样本不足，请扩大选区或关闭时段验证。");
        while(n*2<=limit)n*=2;
        // Resolution retries retain at least two complete Welch windows per part.
        var maxResolution=Math.min(fftLimit,Math.floor(2*split/3),timeValidation?Math.floor(2*(count-split)/3):16384);
        if(idOptions.resolutionNfft){var requested=Number(idOptions.resolutionNfft);if(requested>=64&&requested<=maxResolution&&Math.pow(2,Math.round(Math.log(requested)/Math.LN2))===requested)n=requested;}

        var coherence=idOptions.minCoherence===undefined?options.minCoherence:Number(idOptions.minCoherence);
        if((typeof idOptions.minCoherence==="string"&&!idOptions.minCoherence.trim())||!isFinite(coherence)||coherence<0||coherence>1)throw new Error("辨识相干性门槛须为 0～1。");
        var fftOptions={fs:options.fs,nfft:n,minCoherence:coherence,powerFloorDb:options.powerFloorDb};
        ranges.push(streamRange(begin,begin+split,fftOptions));if(timeValidation)ranges.push(streamRange(begin+split,analysisEnd,fftOptions));
        metadata={analysisStart:analysisStart,analysisEnd:analysisEnd,trimmedStart:begin,validationMode:frequencyHoldout?"frequency":timeValidation?"time":"none",removeMean:true,linearDetrend:!!idOptions.detrend,trimPercent:trim,trimmedSamples:removed,robust:!!idOptions.robust,coherenceThreshold:coherence,measurementCoherenceThreshold:options.minCoherence,noiseAssist:!!idOptions.noiseAssist,extraAveraging:!!(idOptions.noiseAssist&&idOptions.noisy),nfft:n,maxResolutionNfft:maxResolution,trainingSamples:split,validationSamples:timeValidation?count-split:0};
    }
    if(metadata){metadata.frequencyResolutionHz=options.fs/n;metadata.trainingSegments=ranges[0].options.averages;metadata.validationSegments=ranges.length>1?ranges[1].options.averages:0;}
    var job={text:text,source:source,kind:kind,headerEnd:header+1,ranges:ranges,metadata:metadata,statistics:kind!=="capture"&&!!idOptions.detrend,pass:0,cursor:header+1,row:0,lastNonEmpty:0,done:false,idOptions:idOptions};
    resetStreamRanges(job);return job;
}
function createChunkedStreamJob(source,kind,idOptions){
    var job=createStreamJob("header\n",source,kind,idOptions);
    job.chunked=true;job.text="";job.cursor=0;job.headerSeen=false;job.finalChunk=false;job.receivedChars=0;return job;
}
function feedStreamChunk(job,chunk,finalChunk){
    job.text=job.text.slice(job.cursor)+chunk;job.cursor=0;job.receivedChars+=chunk.length;job.finalChunk=!!finalChunk;
    if(!job.headerSeen){var header=job.text.indexOf("\n");if(header>=0){job.cursor=header+1;job.headerSeen=true;}}
}
function streamNeedsChunk(job){return job.chunked&&!job.finalChunk&&(job.cursor>=job.text.length||job.text.indexOf("\n",job.cursor)<0);}
function resetStreamRanges(job){
    for(var i=0;i<job.ranges.length;i++){var r=job.ranges[i];r.x=[];r.y=[];r.seen=0;r.acc=job.statistics?null:createAccumulator(r.options);r.stats={count:0,meanT:0,meanX:0,meanY:0,m2:0,covX:0,covY:0,baseX:0,baseY:0};}
}
function stepStreamJob(job,maxRows,maxMs){
    if(job.done)return true;
    var started=Date.now(),processed=0,text=job.text,source=job.source;
    while(job.cursor<text.length&&processed<(maxRows||8192)){
        if(processed%128===0&&Date.now()-started>=(maxMs||25))break;
        var next=text.indexOf("\n",job.cursor);if(next<0){if(job.chunked&&!job.finalChunk)break;throw new Error("CSV 最后一行不完整。");}
        var line=text.slice(job.cursor,next),row=job.row++;job.cursor=next+1;processed++;
        if(line.trim())job.lastNonEmpty=job.row;
        for(var i=0;i<job.ranges.length;i++){
            var r=job.ranges[i],start=job.statistics?r.originalStart:r.start,end=job.statistics?r.originalEnd:r.end;
            if(row<start||row>=end)continue;
            var pair=streamPair(line,source.channelCount,source.xindex,source.yindex,row);
            if(job.statistics){
                var s=r.stats,t=row-r.originalStart;if(!s.count){s.baseX=pair[0];s.baseY=pair[1];}
                var vx=pair[0]-s.baseX,vy=pair[1]-s.baseY,dt=t-s.meanT;
                s.count++;s.meanT+=dt/s.count;s.meanX+=(vx-s.meanX)/s.count;s.meanY+=(vy-s.meanY)/s.count;
                s.m2+=dt*(t-s.meanT);s.covX+=dt*(vx-s.meanX);s.covY+=dt*(vy-s.meanY);
            }else{
                var n=r.options.nfft,index=r.seen%n,coordinate=row-r.originalStart-(r.originalEnd-r.originalStart-1)/2;
                r.x[index]=pair[0]-r.slopeX*coordinate;r.y[index]=pair[1]-r.slopeY*coordinate;r.seen++;
                if(r.seen>=n&&(r.seen-n)%(n/2)===0)addWindow(r.acc,r.x,r.y,r.seen%n,true);
            }
        }
    }
    if(job.cursor>=text.length&&(!job.chunked||job.finalChunk)){
        if(job.lastNonEmpty!==source.expectedRows){var e=new Error("快照行数 "+job.lastNonEmpty+" 与请求 "+source.expectedRows+" 不一致（文本 "+text.length+" 字符），请暂停接收后重试。");e.incomplete=job.lastNonEmpty<source.expectedRows;throw e;}
        if(job.statistics){
            for(var k=0;k<job.ranges.length;k++){var range=job.ranges[k],stats=range.stats;range.slopeX=stats.m2?stats.covX/stats.m2:0;range.slopeY=stats.m2?stats.covY/stats.m2:0;}
            job.statistics=false;job.pass=1;job.cursor=job.headerEnd;job.row=0;job.lastNonEmpty=0;
            if(job.chunked){job.text="";job.cursor=0;job.headerSeen=false;job.finalChunk=false;job.receivedChars=0;job.rewind=true;}
            resetStreamRanges(job);return false;
        }
        job.results=[];for(k=0;k<job.ranges.length;k++)job.results.push(finishAccumulator(job.ranges[k].acc));if(job.metadata&&job.metadata.validationMode==="frequency"){
            job.fullSpectrum=job.results[0];var partition=partitionFrequencyHoldout(job.fullSpectrum,job.idOptions);
            job.results=partition.results;job.metadata.validationUnavailableReason=partition.reason;
            job.metadata.trainingFrequencyCount=partition.trainingCount;job.metadata.validationFrequencyCount=partition.validationCount;
        }
        job.done=true;return true;
    }
    return false;
}
function streamProgress(job){var p=Math.min(1,job.row/job.source.expectedRows);if(job.metadata&&job.metadata.linearDetrend)p=(job.pass+p)/2;return Math.floor(100*p);}

function identificationSupport(results,options){
    var lo=Number(options.minHz||0),hi=Number(options.maxHz||0)||Infinity,train=results[0].points,count=0,first=Infinity,last=0;
    for(var i=0;i<train.length;i++)if(train[i].valid&&train[i].frequency>=lo&&train[i].frequency<=hi){count++;first=Math.min(first,train[i].frequency);last=Math.max(last,train[i].frequency);}
    var validation=options.validate?0:count;
    if(results.length>1){validation=0;var points=results[1].points;for(i=0;i<points.length;i++)if(points[i].valid&&points[i].frequency>=first&&points[i].frequency<=last)validation++;}
    return {training:count,validation:validation,score:Math.min(count,validation)};
}

function partitionFrequencyHoldout(spectrum,options){
    var lo=Number(options.minHz||0),hi=Number(options.maxHz||0)||Infinity,indices=[],i;
    for(i=0;i<spectrum.points.length;i++){var p=spectrum.points[i];if(p.valid&&p.frequency>=lo&&p.frequency<=hi)indices.push(i);}
    var zeros=Number(options.zeros||0),poles=options.autoOrder?(options.autoZeros?1:Math.max(1,zeros)):Number(options.poles||3);
    var minimum=Math.max(6,2*(poles+(options.autoZeros?0:zeros)+1)),count=indices.length,validationCount=Math.max(6,Math.floor(count*.2));
    if(count<minimum+6)return {results:[spectrum],trainingCount:count,validationCount:0,reason:"仅 "+count+" 个可信频点，无法同时保证训练至少 "+minimum+" 点、验证至少6点；当前仅训练估计，未留出验证。"};
    validationCount=Math.min(validationCount,count-minimum);
    var held={},train=[],validation=[];
    for(i=0;i<validationCount;i++)held[indices[Math.round((i+1)*(count-1)/(validationCount+1))]]=true;
    for(i=0;i<spectrum.points.length;i++){var a={},b={},source=spectrum.points[i];for(var key in source){a[key]=source[key];b[key]=source[key];}a.valid=source.valid&&!held[i];b.valid=source.valid&&!!held[i];train.push(a);validation.push(b);}
    function part(points){var out={};for(var k in spectrum)out[k]=spectrum[k];out.points=points;out.validCount=points.filter(function(p){return p.valid;}).length;return out;}
    return {results:[part(train),part(validation)],trainingCount:count-validationCount,validationCount:validationCount,reason:null};
}
