.pragma library
function heights(total,ratios){
    total=Math.max(0,total);var minimum=[90,90,70],sum=250,out=[],free=Math.max(0,total-sum),r=ratios||[.45,.4,.15];
    for(var i=0;i<3;i++)out[i]=total<sum?total*minimum[i]/sum:minimum[i]+free*r[i];return out;
}
function resize(total,ratios,index,delta){
    if(index!==0&&index!==1)return ratios;
    var h=heights(total,ratios),mins=[90,90,70],free=total-250;
    if(free<=0)return ratios;
    delta=Math.max(mins[index]-h[index],Math.min(h[index+1]-mins[index+1],delta));
    h[index]+=delta;h[index+1]-=delta;
    return [(h[0]-90)/free,(h[1]-90)/free,(h[2]-70)/free];
}
function valid(r){return r&&r.length===3&&isFinite(r[0])&&isFinite(r[1])&&isFinite(r[2])&&r[0]>=0&&r[1]>=0&&r[2]>=0&&Math.abs(r[0]+r[1]+r[2]-1)<.001;}
