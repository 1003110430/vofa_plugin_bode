.pragma library
// Display-only robust local linear smoothing in log frequency. Never modifies source points.
function smooth(points,strength){
    var level=Math.max(0,Math.min(2,Math.round(Number(strength)||0))),radius=[2,5,10][level],logWidth=[.08,.16,.32][level]*Math.LN2;
    var out=[],segment=[];
    function median(a){a.sort(function(x,y){return x-y;});return a[Math.floor(a.length/2)];}
    function flush(){
        if(!segment.length)return;
        var n=segment.length,x=[],g=[],p=[],cg=[],cp=[],i,j;
        for(i=0;i<n;i++){var source=points[segment[i]];x[i]=Math.log(source.frequency);g[i]=source.gainDb;p[i]=source.phaseDeg;if(i){while(p[i]-p[i-1]>180)p[i]-=360;while(p[i]-p[i-1]< -180)p[i]+=360;}}
        // Hampel-style spike replacement, bounded by the same physical frequency width.
        function clean(values,index,floor){var v=[];for(var k=Math.max(0,index-2);k<=Math.min(n-1,index+2);k++)if(Math.abs(x[k]-x[index])<=logWidth)v.push(values[k]);if(v.length<5)return values[index];var m=median(v),d=[];for(k=0;k<v.length;k++)d.push(Math.abs(v[k]-m));var mad=median(d);return Math.abs(values[index]-m)>Math.max(floor,3*1.4826*mad)?m:values[index];}
        for(i=0;i<n;i++){cg[i]=clean(g,i,.5);cp[i]=clean(p,i,3);}
        function fit(values,index){var sw=0,sx=0,sxx=0,sy=0,sxy=0,used=0;
            for(var k=Math.max(0,index-radius);k<=Math.min(n-1,index+radius);k++){
                var dx=x[k]-x[index];if(Math.abs(dx)>logWidth)continue;
                var t=Math.abs(k-index)/(radius+1),tri=Math.pow(1-t*t*t,3),coh=points[segment[k]].coherence;
                var w=tri*(isFinite(coh)?Math.max(.05,Math.min(1,coh*coh)):1);sw+=w;sx+=w*dx;sxx+=w*dx*dx;sy+=w*values[k];sxy+=w*dx*values[k];used++;
            }
            var det=sw*sxx-sx*sx;if(used<3||det<=1e-20)return values[index];return (sy*sxx-sx*sxy)/det;
        }
        for(i=0;i<n;i++){var target=out[segment[i]];target.gainDb=fit(cg,i);target.phaseDeg=fit(cp,i);}
        segment=[];
    }
    for(var i=0;i<points.length;i++){
        var source=points[i],copy={};for(var key in source)copy[key]=source[key];out.push(copy);
        var good=source.valid&&source.frequency>0&&isFinite(source.frequency)&&source.gainDb!==null&&isFinite(source.gainDb)&&source.phaseDeg!==null&&isFinite(source.phaseDeg);
        if(!good){flush();continue;}
        if(segment.length&&source.frequency<=points[segment[segment.length-1]].frequency)flush();
        segment.push(i);
    }
    flush();return out;
}
