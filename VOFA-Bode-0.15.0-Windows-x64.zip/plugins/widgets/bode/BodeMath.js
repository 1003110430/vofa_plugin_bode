.pragma library

// Double precision radix-2 FFT. Forward transform uses exp(-j*w*n).
function fft(re, im) {
    var n = re.length, i, j = 0, t, k, size, half, angle, wr, wi, tr, ti, ur, ui;
    for (i = 1; i < n; i++) {
        k = n >> 1;
        while (j & k) { j ^= k; k >>= 1; }
        j ^= k;
        if (i < j) { t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; }
    }
    for (size = 2; size <= n; size *= 2) {
        half = size / 2;
        for (i = 0; i < n; i += size) {
            for (j = 0; j < half; j++) {
                angle = -2 * Math.PI * j / size;
                wr = Math.cos(angle); wi = Math.sin(angle);
                k = i + j + half;
                tr = wr * re[k] - wi * im[k]; ti = wr * im[k] + wi * re[k];
                ur = re[i + j]; ui = im[i + j];
                re[k] = ur - tr; im[k] = ui - ti;
                re[i + j] = ur + tr; im[i + j] = ui + ti;
            }
        }
    }
}

function estimate(x, y, options) {
    var accumulator=createAccumulator(options);
    var n=accumulator.n,averages=accumulator.averages;
    if(x.length!==y.length)throw new Error("输入、输出采样点数不一致。");
    for(var q=0;q<x.length;q++)if(!isFinite(x[q])||!isFinite(y[q]))throw new Error("采样数据包含非有限数值。");
    var required=n+(averages-1)*n/2;
    if(x.length<required)throw new Error("连续样本不足：需要 "+required+" 对，当前 "+x.length+" 对。");
    for(var s=0;s<averages;s++)addWindow(accumulator,x,y,x.length-required+s*n/2,false);
    return finishAccumulator(accumulator);
}

function createAccumulator(options) {
    var fs = Number(options.fs), n = Number(options.nfft), averages = Number(options.averages);
    if (!isFinite(fs) || fs <= 0) throw new Error("请输入真实采样率（Hz），必须大于 0。");
    if (n < 64 || n > 16384 || n !== Math.floor(n) || (n & (n - 1)))
        throw new Error("FFT 点数必须是 64～16384 内的 2 的整数次幂。");
    if (!isFinite(averages) || averages < 2 || averages > 9007199254740991 || averages !== Math.floor(averages))
        throw new Error("平均段数必须是至少为 2 的安全整数。");
    var coherenceLimit = options.minCoherence === undefined ? 0.8 : Number(options.minCoherence);
    var floorDb = options.powerFloorDb === undefined ? -60 : Number(options.powerFloorDb);
    if (!isFinite(coherenceLimit) || coherenceLimit < 0 || coherenceLimit > 1 || !isFinite(floorDb) || floorDb >= 0)
        throw new Error("相干性阈值或输入能量阈值无效。");
    var xx = [], yy = [], xyR = [], xyI = [], window = [], i, k;
    for (k = 0; k <= n / 2; k++) { xx[k] = 0; yy[k] = 0; xyR[k] = 0; xyI[k] = 0; }
    for (i = 0; i < n; i++) window[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / n);
    return {fs:fs,n:n,averages:averages,coherenceLimit:coherenceLimit,floorDb:floorDb,xx:xx,yy:yy,xyR:xyR,xyI:xyI,window:window,segments:0};
}

function addWindow(state,x,y,begin,circular) {
        var n=state.n,xx=state.xx,yy=state.yy,xyR=state.xyR,xyI=state.xyI,window=state.window;
        function at(i){return circular?(begin+i)%n:begin+i;}
        var bx = x[at(0)], by = y[at(0)], mx = 0, my = 0, xr = [], xi = [], yr = [], yi = [],i,k;
        // Subtract an exact sample baseline first: a constant like 0.1 must remain
        // exactly zero AC rather than acquiring a sinusoid from mean roundoff.
        for (i = 0; i < n; i++) { mx += x[at(i)] - bx; my += y[at(i)] - by; }
        mx /= n; my /= n;
        for (i = 0; i < n; i++) {
            xr[i] = ((x[at(i)] - bx) - mx) * window[i]; yr[i] = ((y[at(i)] - by) - my) * window[i];
            xi[i] = 0; yi[i] = 0;
        }
        fft(xr, xi); fft(yr, yi);
        for (k = 1; k < n / 2; k++) {
            xx[k] += xr[k] * xr[k] + xi[k] * xi[k];
            yy[k] += yr[k] * yr[k] + yi[k] * yi[k];
            xyR[k] += xr[k] * yr[k] + xi[k] * yi[k];
            xyI[k] += xr[k] * yi[k] - xi[k] * yr[k];
        }
        state.segments++;
}

function finishAccumulator(state) {
    if(state.segments!==state.averages)throw new Error("完整分段数与请求不一致。");
    var n=state.n,fs=state.fs,averages=state.segments,hop=n/2,coherenceLimit=state.coherenceLimit,floorDb=state.floorDb;
    var xx=state.xx,yy=state.yy,xyR=state.xyR,xyI=state.xyI,k;
    var peak = 0;
    for (k = 1; k < n / 2; k++) peak = Math.max(peak, xx[k]);
    var threshold = peak * Math.pow(10, floorDb / 10), points = [], lastPhase = null, phaseOffset = 0,coherences=[];
    for (k = 1; k < n / 2; k++) {
        var cross = xyR[k] * xyR[k] + xyI[k] * xyI[k];
        var coherence = xx[k] > 0 && yy[k] > 0 ? Math.min(1, cross / (xx[k] * yy[k])) : 0;
        var valid = peak > 0 && xx[k] >= threshold && xx[k] > 0 && yy[k] > 0 && cross > 0 && coherence >= coherenceLimit;
        var excited=peak>0&&xx[k]>=threshold&&xx[k]>0;
        if(excited)coherences.push(coherence);
        var phase = valid ? Math.atan2(xyI[k], xyR[k]) * 180 / Math.PI : null;
        if (valid) {
            if (lastPhase !== null) {
                while (phase + phaseOffset - lastPhase > 180) phaseOffset -= 360;
                while (phase + phaseOffset - lastPhase < -180) phaseOffset += 360;
            } else phaseOffset = 0;
            phase += phaseOffset; lastPhase = phase;
        } else { lastPhase = null; phaseOffset = 0; }
        points.push({ frequency: k * fs / n,
            gainDb: valid ? 10 * Math.log(cross / (xx[k] * xx[k])) / Math.LN10 : null,
            phaseDeg: phase, coherence: coherence, valid: valid,excited:excited });
    }
    coherences.sort(function(a,b){return a-b;});
    return { points: points, segments: averages, samples: n + (averages - 1) * hop,coherenceMedian:coherences.length?coherences[Math.floor(coherences.length/2)]:0,excitedCount:coherences.length,
        resolution: fs / n, fs: fs, nfft: n, validCount: points.filter(function(p) { return p.valid; }).length };
}
