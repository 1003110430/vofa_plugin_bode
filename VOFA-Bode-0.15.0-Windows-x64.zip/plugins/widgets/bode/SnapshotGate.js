.pragma library

function create(expectedRows, started, stableMs, timeoutMs) {
    return { expectedRows: expectedRows, started: started, stableMs: stableMs,
        timeoutMs: timeoutMs, lastText: "", stableSince: null };
}

function observe(state, text, now) {
    if (now - state.started > state.timeoutMs) throw new Error("等待宿主导出超时，请减小缓冲区后重试。");
    if (!text || text.charAt(text.length - 1) !== "\n") {
        state.lastText = ""; state.stableSince = null; return null;
    }
    var lines = text.split(/\r?\n/);
    while (lines.length && !lines[lines.length - 1].trim()) lines.pop();
    var rows = lines.length - 1;
    if (rows < state.expectedRows) { state.lastText = ""; state.stableSince = null; return null; }
    if (text !== state.lastText) { state.lastText = text; state.stableSince = now; return null; }
    if (state.stableSince === null || now - state.stableSince < state.stableMs) return null;
    return { text: text, totalRows: rows };
}
