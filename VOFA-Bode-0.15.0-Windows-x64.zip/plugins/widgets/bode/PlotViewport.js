.pragma library
function zoom(min,max,anchor,factor,logarithmic) {
    var lo=logarithmic?Math.log(min):min, hi=logarithmic?Math.log(max):max;
    anchor=Math.max(0,Math.min(1,anchor)); factor=Math.max(.01,Math.min(100,factor));
    var center=lo+(hi-lo)*anchor,span=(hi-lo)*factor;
    lo=center-span*anchor; hi=center+span*(1-anchor);
    // Bound exponent to keep repeated wheel events finite.
    if(logarithmic) {lo=Math.max(-25,Math.min(25,lo));hi=Math.max(lo+.000001,Math.min(26,hi));}
    return {min:logarithmic?Math.exp(lo):lo,max:logarithmic?Math.exp(hi):hi};
}
function pan(min,max,fraction,logarithmic) {
    var lo=logarithmic?Math.log(min):min,hi=logarithmic?Math.log(max):max,shift=(hi-lo)*fraction;
    return {min:logarithmic?Math.exp(Math.max(-25,Math.min(25,lo-shift))):lo-shift,
        max:logarithmic?Math.exp(Math.max(-24,Math.min(26,hi-shift))):hi-shift};
}
