import QtQuick 2.12
import "PlotViewport.js" as Viewport
import "AnnotationLayout.js" as AnnotationLayout

Canvas {
    id: plot
    property var points: []
    property var modelPoints: []
    onModelPointsChanged: requestPaint()
    property string valueKey: "gainDb"
    property string caption: "增益 / dB"
    property color curveColor: "#28b4e8"
    property real frequencyMin: 1
    property real frequencyMax: 1000
    property real cursorFrequency: 0
    property bool cursorPinned:false
    onCursorPinnedChanged:requestPaint()
    property bool coherencePlot: false
    property bool showZeroDb:true
    property bool showMinus180:true
    onShowZeroDbChanged:requestPaint()
    onShowMinus180Changed:requestPaint()
    property real valueMin: coherencePlot ? 0 : -20
    property real valueMax: coherencePlot ? 1 : 20
    property var annotations: []
    property real marginLeft: 65
    property real marginRight: 18
    property real marginTop: 27
    property real marginBottom: 27
    signal cursorMoved(real frequency)
    signal cursorPicked(real frequency)
    signal frequencyViewChanged(real minimum, real maximum)
    signal manualViewChanged()
    signal autoRequested()
    signal contextRequested()
    onPointsChanged: requestPaint()
    onAnnotationsChanged: requestPaint()
    onWidthChanged: requestPaint()
    onHeightChanged: requestPaint()
    onFrequencyMinChanged: requestPaint()
    onFrequencyMaxChanged: requestPaint()
    onCursorFrequencyChanged: requestPaint()
    onValueMinChanged: requestPaint()
    onValueMaxChanged: requestPaint()
    function autoY() {
        var lo=coherencePlot?0:Infinity,hi=coherencePlot?1:-Infinity;
        var all=points.concat(modelPoints);
        for(var i=0;i<all.length;i++) {
            var p=all[i],v=p[valueKey];
            if(p.frequency>=frequencyMin && p.frequency<=frequencyMax && (coherencePlot||p.valid) && !p.extrapolated && v!==null && isFinite(v)) {lo=Math.min(lo,v);hi=Math.max(hi,v);}
        }
        if(!isFinite(lo)){lo=valueKey==="phaseDeg"?-180:-20;hi=valueKey==="phaseDeg"?0:20;}
        if(!coherencePlot){var mid=(lo+hi)/2,span=Math.max(hi-lo,valueKey==="phaseDeg"?20:6);lo=mid-.6*span;hi=mid+.6*span;}
        valueMin=lo;valueMax=hi;requestPaint();
    }
    function moveView(xFraction,yFraction,anchorX,anchorY,zooming,factor) {
        manualViewChanged();
        if(xFraction!==null) {
            var x=zooming?Viewport.zoom(frequencyMin,frequencyMax,anchorX,factor,true):Viewport.pan(frequencyMin,frequencyMax,xFraction,true);
            frequencyViewChanged(x.min,x.max);
        }
        if(yFraction!==null) {
            var y=zooming?Viewport.zoom(valueMin,valueMax,anchorY,factor,false):Viewport.pan(valueMin,valueMax,yFraction,false);
            valueMin=y.min;valueMax=y.max;
        }
    }
    onPaint: {
        var c=getContext("2d");c.reset();
        var left=marginLeft,right=width-marginRight,top=marginTop,bottom=height-marginBottom;
        if(right<=left||bottom<=top)return;
        c.fillStyle="#0f1e30";c.fillRect(0,0,width,height);
        c.strokeStyle="#20354c";c.lineWidth=1;c.strokeRect(.5,.5,width-1,height-1);
        c.font="12px sans-serif";c.fillStyle="#b4c6dc";c.fillText(caption,12,17);
        var fmin=Math.max(1e-9,frequencyMin),fmax=Math.max(fmin*1.000001,frequencyMax);
        var lmin=Math.log(fmin)/Math.LN10,lmax=Math.log(fmax)/Math.LN10;
        var ymin=valueMin,ymax=Math.max(ymin+.000000001,valueMax);
        function xp(f){return left+(Math.log(f)/Math.LN10-lmin)/(lmax-lmin)*(right-left);}
        function yp(y){return bottom-(y-ymin)/(ymax-ymin)*(bottom-top);}
        c.lineWidth=1;c.strokeStyle="#25384f";
        var i,p,v;
        var divisions=bottom-top<60?2:4;
        for(i=0;i<=divisions;i++) {
            var y=top+(bottom-top)*i/divisions;
            c.beginPath();c.moveTo(left,y);c.lineTo(right,y);c.stroke();
            c.fillStyle="#8ea5bf";c.fillText((ymax-(ymax-ymin)*i/divisions).toFixed(coherencePlot?2:1),9,y+4);
        }
        for(var decade=Math.floor(lmin);decade<=Math.ceil(lmax);decade++) {
            for(var multiple=1;multiple<=9;multiple++) {
                var frequency=multiple*Math.pow(10,decade);if(frequency<fmin||frequency>fmax)continue;
                var px=xp(frequency);c.strokeStyle=multiple===1?"#364d68":"#1c2d42";
                c.beginPath();c.moveTo(px,top);c.lineTo(px,bottom);c.stroke();
                if(multiple===1 || (lmax-lmin<1.5 && (multiple===2||multiple===5))) {
                    c.fillStyle="#8ea5bf";c.fillText(frequency>=1000?(frequency/1000).toPrecision(3)+"k":String(Number(frequency.toPrecision(3))),px-10,height-7);
                }
            }
        }
        if(modelPoints.length&&!coherencePlot){c.fillStyle="#ffd17a";c.fillText("-- 辨识模型 / ·· 外推",right-175,17);}
        c.fillStyle="#8ea5bf";c.fillText("Hz",right-12,17);
        if(cursorPinned&&bottom-top<44&&cursorFrequency>=fmin&&cursorFrequency<=fmax&&points.length){
            var compactPoint=points[0];for(i=1;i<points.length;i++)if(Math.abs(points[i].frequency-cursorFrequency)<Math.abs(compactPoint.frequency-cursorFrequency))compactPoint=points[i];
            var compactValue=compactPoint[valueKey],compactValid=(coherencePlot||compactPoint.valid)&&compactValue!==null&&isFinite(compactValue);
            c.fillStyle="#fff1bb";c.font="11px sans-serif";c.fillText(compactPoint.frequency.toPrecision(5)+" Hz  |  "+(compactValid?compactValue.toFixed(coherencePlot?4:2)+(coherencePlot?"":valueKey==="gainDb"?" dB":"°"):"无可信幅相"),left+35,17);
        }
        c.save();c.beginPath();c.rect(left,top,right-left,bottom-top);c.clip();
        // Fixed engineering references use the same transform as the response curve.
        // Draw independently of optional crossover annotations and below the curve.
        var reference=valueKey==="gainDb"&&showZeroDb?0:valueKey==="phaseDeg"&&showMinus180?-180:null;
        if(reference!==null && reference>=ymin && reference<=ymax) {
            var referenceY=yp(reference), referenceColor=valueKey==="gainDb"?"#f6c85f":"#ff9585";
            c.strokeStyle=referenceColor;c.lineWidth=2;
            c.beginPath();c.moveTo(left,referenceY);c.lineTo(right,referenceY);c.stroke();
            var referenceLabel=valueKey==="gainDb"?"0 dB":"−180°";
            c.font="bold 12px sans-serif";
            var labelWidth=c.measureText(referenceLabel).width;
            var labelY=referenceY<top+20?referenceY+17:referenceY-5;
            c.fillStyle="#0f1e30";c.fillRect(right-labelWidth-12,labelY-13,labelWidth+10,17);
            c.fillStyle=referenceColor;c.fillText(referenceLabel,right-labelWidth-6,labelY);
            c.font="12px sans-serif";
        }
        c.lineWidth=1.8;c.strokeStyle=curveColor;c.beginPath();var drawing=false;
        for(i=0;i<points.length;i++) {
            p=points[i];v=p[valueKey];
            if((!coherencePlot&&!p.valid)||v===null||!isFinite(v)||p.frequency<=0){drawing=false;continue;}
            if(!drawing){c.moveTo(xp(p.frequency),yp(v));drawing=true;}else c.lineTo(xp(p.frequency),yp(v));
        }
        c.stroke();
        if(modelPoints.length&&!coherencePlot){
            c.strokeStyle="#ffd17a";c.lineWidth=2;c.beginPath();var previous=null,segment=0;
            for(i=0;i<modelPoints.length;i++){
                p=modelPoints[i];v=p[valueKey];if(!isFinite(v)){previous=null;continue;}
                var nextPoint={x:xp(p.frequency),y:yp(v),extrapolated:!!p.extrapolated};
                if(previous){c.stroke();c.beginPath();var outside=previous.extrapolated||nextPoint.extrapolated;c.strokeStyle=outside?"#9d8d70":"#ffd17a";c.lineWidth=outside?1.2:2;var dash=outside?3:6;var dx=nextPoint.x-previous.x,dy=nextPoint.y-previous.y,len=Math.sqrt(dx*dx+dy*dy),at=0;
                    while(at<len){if(dash-segment%dash<1e-7)segment=Math.ceil(segment/dash)*dash;var remaining=dash-(segment%dash),take=Math.min(remaining,len-at);if(Math.floor(segment/dash)%2===0){c.moveTo(previous.x+dx*at/len,previous.y+dy*at/len);c.lineTo(previous.x+dx*(at+take)/len,previous.y+dy*(at+take)/len);}at+=take;segment+=take;}
                }previous=nextPoint;
            }c.stroke();
        }
        if(cursorFrequency>=fmin&&cursorFrequency<=fmax) {
            c.strokeStyle="#ebc874";c.lineWidth=1;c.beginPath();c.moveTo(xp(cursorFrequency),top);c.lineTo(xp(cursorFrequency),bottom);c.stroke();
        }
        var callouts=[],occupied=[];
        for(i=0;i<annotations.length;i++) {
            var mark=annotations[i],label=AnnotationLayout.describe(mark,valueKey);if(!label)continue;if(mark.frequency<fmin||mark.frequency>fmax)continue;
            var mx=xp(mark.frequency),my=yp(mark[valueKey]);
            c.globalAlpha=.42;c.strokeStyle=mark.color;c.lineWidth=1;c.beginPath();c.moveTo(mx,top);c.lineTo(mx,bottom);c.stroke();c.globalAlpha=1;
            c.fillStyle=mark.color;c.beginPath();c.arc(mx,my,3.5,0,2*Math.PI);c.fill();
            if(!label || my<top || my>bottom || callouts.length>=12)continue;
            c.font="bold 13px sans-serif";var titleWidth=c.measureText(label.title).width;
            c.font="11px sans-serif";
            var details=label.details===undefined?[label.detail]:label.details,boxWidth=titleWidth;for(var dl=0;dl<details.length;dl++)boxWidth=Math.max(boxWidth,c.measureText(details[dl]).width);
            var box=AnnotationLayout.place(mx,my,boxWidth+18,24+15*details.length,{left:left+4,right:right-4,top:top+4,bottom:bottom-4},occupied);
            if(box){occupied.push(box);callouts.push({box:box,label:label,details:details,color:mark.color,px:mx,py:my});}
        }
        for(i=0;i<callouts.length;i++){
            var item=callouts[i],b=item.box;
            var bx=Math.max(b.x,Math.min(b.x+b.w,item.px)),by=Math.max(b.y,Math.min(b.y+b.h,item.py));
            c.globalAlpha=.8;c.strokeStyle=item.color;c.lineWidth=1;c.beginPath();c.moveTo(item.px,item.py);c.lineTo(bx,by);c.stroke();c.globalAlpha=1;
            c.fillStyle="#14283d";c.fillRect(b.x,b.y,b.w,b.h);c.strokeStyle=item.color;c.lineWidth=1;c.strokeRect(b.x+.5,b.y+.5,b.w-1,b.h-1);
            c.fillStyle=item.color;c.font="bold 13px sans-serif";c.fillText(item.label.title,b.x+9,b.y+15);
            c.fillStyle="#c3d4e6";c.font="11px sans-serif";for(var line=0;line<item.details.length;line++)c.fillText(item.details[line],b.x+9,b.y+31+15*line);
        }
        if(cursorPinned&&cursorFrequency>=fmin&&cursorFrequency<=fmax&&points.length){
            var picked=points[0];for(i=1;i<points.length;i++)if(Math.abs(points[i].frequency-cursorFrequency)<Math.abs(picked.frequency-cursorFrequency))picked=points[i];
            var pv=picked[valueKey],trusted=coherencePlot||picked.valid;
            var reading=trusted&&pv!==null&&isFinite(pv)?pv.toFixed(coherencePlot?4:2)+(coherencePlot?"":valueKey==="gainDb"?" dB":"°"):"无可信幅相";
            var title=picked.frequency.toPrecision(6)+" Hz";
            c.font="bold 12px sans-serif";var bw=Math.max(c.measureText(title).width,c.measureText(reading).width)+18;
            var cx=xp(picked.frequency),cy=trusted&&pv!==null&&isFinite(pv)?yp(pv):top+22;
            var bx=Math.max(left+3,Math.min(right-bw-3,cx+12)),by=Math.max(top+3,Math.min(bottom-43,cy-44));
            if(trusted&&pv!==null&&isFinite(pv)){c.strokeStyle="#ebc874";c.lineWidth=1;c.beginPath();c.moveTo(left,cy);c.lineTo(right,cy);c.stroke();c.fillStyle="#fff1bb";c.beginPath();c.arc(cx,cy,4,0,2*Math.PI);c.fill();}
            if(bottom-top>=44){c.fillStyle="#1b3046";c.fillRect(bx,by,bw,39);c.strokeStyle="#ebc874";c.strokeRect(bx+.5,by+.5,bw-1,38);
            c.fillStyle="#fff1bb";c.fillText(title,bx+9,by+15);c.fillStyle="#edf5ff";c.fillText(reading,bx+9,by+31);}
        }
        c.font="12px sans-serif";
        c.restore();
    }
    MouseArea {
        anchors.fill: parent;hoverEnabled:true;acceptedButtons:Qt.LeftButton|Qt.MiddleButton|Qt.RightButton;preventStealing:true
        property real lastX:0
        property real lastY:0
        property real originX:0
        property real originY:0
        property bool dragging:false
        property bool xOnly:false
        property bool yOnly:false
        onPressed: {
            lastX=originX=mouse.x;lastY=originY=mouse.y;dragging=false;
            xOnly=mouse.y>height-plot.marginBottom;yOnly=mouse.x<plot.marginLeft;
        }
        onPositionChanged: {
            var dx=(mouse.x-lastX)/Math.max(1,width-83),dy=-(mouse.y-lastY)/Math.max(1,height-54);
            if(pressed&&Math.abs(mouse.x-originX)+Math.abs(mouse.y-originY)>=6)dragging=true;
            if(pressed&&dragging&&!(pressedButtons&Qt.RightButton))plot.moveView(yOnly?null:dx,xOnly?null:dy,0,0,false,1);
            lastX=mouse.x;lastY=mouse.y;
            var fraction=Math.max(0,Math.min(1,(mouse.x-65)/Math.max(1,width-83)));
            if(plot.frequencyMin>0 && plot.frequencyMax>plot.frequencyMin)plot.cursorMoved(plot.frequencyMin*Math.pow(plot.frequencyMax/plot.frequencyMin,fraction));
        }
        onReleased: {if(mouse.button===Qt.RightButton && Math.abs(mouse.x-originX)+Math.abs(mouse.y-originY)<6)plot.contextRequested();}
        onClicked:{if(mouse.button===Qt.LeftButton&&!dragging&&Math.abs(mouse.x-originX)+Math.abs(mouse.y-originY)<6&&mouse.x>=plot.marginLeft&&mouse.y>=plot.marginTop&&mouse.y<=height-plot.marginBottom){var fraction=Math.max(0,Math.min(1,(mouse.x-plot.marginLeft)/Math.max(1,width-plot.marginLeft-plot.marginRight)));plot.cursorPicked(plot.frequencyMin*Math.pow(plot.frequencyMax/plot.frequencyMin,fraction));}}
        onDoubleClicked: {if(mouse.button===Qt.LeftButton)plot.autoRequested();}
        onWheel: {
            var ax=(wheel.x-65)/Math.max(1,width-83),ay=1-(wheel.y-27)/Math.max(1,height-54);
            var factor=Math.pow(1.2,-wheel.angleDelta.y/120);
            plot.moveView(wheel.x<65?null:0,wheel.y>height-27?null:0,ax,ay,true,factor);
            wheel.accepted=true;
        }
    }
}
