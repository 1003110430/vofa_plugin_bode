import QtQuick 2.12
import QtQuick.Controls 2.5
Button {
 id: control
 property bool primary: false
 implicitHeight: 34; implicitWidth: Math.max(76, contentItem.implicitWidth+26)
 padding: 12; font.family:"Microsoft YaHei";font.pixelSize:12
 contentItem: Text {text:control.text;font:control.font;color:control.enabled?(control.primary?"#071824":"#d7e5f5"):"#65778f";horizontalAlignment:Text.AlignHCenter;verticalAlignment:Text.AlignVCenter}
 background: Rectangle {radius:7;color:!control.enabled?"#142237":control.primary?(control.down?"#39b6d5":control.hovered?"#80e1f1":"#56cce4"):(control.checked?"#23435a":control.down?"#263b53":control.hovered?"#22354d":"#182b41");border.width:1;border.color:control.checked?"#4398ad":"#2b405b"}
}
