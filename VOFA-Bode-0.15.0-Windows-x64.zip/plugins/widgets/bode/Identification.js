.pragma library
// Continuous-time SISO frequency-domain identification. No external runtime.
// Scaled polynomial SK initialization, QR least squares, stable LM refinement.
function mul(a,b){return [a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]];}
function div(a,b){var d=b[0]*b[0]+b[1]*b[1];return [(a[0]*b[0]+a[1]*b[1])/d,(a[1]*b[0]-a[0]*b[1])/d];}
function poly(a,q){var v=[0,0];for(var k=a.length-1;k>=0;k--){v=mul(v,q);v[0]+=a[k];}return v;}
function powers(q,n){var p=[[1,0]];for(var k=1;k<=n;k++)p.push(mul(p[k-1],q));return p;}
function stable(a){
    var n=a.length-1,cols=Math.ceil((n+1)/2),rows=[],i,j;
    if(n<1||a[n]<=0)return false;
    for(i=0;i<2;i++){rows[i]=[];for(j=0;j<cols;j++)rows[i][j]=n-i-2*j>=0?a[n-i-2*j]:0;}
    function normalize(row){var max=0;for(var k=0;k<row.length;k++)max=Math.max(max,Math.abs(row[k]));if(max)for(k=0;k<row.length;k++)row[k]/=max;}
    normalize(rows[0]);normalize(rows[1]);
    if(rows[0][0]<=0||rows[1][0]<=0)return false;
    for(i=2;i<=n;i++){
        rows[i]=[];
        for(j=0;j<cols;j++)rows[i][j]=((rows[i-1][0]*(rows[i-2][j+1]||0)-rows[i-2][0]*(rows[i-1][j+1]||0))/rows[i-1][0]);
        if(!isFinite(rows[i][0])||rows[i][0]<=0)return false;
        normalize(rows[i]);
    }
    return true;
}
// Twice reorthogonalized, column-scaled QR. Avoids squaring the condition number.
function leastSquares(rows,rhs){
    var m=rows.length,n=rows[0].length,Q=[],R=[],scale=[],i,j,k,v,s,norm;
    if(m<n)throw new Error("有效频点不足，无法确定该阶次模型。");
    for(j=0;j<n;j++){
        v=[];norm=0;for(i=0;i<m;i++){v[i]=rows[i][j];norm+=v[i]*v[i];}
        scale[j]=Math.sqrt(norm);if(!(scale[j]>1e-100))throw new Error("辨识矩阵退化，请扩大激励频段或降低阶次。");
        for(i=0;i<m;i++)v[i]/=scale[j];
        for(k=0;k<j;k++)R[k][j]=0;
        for(var pass=0;pass<2;pass++)for(k=0;k<j;k++){
            s=0;for(i=0;i<m;i++)s+=Q[k][i]*v[i];R[k][j]+=s;
            for(i=0;i<m;i++)v[i]-=s*Q[k][i];
        }
        norm=0;for(i=0;i<m;i++)norm+=v[i]*v[i];norm=Math.sqrt(norm);
        if(norm<1e-10)throw new Error("模型阶次过高或频段过窄，辨识矩阵病态。");
        R[j]=[];R[j][j]=norm;for(i=0;i<m;i++)v[i]/=norm;Q[j]=v;
    }
    var z=[],answer=[];
    for(j=n-1;j>=0;j--){s=0;for(i=0;i<m;i++)s+=Q[j][i]*rhs[i];for(k=j+1;k<n;k++)s-=R[j][k]*z[k];z[j]=s/R[j][j];}
    for(j=0;j<n;j++)answer[j]=z[j]/scale[j];return answer;
}
function prepare(x,y,options){
    var trim=Number(options.trimPercent||0);
    if(!isFinite(trim)||trim<0||trim>40)throw new Error("过渡段剔除比例须为 0～40%。");
    var start=Math.floor(x.length*trim/100),xx=x.slice(start),yy=y.slice(start);
    if(x.length!==y.length)throw new Error("输入输出长度不一致。");
    for(var i=0;i<xx.length;i++)if(!isFinite(xx[i])||!isFinite(yy[i]))throw new Error("时域数据含非有限值。");
    if(xx.length<256)throw new Error("剔除过渡段后样本不足。");
    // Train/validation detrending is deliberately performed by the caller after splitting.
    return {x:xx,y:yy,removed:start};
}
function detrendPair(x,y,linear){
    function one(a){var n=a.length,c=(n-1)/2,base=a[0],mean=0,s=0,d=0,i;for(i=0;i<n;i++)mean+=a[i]-base;mean/=n;
        if(linear)for(i=0;i<n;i++){s+=(i-c)*(a[i]-base-mean);d+=(i-c)*(i-c);}
        s=d?s/d:0;for(i=0;i<n;i++)a[i]=a[i]-base-mean-s*(i-c);return a;}
    return {x:one(x.slice()),y:one(y.slice())};
}
function samples(points,lo,hi,delay){
    var out=[];
    for(var i=0;i<points.length;i++){
        var p=points[i];if(!p.valid||p.frequency<lo||p.frequency>hi||!isFinite(p.gainDb)||!isFinite(p.phaseDeg))continue;
        var mag=Math.pow(10,p.gainDb/20),angle=p.phaseDeg*Math.PI/180+2*Math.PI*p.frequency*delay;
        if(!(mag>1e-12)||!isFinite(mag))continue;
        out.push({f:p.frequency,h:[mag*Math.cos(angle),mag*Math.sin(angle)],coherence:p.coherence,mag:mag});
    }
    // Bounded CPU/memory. Uniform frequency subsampling retains original values, no smoothing.
    if(out.length>900){var selected=[];for(i=0;i<900;i++)selected.push(out[Math.round(i*(out.length-1)/899)]);out=selected;}
    return out;
}
function evaluate(model,f){var h=div(poly(model.b,[0,2*Math.PI*f/model.scale]),poly(model.a,[0,2*Math.PI*f/model.scale]));return mul(h,[Math.cos(-2*Math.PI*f*model.delay),Math.sin(-2*Math.PI*f*model.delay)]);}
function prepareFrequencyPoints(points,options){
    var out=[],smoothed=0;
    for(var i=0;i<points.length;i++){
        var p=points[i],copy={};for(var key in p)copy[key]=p[key];
        // Only weak-coherence, contiguous training bins are smoothed in complex form.
        // Sharp coherent resonances and invalid gaps remain untouched.
        if(options.noiseAssist&&p.valid&&p.coherence<.7&&i>0&&i+1<points.length){
            var left=points[i-1],right=points[i+1];
            if(left.valid&&right.valid&&left.coherence<.85&&right.coherence<.85&&right.frequency/left.frequency<1.5){
                var re=0,im=0,total=0;
                for(var j=i-1;j<=i+1;j++){var a=points[j],w=(j===i?2:1)*Math.max(.01,a.coherence),mag=Math.pow(10,a.gainDb/20),phase=a.phaseDeg*Math.PI/180;re+=w*mag*Math.cos(phase);im+=w*mag*Math.sin(phase);total+=w;}
                re/=total;im/=total;var gain=Math.sqrt(re*re+im*im);
                if(gain>0){copy.gainDb=20*Math.log(gain)/Math.LN10;copy.phaseDeg=Math.atan2(im,re)*180/Math.PI+360*Math.round((p.phaseDeg-Math.atan2(im,re)*180/Math.PI)/360);smoothed++;}
            }
        }
        out.push(copy);
    }
    return {points:out,smoothed:smoothed};
}
function fit(points,options){
    var n=Number(options.poles),m=Number(options.zeros),delay=Number(options.delayMs||0)/1000;
    if(n!==Math.floor(n)||n<1||n>6||m!==Math.floor(m)||m<0||m>n)throw new Error("支持 1～6 个极点，零点数须在 0～极点数之间。");
    if(!isFinite(delay)||delay<0||delay>10)throw new Error("已知延迟须为 0～10000 ms。");
    var lo=Number(options.minHz||0),hi=Number(options.maxHz||0)||Infinity;
    if(!isFinite(lo)||lo<0||!(hi>lo))throw new Error("辨识频段无效。");
    var data=samples(points,lo,hi,delay),d=n+m+1;
    if(data.length<Math.max(6,2*d))throw new Error("可信频点不足：辨识频段内仅 "+data.length+" 个，需要至少 "+Math.max(6,2*d)+" 个；请扩大稳态宽带选区、降低阶次，或调整独立的辨识相干性门槛。");
    if(data[data.length-1].f/data[0].f<2)throw new Error("辨识频段过窄，至少应覆盖 2 倍频率范围。");
    var scale=2*Math.PI*data[data.length-1].f,previous=null,best=null,bestCost=Infinity,i,j,k;
    for(i=0;i<data.length;i++){
        var t=data[i];t.p=powers([0,2*Math.PI*t.f/scale],n);
        // Coherence weighting with inverse-square-root magnitude weighting in residual.
        t.w=Math.sqrt(Math.max(.01,Math.min(1,t.coherence)))/Math.sqrt(t.mag);
        if(options.noiseAssist)t.w*=Math.max(.01,t.coherence);
    }
    function unpack(z){var a=z.slice(0,n);a.push(1);return {a:a,b:z.slice(n),scale:scale,delay:delay};}
    function prediction(mod,t){return div(poly(mod.b,[0,2*Math.PI*t.f/scale]),poly(mod.a,[0,2*Math.PI*t.f/scale]));}
    var magnitudes=[];for(i=0;i<data.length;i++)magnitudes.push(Math.sqrt(data[i].mag));
    magnitudes.sort(function(a,b){return a-b;});
    var huber=Math.max(1e-12,.03*magnitudes[Math.floor(magnitudes.length/2)]);
    function cost(mod){var s=0;for(var l=0;l<data.length;l++){var h=prediction(mod,data[l]),er=h[0]-data[l].h[0],ei=h[1]-data[l].h[1],r=Math.sqrt(er*er+ei*ei)*data[l].w;s+=options.robust&&r>huber?2*huber*r-huber*huber:r*r;}return isFinite(s)?s:Infinity;}
    function consider(mod){var c=cost(mod);if((!options.enforceStable||stable(mod.a))&&c<bestCost){best=mod;bestCost=c;}}
    // SK solves linearized rational equations, reweighting by previous denominator.
    for(var iteration=0;iteration<12;iteration++){
        var rows=[],rhs=[];
        for(i=0;i<data.length;i++){
            t=data[i];var aold=previous?poly(previous.a,[0,2*Math.PI*t.f/scale]):[1,0];
            var w=t.w/Math.max(1e-10,Math.sqrt(aold[0]*aold[0]+aold[1]*aold[1])),rr=[],ri=[];
            for(j=0;j<n;j++){var hp=mul(t.h,t.p[j]);rr.push(-hp[0]*w);ri.push(-hp[1]*w);}
            for(j=0;j<=m;j++){rr.push(t.p[j][0]*w);ri.push(t.p[j][1]*w);}
            hp=mul(t.h,t.p[n]);rows.push(rr,ri);rhs.push(hp[0]*w,hp[1]*w);
        }
        try{previous=unpack(leastSquares(rows,rhs));consider(previous);}catch(e){break;}
    }
    // Stable real-pole seeds allow constrained refinement if noisy SK is unstable.
    if(!best||options.noiseAssist)for(var seed=0;seed<4;seed++){
        var den=[1],f0=Math.sqrt(data[0].f*data[data.length-1].f)*Math.pow(3,seed-1.5);
        for(k=0;k<n;k++){var pole=2*Math.PI*f0*Math.pow(2,k-(n-1)/2)/scale,next=[];for(j=0;j<den.length+1;j++)next[j]=(j<den.length?den[j]*pole:0)+(j?den[j-1]:0);den=next;}
        var seedModel={a:den,b:[],scale:scale,delay:delay},sr=[],sv=[];
        for(i=0;i<data.length;i++){t=data[i];var ap=poly(den,[0,2*Math.PI*t.f/scale]),real=[],imag=[];for(j=0;j<=m;j++){var basis=div(t.p[j],ap);real.push(basis[0]*t.w);imag.push(basis[1]*t.w);}sr.push(real,imag);sv.push(t.h[0]*t.w,t.h[1]*t.w);}
        try{seedModel.b=leastSquares(sr,sv);consider(seedModel);}catch(seedError){}
    }
    if(!best)throw new Error("没有找到稳定的可用初始模型，请降低阶次或检查数据。");
    var lambda=.001,accepted=0;
    for(iteration=0;iteration<45;iteration++){
        rows=[];rhs=[];var norms=[];for(j=0;j<d;j++)norms[j]=0;
        var errors=[];
        for(i=0;i<data.length;i++){var ph=prediction(best,data[i]);errors.push(Math.sqrt(Math.pow(ph[0]-data[i].h[0],2)+Math.pow(ph[1]-data[i].h[1],2))*data[i].w);}
        for(i=0;i<data.length;i++){
            t=data[i];var q=[0,2*Math.PI*t.f/scale],ap=poly(best.a,q),h=prediction(best,t),jr=[],ji=[];
            w=t.w*(options.robust?Math.sqrt(Math.min(1,huber/Math.max(1e-12,errors[i]))):1);
            for(j=0;j<d;j++){var derivative=j<n?div(mul([-h[0],-h[1]],t.p[j]),ap):div(t.p[j-n],ap);jr[j]=derivative[0]*w;ji[j]=derivative[1]*w;norms[j]+=jr[j]*jr[j]+ji[j]*ji[j];}
            rows.push(jr,ji);rhs.push((t.h[0]-h[0])*w,(t.h[1]-h[1])*w);
        }
        for(j=0;j<d;j++){var ridge=[];for(k=0;k<d;k++)ridge[k]=j===k?Math.sqrt(lambda*Math.max(norms[j],1e-24)):0;rows.push(ridge);rhs.push(0);}
        var step;try{step=leastSquares(rows,rhs);}catch(e){break;}
        var z=best.a.slice(0,n).concat(best.b),candidate=null,oldCost=bestCost;
        for(var fraction=1;fraction>=1/128;fraction/=2){var nz=[];for(j=0;j<d;j++)nz[j]=z[j]+step[j]*fraction;var trial=unpack(nz);if((!options.enforceStable||stable(trial.a))&&cost(trial)<bestCost){candidate=trial;break;}}
        if(candidate){consider(candidate);accepted++;lambda=Math.max(1e-9,lambda/3);if(oldCost-bestCost<1e-11*Math.max(1,oldCost))break;}
        else{lambda*=10;if(lambda>1e9)break;}
    }
    best.stable=stable(best.a);best.poles=n;best.zeros=m;best.fitMin=data[0].f;best.fitMax=data[data.length-1].f;best.frequencyCount=data.length;best.iterations=accepted;
    best.denominator=[];best.numerator=[];
    for(j=n;j>=0;j--)best.denominator.push(best.a[j]*Math.pow(scale,n-j));
    for(j=m;j>=0;j--)best.numerator.push(best.b[j]*Math.pow(scale,n-j));
    best.method="Scaled SK initialization + QR weighted complex output-error LM";
    best.supportRanges=trustedRanges(options.supportPoints||options.assessmentPoints||points,best.fitMin,best.fitMax);best.validationKind=options.validationKind||"time";best.training=metrics(best,options.assessmentPoints||points);best.minimumFrequencyCount=Math.max(6,2*d);best.limitedSupport=data.length<Math.max(12,3*d);return best;
}
function metrics(model,points){
    var data=samples(points,model.fitMin,model.fitMax,0),e=0,energy=0,db=0,phase=0,count=0;
    for(var i=0;i<data.length;i++){var t=data[i],h=evaluate(model,t.f),mag=Math.sqrt(h[0]*h[0]+h[1]*h[1]);if(!(mag>0))continue;
        var diff=Math.atan2(h[1],h[0])-Math.atan2(t.h[1],t.h[0]);diff=Math.atan2(Math.sin(diff),Math.cos(diff))*180/Math.PI;
        e+=Math.pow(h[0]-t.h[0],2)+Math.pow(h[1]-t.h[1],2);energy+=t.mag*t.mag;db+=Math.pow(20*Math.log(mag/t.mag)/Math.LN10,2);phase+=diff*diff;count++;}
    if(count<6||!(energy>0))throw new Error("评估时段在辨识频段内仅 "+count+" 个可信频点（至少需要6个）；请增加该时段宽带激励与平均段数，或调整辨识相干性门槛。");
    return {points:count,relativeErrorPercent:100*Math.sqrt(e/energy),gainRmseDb:Math.sqrt(db/count),phaseRmseDeg:Math.sqrt(phase/count)};
}
function trustedRanges(points,lo,hi){
    var ranges=[],current=null,step=points.length>1?points[1].frequency-points[0].frequency:0;
    for(var i=0;i<points.length;i++){var p=points[i];if(p.frequency<lo||p.frequency>hi||!p.valid){current=null;continue;}
        if(!current){current={min:Math.max(lo,p.frequency-step/2),max:Math.min(hi,p.frequency+step/2)};ranges.push(current);}else current.max=Math.min(hi,p.frequency+step/2);
    }return ranges;
}
function supportedAt(model,frequency){
    if(frequency<model.fitMin||frequency>model.fitMax)return false;
    if(!model.supportRanges)return true;
    for(var i=0;i<model.supportRanges.length;i++)if(frequency>=model.supportRanges[i].min&&frequency<=model.supportRanges[i].max)return true;
    return false;
}
function coverage(model,points){
    var total=0,covered=0,lo=Infinity,hi=0;
    for(var i=0;i<points.length;i++){var p=points[i];if(!p.valid)continue;total++;lo=Math.min(lo,p.frequency);hi=Math.max(hi,p.frequency);if(supportedAt(model,p.frequency))covered++;}
    return {trustedMeasurementPoints:total,coveredMeasurementPoints:covered,percent:total?100*covered/total:null,referenceMin:total?lo:null,referenceMax:total?hi:null};
}
function curve(model,points,options){
    options=options||{};
    var lo=options.fullRange?Number(options.minimum):model.fitMin,hi=options.fullRange?Number(options.maximum):model.fitMax;
    if(!(lo>0)||!isFinite(hi)||hi<=lo)return [];
    var frequencies=[],i;for(i=0;i<600;i++)frequencies.push(lo*Math.pow(hi/lo,i/599));
    for(i=0;i<2;i++){var edge=i?model.fitMax:model.fitMin;if(edge>=lo&&edge<=hi)frequencies.push(edge);}
    if(model.supportRanges)for(i=0;i<model.supportRanges.length;i++){var r=model.supportRanges[i];if(r.min>=lo&&r.min<=hi)frequencies.push(r.min);if(r.max>=lo&&r.max<=hi)frequencies.push(r.max);}
    frequencies.sort(function(a,b){return a-b;});var out=[],last=null;
    for(i=0;i<frequencies.length;i++){
        var f=frequencies[i];if(i&&Math.abs(f-frequencies[i-1])<1e-10*Math.max(1,f))continue;
        var h=evaluate(model,f),mag=Math.sqrt(h[0]*h[0]+h[1]*h[1]),angle=Math.atan2(h[1],h[0])*180/Math.PI;
        if(!(mag>0)||!isFinite(mag)||!isFinite(angle)){last=null;continue;}
        if(last!==null){while(angle-last>180)angle-=360;while(angle-last< -180)angle+=360;}last=angle;
        out.push({frequency:f,gainDb:20*Math.log(mag)/Math.LN10,phaseDeg:angle,valid:true,extrapolated:!supportedAt(model,f)});
    }
    // Anchor the phase branch to a trusted measured bin inside the fitted band.
    var anchor=null;for(i=0;i<points.length;i++)if(points[i].valid&&supportedAt(model,points[i].frequency)){anchor=points[i];break;}
    if(anchor&&out.length){var nearest=0;for(i=1;i<out.length;i++)if(Math.abs(Math.log(out[i].frequency/anchor.frequency))<Math.abs(Math.log(out[nearest].frequency/anchor.frequency)))nearest=i;var offset=360*Math.round((anchor.phaseDeg-out[nearest].phaseDeg)/360);for(i=0;i<out.length;i++)out[i].phaseDeg+=offset;}
    return out;
}
function equation(model){
    function format(a){var terms=[];for(var i=0;i<a.length;i++){var power=a.length-1-i,v=a[i];if(Math.abs(v)<1e-100)continue;terms.push((terms.length?(v<0?" − ":" + "):(v<0?"−":""))+Math.abs(v).toPrecision(5)+(power?"·s"+(power>1?"^"+power:""):""));}return terms.join("")||"0";}
    return "G(s) = ("+format(model.numerator)+") / ("+format(model.denominator)+")"+(model.delay?" · exp(−"+model.delay.toPrecision(4)+"s)":"");
}
// Model-order selection uses held-out time-window FRFs, never training error alone.
// Choose the simplest candidate within an explicit tolerance of the best validation error.
function createOrderSearch(training,validation,options){
    if(!validation||validation.length<6)throw new Error("自动选阶需要有效的留出时段验证数据。");
    var max=Number(options.maxPoles),fixed=Number(options.zeros),jobs=[];
    if(max!==Math.floor(max)||max<1||max>6)throw new Error("自动选阶上限须为 1～6。");
    if(!options.autoZeros&&(fixed!==Math.floor(fixed)||fixed<0||fixed>max))throw new Error("固定零点数不能超过极点搜索上限。");
    for(var n=1;n<=max;n++){
        var start=options.autoZeros?0:fixed,end=options.autoZeros?n:fixed;
        for(var m=start;m<=end;m++)if(m<=n)jobs.push({poles:n,zeros:m});
    }
    return {training:training,validation:validation,options:options,jobs:jobs,index:0,candidates:[],models:[]};
}
function stepOrderSearch(search){
    if(search.index>=search.jobs.length)return false;
    var job=search.jobs[search.index++],options={},key;
    for(key in search.options)options[key]=search.options[key];
    options.poles=job.poles;options.zeros=job.zeros;
    var summary={poles:job.poles,zeros:job.zeros,parameters:job.poles+job.zeros+1};
    try{
        var model=fit(search.training,options);
        model.validation=metrics(model,search.validation);
        if(!isFinite(model.validation.relativeErrorPercent))throw new Error("验证误差非有限。");
        summary.ok=true;summary.trainingErrorPercent=model.training.relativeErrorPercent;
        summary.validationErrorPercent=model.validation.relativeErrorPercent;summary.stable=model.stable;
        summary.gainRmseDb=model.validation.gainRmseDb;summary.phaseRmseDeg=model.validation.phaseRmseDeg;
        search.models.push(model);
    }catch(e){summary.ok=false;summary.reason=String(e.message||e);}
    search.candidates.push(summary);return true;
}
function finishOrderSearch(search){
    if(search.index<search.jobs.length)throw new Error("自动选阶尚未完成。");
    if(!search.models.length){var counts={},details=[];for(var ci=0;ci<search.candidates.length;ci++){var reason=search.candidates[ci].reason||"未知原因",category=/频点不足|可信频点/.test(reason)?"可信频点不足":/病态|退化/.test(reason)?"矩阵病态":/稳定/.test(reason)?"稳定初值失败":/频段过窄/.test(reason)?"频段过窄":"其他";counts[category]=(counts[category]||0)+1;}for(var categoryName in counts)details.push(categoryName+" "+counts[categoryName]+" 组");throw new Error("所有候选模型均不可用。"+details.join("；")+"。首个原因："+(search.candidates[0]?search.candidates[0].reason:"没有候选组合"));}
    var best=Infinity,i;
    for(i=0;i<search.models.length;i++)best=Math.min(best,search.models[i].validation.relativeErrorPercent);
    var tolerance=Math.max(.25,.05*best),eligible=[];
    for(i=0;i<search.models.length;i++)if(search.models[i].validation.relativeErrorPercent<=best+tolerance)eligible.push(search.models[i]);
    eligible.sort(function(a,b){return (a.poles+a.zeros)-(b.poles+b.zeros)||a.poles-b.poles||a.validation.relativeErrorPercent-b.validation.relativeErrorPercent;});
    var selected=eligible[0];
    selected.orderSelection={method:(search.options.validationKind==="frequency"?"Interleaved frequency-bin holdout within one recording":"Held-out time-window validation")+"; simplest within max(0.25 percentage points, 5% of minimum error)",maxPoles:search.options.maxPoles,autoZeros:!!search.options.autoZeros,fixedZeros:search.options.autoZeros?null:search.options.zeros,minimumValidationErrorPercent:best,tolerancePercentagePoints:tolerance,selectedPoles:selected.poles,selectedZeros:selected.zeros,atPoleLimit:selected.poles===Number(search.options.maxPoles),attempted:search.candidates.length,successful:search.models.length,candidates:search.candidates};
    return selected;
}
