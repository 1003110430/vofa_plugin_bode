import QtQuick 2.12
import QtQuick.Controls 2.5
import "IdentificationDisplay.js" as Display

Rectangle {
    id:formula
    objectName:"bode-formula"
    property var model:null
    implicitHeight:104
    color:"#0c1a2c";radius:7;border.color:"#28435d"
    Text {anchors.left:parent.left;anchors.leftMargin:12;anchors.top:parent.top;anchors.topMargin:7;text:"连续域传递函数";font.pixelSize:10;color:"#7899b8"}
    Flickable {
        id:formulaScroll;anchors.left:parent.left;anchors.right:parent.right;anchors.top:parent.top;anchors.bottom:parent.bottom
        anchors.leftMargin:12;anchors.rightMargin:12;anchors.topMargin:24;anchors.bottomMargin:7
        contentWidth:Math.max(width,equationRow.width);contentHeight:height;clip:true;boundsBehavior:Flickable.StopAtBounds
        ScrollBar.horizontal:ScrollBar {policy:ScrollBar.AsNeeded}
        Row {
            id:equationRow;spacing:12;anchors.verticalCenter:parent.verticalCenter
            Text {anchors.verticalCenter:parent.verticalCenter;text:"<i>G</i>(<i>s</i>) =";textFormat:Text.RichText;font.family:"Cambria";font.pixelSize:20;color:"#f3d48d"}
            Column {
                id:fraction;spacing:4;anchors.verticalCenter:parent.verticalCenter
                width:Math.max(numerator.implicitWidth,denominator.implicitWidth)+18
                Text {id:numerator;objectName:"bode-numerator";anchors.horizontalCenter:parent.horizontalCenter;text:formula.model?Display.polynomialRich(formula.model.numerator):"—";textFormat:Text.RichText;font.family:"Cambria";font.pixelSize:18;color:"#f5ddb0"}
                Rectangle {width:parent.width;height:1;color:"#c8af7f"}
                Text {id:denominator;objectName:"bode-denominator";anchors.horizontalCenter:parent.horizontalCenter;text:formula.model?Display.polynomialRich(formula.model.denominator):"—";textFormat:Text.RichText;font.family:"Cambria";font.pixelSize:18;color:"#f5ddb0"}
            }
            Text {visible:formula.model!==null&&formula.model.delay>0;anchors.verticalCenter:parent.verticalCenter;text:formula.model?"· e<sup>−"+Number(formula.model.delay.toPrecision(5))+"s</sup>":"";textFormat:Text.RichText;font.family:"Cambria";font.pixelSize:17;color:"#f3d48d"}
        }
    }
}
