import QtQuick 2.12
import QtQuick.Layouts 1.12
import "FrequencyRange.js" as Range

Item {
    id:nav;objectName:"bode-frequency-navigator";implicitHeight:68;opacity:enabled?1:.45
    property real fullMin:1
    property real fullMax:10000
    property real viewMin:1
    property real viewMax:1000
    property var points:[]
    signal rangeChanged(real minimum,real maximum)
    signal autoRequested()
    signal fullRequested()
    function hz(f){return f>=10000?(f/1000).toPrecision(4)+" kHz":f.toPrecision(5)+" Hz";}
    function adjust(kind,delta){var r=Range.drag(viewMin,viewMax,fullMin,fullMax,kind,delta);if(r)rangeChanged(r.min,r.max);}
    RowLayout {
        anchors.left:parent.left;anchors.right:parent.right;anchors.top:parent.top;height:27;spacing:8
        BodeLabel{text:"横轴频率";font.pixelSize:11;color:"#88adc5"}
        BodeLabel{Layout.fillWidth:true;text:nav.hz(nav.viewMin)+"  ～  "+nav.hz(nav.viewMax);font.pixelSize:11;color:"#b6dedb"}
        BodeLabel{text:"拖端点缩放 · 拖中间平移";font.pixelSize:10;color:"#6e8ca5"}
        BodeButton{text:"横轴 Auto";implicitHeight:26;onClicked:nav.autoRequested()}
        BodeButton{text:"全频段";implicitHeight:26;onClicked:nav.fullRequested()}
    }
    Rectangle {
        id:track;x:65;y:31;width:Math.max(1,parent.width-83);height:23;radius:4;color:"#12273b";border.color:"#28445c"
        property real leftEdge:Range.fraction(nav.viewMin,nav.fullMin,nav.fullMax)*width
        property real rightEdge:Range.fraction(nav.viewMax,nav.fullMin,nav.fullMax)*width
        Canvas {
            id:overview;anchors.fill:parent
            onPaint:{var c=getContext("2d");c.reset();var lo=Infinity,hi=-Infinity,i,p;for(i=0;i<nav.points.length;i++){p=nav.points[i];if(p.valid&&isFinite(p.gainDb)){lo=Math.min(lo,p.gainDb);hi=Math.max(hi,p.gainDb);}}if(!isFinite(lo))return;c.strokeStyle="#446885";c.lineWidth=1;c.beginPath();var drawing=false;for(i=0;i<nav.points.length;i++){p=nav.points[i];if(!p.valid||!isFinite(p.gainDb)){drawing=false;continue;}var x=Range.fraction(p.frequency,nav.fullMin,nav.fullMax)*width,y=height-3-(p.gainDb-lo)/Math.max(1,hi-lo)*(height-6);if(!drawing)c.moveTo(x,y);else c.lineTo(x,y);drawing=true;}c.stroke();}
        }
        Rectangle{x:track.leftEdge;y:1;width:Math.max(0,track.rightEdge-track.leftEdge);height:parent.height-2;radius:3;color:"#205953";opacity:.65;border.color:"#5ed8c0"}
        Rectangle{x:(track.leftEdge+track.rightEdge)/2-9;y:10;width:18;height:3;radius:1.5;color:"#7be2cc"}
        Rectangle{x:track.leftEdge-4;y:2;width:8;height:parent.height-4;radius:4;color:"#5ce2bd"}
        Rectangle{x:track.rightEdge-4;y:2;width:8;height:parent.height-4;radius:4;color:"#bc8bf2"}
        MouseArea {
            anchors.fill:parent;hoverEnabled:true;preventStealing:true;cursorShape:pressed?Qt.ClosedHandCursor:Math.abs(mouseX-track.leftEdge)<12||Math.abs(mouseX-track.rightEdge)<12?Qt.SizeHorCursor:Qt.OpenHandCursor
            property string mode:"pan"
            property real origin:0
            property real initialMin:1
            property real initialMax:1000
            onPressed:{
                var dl=Math.abs(mouse.x-track.leftEdge),dr=Math.abs(mouse.x-track.rightEdge);
                mode=dl<12&&dr<12?(mouse.y<height/2?"left":"right"):dl<12?"left":dr<12?"right":"pan";
                origin=mouse.x;initialMin=nav.viewMin;initialMax=nav.viewMax;
                if(mode==="pan"&&(mouse.x<track.leftEdge||mouse.x>track.rightEdge)){var center=(track.leftEdge+track.rightEdge)/2,shifted=Range.drag(initialMin,initialMax,nav.fullMin,nav.fullMax,"pan",(mouse.x-center)/width);if(shifted){initialMin=shifted.min;initialMax=shifted.max;nav.rangeChanged(initialMin,initialMax);}}
            }
            onPositionChanged:if(pressed){var r=Range.drag(initialMin,initialMax,nav.fullMin,nav.fullMax,mode,(mouse.x-origin)/width);if(r)nav.rangeChanged(r.min,r.max);}
            onDoubleClicked:nav.autoRequested()
            onWheel:{var a=Range.fraction(nav.viewMin,nav.fullMin,nav.fullMax),b=Range.fraction(nav.viewMax,nav.fullMin,nav.fullMax),anchor=Math.max(0,Math.min(1,wheel.x/width)),factor=Math.pow(1.2,-wheel.angleDelta.y/120),span=Math.max(.001,Math.min(1,(b-a)*factor)),relative=(anchor-a)/Math.max(.001,b-a),start=Math.max(0,Math.min(1-span,anchor-span*relative));nav.rangeChanged(Range.frequency(start,nav.fullMin,nav.fullMax),Range.frequency(start+span,nav.fullMin,nav.fullMax));wheel.accepted=true;}
        }
    }
    BodeLabel{x:65;y:55;text:nav.hz(nav.fullMin);font.pixelSize:9;color:"#688aa4"}
    BodeLabel{anchors.right:parent.right;anchors.rightMargin:18;y:55;text:nav.hz(nav.fullMax);font.pixelSize:9;color:"#688aa4"}
    function redrawOverview(){if(overview)overview.requestPaint();}
    onPointsChanged:redrawOverview()
    onFullMinChanged:redrawOverview()
    onFullMaxChanged:redrawOverview()
    onWidthChanged:redrawOverview()
    onHeightChanged:redrawOverview()
}
