.pragma library

function splitRow(line) {
    var result = [], field = "", quoted = false;
    for (var i = 0; i < line.length; i++) {
        var c = line.charAt(i);
        if (c === '"') {
            if (quoted && line.charAt(i + 1) === '"') { field += '"'; i++; }
            else quoted = !quoted;
        } else if (c === ',' && !quoted) { result.push(field); field = ""; }
        else field += c;
    }
    if (quoted) throw new Error("CSV 引号未闭合。");
    result.push(field); return result;
}

function parse(text, inputIndex, outputIndex, maxPairs, interval) {
    if (!isFinite(maxPairs) || maxPairs < 1 || maxPairs !== Math.floor(maxPairs)) throw new Error("分析窗口无效。");
    var lines = text.replace(/^\uFEFF/, "").split(/\r?\n/);
    while (lines.length && !lines[lines.length - 1].trim()) lines.pop();
    if (lines.length < 2) throw new Error("采样缓冲区为空；请先连接并接收数据。");
    var headers = splitRow(lines[0]);
    if (inputIndex < 0 || outputIndex < 0 || inputIndex !== Math.floor(inputIndex) || outputIndex !== Math.floor(outputIndex) || inputIndex >= headers.length || outputIndex >= headers.length)
        throw new Error("所选通道不在当前缓冲区中，请重新选择。");
    var first=interval?interval.start:0, end=interval?interval.end:lines.length-1;
    if(first<0 || end>lines.length-1 || end<=first || first!==Math.floor(first) || end!==Math.floor(end)) throw new Error("快照与所选区间不匹配，请暂停接收后重试。");
    var begin = Math.max(first+1, end+1-maxPairs), x = [], y = [];
    // Only the latest complete window is analysed; no missing row may be skipped inside it.
    for (var i = begin; i < end+1; i++) {
        var values = splitRow(lines[i]);
        if (values.length !== headers.length) throw new Error("CSV 第 " + (i + 1) + " 行通道数不一致，不能保证连续采样。");
        var sx = values[inputIndex].trim(), sy = values[outputIndex].trim();
        var vx = Number(sx), vy = Number(sy);
        if (!sx || !sy || !isFinite(vx) || !isFinite(vy)) throw new Error("CSV 第 " + (i + 1) + " 行采样无效。");
        x.push(vx); y.push(vy);
    }
    return { x: x, y: y, headers: headers, totalRows: lines.length - 1 };
}

// Native ColorBar indices include the unfilled prefix of the logical buffer.
// CSV contains only effective samples, oldest first. End is exclusive here.
function selection(size,effective,left,right) {
    if(!isFinite(size)||!isFinite(effective)||size<effective||effective<1||!isFinite(left)||!isFinite(right)||left>right)
        throw new Error("底部数据选区无效或没有有效采样。");
    var offset=size-effective,start=Math.max(0,Math.ceil(left)-offset),end=Math.min(effective,Math.floor(right)-offset+1);
    if(end<=start) throw new Error("底部选择条尚未选中有效数据，请将选区移动到有数据的位置。");
    return {start:start,end:end,count:end-start};
}
