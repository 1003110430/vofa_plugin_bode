﻿param(
    [string]$TargetPath = 'C:\Program Files\Gutega\VOFA+\x64'
)
$ErrorActionPreference = 'Stop'
$targetRoot = (Resolve-Path -LiteralPath $TargetPath).ProviderPath
if (-not (Test-Path -LiteralPath (Join-Path $targetRoot 'vofa+.exe') -PathType Leaf)) {
    throw 'TargetPath 必须是包含 vofa+.exe 的目录。'
}
$pluginSource = Join-Path $PSScriptRoot 'plugins\widgets\bode'
if (-not (Test-Path -LiteralPath (Join-Path $pluginSource 'bode.qml') -PathType Leaf)) {
    throw '没有找到插件源码，请先完整解压发布包。'
}
$widgetRoot = Join-Path $targetRoot 'plugins\widgets'
$pluginTarget = Join-Path $widgetRoot 'bode'
if (Test-Path -LiteralPath $pluginTarget) {
    $backupRoot = Join-Path $targetRoot ('bode-plugin-backups\' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
    Copy-Item -LiteralPath $pluginTarget -Destination $backupRoot -Recurse
    Write-Output ('已备份原插件：' + $backupRoot)
}
New-Item -ItemType Directory -Path $widgetRoot -Force | Out-Null
Copy-Item -LiteralPath $pluginSource -Destination $widgetRoot -Recurse -Force
Write-Output ('已安装：' + $pluginTarget)
Write-Output '请重启 VOFA+，从控件列表拖入 bode。'
